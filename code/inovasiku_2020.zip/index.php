<?
session_start();
ob_start();
#####
if(isset($_SESSION['login'])){}else{session_destroy();header("Location: App/login");}
echo "..Load Apps..".$_SESSION['apps'];
#sleep(10);
#exit();
if($_GET['action']=='print'){
include("App/template/sinovda/index.print.php");
}else{
	include("App/template/".$_SESSION['apps']."/index.php");
}
?>