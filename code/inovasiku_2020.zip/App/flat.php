<?
include('header.php');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Aplikasi Manajemen Percetakan</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
</head>
<body>


<!-- Container -->
<div id="container">
	<div class="shell">
		
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
<?php
if($data['page']) {
$page=$data['page'];
$modul=$data['modul'];
} else {
$page='order';
$modul='admin';
}
include("modul/".$modul."/".$page.".php");
?>  				
				
				

			</div>
			<!-- End Content -->
			
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->



	
</body>
</html>