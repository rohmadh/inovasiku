<?
session_start();
ob_start();
include("../header.php");
?>
<?
if($_GET['mode']=='logout'){session_destroy();}
if($_POST['tbl']=='Login'){
#echo $cek1;
$nip=sanitize(cleanerpost($_POST['username'],'string'));
$psw=sanitize(cleanerpost($_POST['password'],'string'));
$cek1=md5($psw);
$a=0;$b=0;$d=0;$k=0;
$q1="select *,keu_pengguna.id as idd,skpd.namaskpd as skpd,keu_pengguna.skpd as idskpd,keu_pengguna.nama as namauser,skpd.apps as apps from keu_pengguna 
left join skpd on keu_pengguna.level=skpd.id
where nip=:nip and passwd=:psw";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q1);
$stmt->bindValue(':nip', $nip, PDO::PARAM_STR);
$stmt->bindValue(':psw', $cek1, PDO::PARAM_STR);
$stmt->execute();
$r1 = $stmt->fetch();
#echo $stmt->rowCount();
 if(($stmt->rowCount()==1) and (strlen($r1['nip'])>0)) {
 $_SESSION['login']='1';$_SESSION['namauser']=$r1['namauser'];$_SESSION['nipuser']=$r1['nip'];$_SESSION['iduser']=$r1['idd'];
 $_SESSION['skpduser']=$r1['skpd'];$_SESSION['leveluser']=$r1['level'];$_SESSION['idskpduser']=$r1['idskpd'];$_SESSION['thn']=date('Y');
 $_SESSION['txtskpd']=$r1['skpd'];$_SESSION['pmbtingkat']=$r1['idskpd'];
 $_SESSION['temp']=rand();
 $_SESSION['apps']=$r1['apps'];
 #header("Location: ../");
 echo "ok";
 }else{ echo "<center>----LOGIN GAGAL</center>";}
}

?>