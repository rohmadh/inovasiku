<?
include("smart_resize_image.function.php");
if(strlen($_POST['cd'])>1){
mkdir("gallery/".$_POST['cd']."");
}
if(($data['mode']=='del')||(($data['ddel'])>1)){

$path="gallery/".$data['ddel']."/";
$files = glob($path . '/*');
	foreach ($files as $file) {
		is_dir($file) ? removeDirectory($file) : unlink($file);
	}
	rmdir($path);
	echo "ALbum ".$data['ddel']." berhasil dihapus";
}
if(($data['mode']=='delfile')){
echo "".$data['fdel']." Berhasil dihapus";
unlink("gallery/".$data['dd']."/".$data['fdel']."");
}
if($_POST['newdir']){

 rename("gallery/".$_POST['olddir']."","gallery/".$_POST['newdir']."");
}
if($_POST['submit']){

$target_dir = "gallery/".$data['dd']."/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
		if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
		//copy("gallery/".$data['dd']."/".basename( $_FILES["fileToUpload"]["name"])."","gallerycrop/".time()."-".basename( $_FILES["fileToUpload"]["name"])."");
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
		//resize
		 //indicate which file to resize (can be any type jpg/png/gif/etc...)
      $file = 'gallery/'.$data['dd'].'/'.basename( $_FILES["fileToUpload"]["name"]).'';

      //indicate the path and name for the new resized file
      $resizedFile = 'gallerycrop/'.time().'-'.basename( $_FILES["fileToUpload"]["name"]).'';

      //call the function (when passing path to pic)
      smart_resize_image($file , null, 230 , null , true , $resizedFile , false , false ,100 );
      //call the function (when passing pic as string)
      //smart_resize_image(null , file_get_contents($file), 230 , 230 , false , $resizedFile , false , false ,100 );

      //done!
		
		//
		
		
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
		
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}


}
?>
<div class="box-head">
<h2>Pengaturan Gallery</h2>
</div>
<?if(strlen($data['dd'])>0){?>
<fieldset>
<form  method="post" action="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=albumfoto&dd=".$data['dd']."",$key2));?>" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
	
</form>
</fieldset>

<?}else{?>
<fieldset>
<form method="post">
Nama Album: <input type="text" name="cd"><input type="submit" value="BUAT ALBUM">
</form>
</fieldset>
<?}?>

<!--##################-->

<script type="text/javascript">
$(document).ready(function () {
    $("a[rel^='prettyPhoto']").prettyPhoto({
        theme: 'dark_rounded',
        overlay_gallery: false
    });
});
</script>
<link rel="stylesheet" href="App/prettyPhoto/prettyPhoto.css" type="text/css" />
<script type="text/javascript" src="App/prettyPhoto/jquery-prettyPhoto.js"></script>
<!--##################-->

    
      <!-- ####################################################################################################### -->
      <div class="table">
        <h2>Direktori Galeri <?if($data['dd']){?>-->[ALBUM <?echo $data['dd']?>]<?}?></h2>
        


			
<?
if(strlen($data['dd'])>0){
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<th>File</th><th>Hapus</th>
</tr>  
<?
$directory2 = "gallery/".$data['dd']."/";
if ($handle = opendir($directory2)) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {?>
			<tr><td>
            <img src="gallery/<? echo $data['dd'];echo"/";echo $entry;?>" alt="" width="160px" height="160px"/>
			</td>
			<td>
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=albumfoto&mode=delfile&dd=".$data['dd']."&fdel=".$entry."",$key2));?>">[X]</a>
			</td>
			</tr>
			<?
        }
    }

    closedir($handle);
}
}
if (glob($directory2 . "*.jpg") != false)
{
 $filecount = count(glob($directory2 . "*.jpg"));
 #echo $filecount;
}
else
{
 $filecount= 0;
}
#echo $filecount;
$i=1;
while($i<($filecount+1)) {
?>
          
<? $i++; };?> 
        
      </div>
 

 
<br class="clear" />
<br class="clear" />
					
<div class="table">
        
     
         
		  <?
if($data['dd']==''){
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<th>Nama Album</th><th>Hapus Album</th><th>Ganti Nama</th>
</tr>   
<?
 $directory = "gallery/";
 $ldir=glob($directory. "*",GLOB_ONLYDIR);
 foreach($ldir as $odir){
				$rdir=explode("/",$odir);
				
				$dir = "gallery/".$rdir[1]."/";

// Open a directory, and read its contents
if (is_dir($dir)){
  if ($dh = opendir($dir)){
		
		
    while (($file = readdir($dh)) !== false){
	    if(strlen($file)>4) {
               //echo "filename:" . $file . "<br>";
			   break;
			   } 
			   
    }
    closedir($dh);
  }
}
				
				
				?>
				<tr> 
				<td>
				<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=albumfoto&dd=".$rdir[1]."",$key2));?>"><?echo $rdir[1];?></a>
				</td>
				<td>
				<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=albumfoto&mode=del&ddel=".$rdir[1]."",$key2));?>">[X]</a>
				 </td>
				 <td>
				 <form method="post">
				 <input type="hidden" name="olddir" value="<?echo $rdir['1']?>"><input type="text" name="newdir"><input type="submit" value="PROSES">
				 </form>
				 </td>
				</tr>
				<?
				
			
			}}?>

</table>			

		  
		  
		  
            
			
			
         
		  
		  
		  
</div>
 <br class="clear" />
 <br class="clear" />