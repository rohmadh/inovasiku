<?
include('../header.php');
$q1=mysql_query("select * from transaksi_order  
left join master_klien on transaksi_order.id_klien=master_klien.id
where notrx='".$_GET['notrx']."'
");
$r1=mysql_fetch_array($q1);
$q2=mysql_query("select * from setting limit 1");
$r2=mysql_fetch_array($q2);
$q3=mysql_query("select * from transaksi_detail left join master_barang on transaksi_detail.idbarang=master_barang.id
where transaksi_detail.notrx='".$_GET['notrx']."'
");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type"><title>Print invoice#<?echo $_GET['notrx']?></title>

</head><body style="width: 717px;">
<big><span style="font-weight: bold; font-family: Cambria;">
<?echo $r2['namausaha'];?></span>
</big>
<br style="font-weight: bold; font-family: Cambria;"><span style="font-weight: bold; font-family: Cambria;">
<?echo $r2['alamat'];?></span><br style="font-weight: bold; font-family: Cambria;"><span style="font-weight: bold; font-family: Cambria;">
<?echo $r2['telp'];?>
</span><br style="font-weight: bold; font-family: Cambria;">


<br>
<table style="text-align: left; width: 700px; height: 52px;" border="0" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td style="width: 395px;">Kepada : <?echo $r1['nama'];?><br>
Alamat : <?echo $r1['alamat'];?></td>
<td style="width: 196px;"><b>INVOICE No.<?echo $r1['notrx'];?></b><br>
Tanggal: <i><?echo $r1['wkt'];?></i></td>
</tr>
</tbody>
</table>
<hr>
<table style="text-align: left; height: 60px; width: 700px;" border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td style="width: 255px;">Produk</td>
<td style="width: 96px;">Satuan</td>
<td style="width: 140px;">Harga</td>
<td style="width: 29px;">Jumlah</td>
<td style="width: 140px;">Total</td>
</tr>
<?
		$tot=0;
		while($r3=mysql_fetch_array($q3)){?>
<tr>
<td style="width: 255px;"><?echo $r3['nama'];?></td>
<td style="width: 96px;" align="center"><?echo $r3['satuan'];?></td>
<td style="width: 140px;" align="right"><?echo uang($r3['harga']);?></td>
<td style="width: 29px;" align="right"><?echo $r3['jml'];?></td>
<td style="width: 140px;" align="right"><?echo uang($r3['total']);?></td>
</tr>
<?
		 $tot=$tot+$r3['total'];
		 }?> 
</tbody>
</table>
<table style="text-align: left; height: 60px; width: 701px;" border="0" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td style="width: 337px;"></td>
<td style="width: 180px;">Sub Total</td>
<td style="width: 162px;" align="right"><?echo uang($tot);?></td>
</tr>
<tr>
<td style="width: 337px;"></td>
<td style="width: 180px;">Pembayaran</td>
<td style="width: 162px;" align="right"><?echo uang($r1['bayar']);?></td>
</tr>
<tr>
<td style="width: 337px;"></td>
<td style="width: 180px;">Kembali</td>
<td style="width: 162px;" align="right"><?echo uang($r1['kembali']);?></td>
</tr>
</tbody>
</table>
<br>
Terima Kasih<br>
</body></html>