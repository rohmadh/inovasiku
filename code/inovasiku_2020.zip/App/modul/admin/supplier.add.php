<?
if($_POST['action']=='submit'){
mysql_query("insert into master_supplier (nama,alamat,telp,ket) values ('".$_POST['nama']."','".$_POST['alamat']."','".$_POST['telp']."','".$_POST['ket']."')");
}

if($_POST['action']=='update'){
mysql_query("update master_supplier set nama='".$_POST['nama']."',alamat='".$_POST['alamat']."',telp='".$_POST['telp']."',ket='".$_POST['ket']."' 
where id='".$_POST['ide']."'");
}
if($data['mode']=='edit'){
$qc=mysql_query("select * from master_supplier where id='".$data['id']."'");
$rqc=mysql_fetch_array($qc);
}
?>
<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=supplier.list",$key2));?>">Daftar Supplier</a>
			
		</div>
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Add Supplier</h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									<span class="req">max 100 symbols</span>
									<label>Nama <span>(Required Field)</span></label>
									<input name="nama" type="text" class="field size1" value="<?echo $rqc['nama'];?>"/>
								</p>
								<p>
									<span class="req">max 100 symbols</span>
									<label>Alamat <span>(Required Field)</span></label>
									<input name="alamat" type="text" class="field size1" value="<?echo $rqc['alamat'];?>"/>
								</p>
								<p>
									<span class="req">max 100 symbols</span>
									<label>Telp <span>(Required Field)</span></label>
									<input name="telp" type="text" class="field size2" value="<?echo $rqc['telp'];?>"/>
								</p>
								
								<p>
									<span class="req">max 100 symbols</span>
									<label>Keterangan <span>(Required Field)</span></label>
									<textarea name="ket" class="field size1" rows="10" cols="30"><?echo $rqc['ket'];?></textarea>
								</p>	
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							<input type="hidden" name="ide" value="<?echo $data['id']?>">
							<input name="action" type="submit" class="button" value="<?if($data['mode']=='edit'){echo "update";}else{echo "submit";}?>" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->