<?
if($_POST['action']=='submit'){
mysql_query("update setting set namausaha='".$_POST['namausaha']."',alamat='".$_POST['alamat']."'");
}
$q=mysql_query("select * from setting limit 1");
$r=mysql_fetch_array($q);
?>

				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Setting </h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									
									<label>Nama Perusahaan<span>(Required Field)</span></label>
									<input name="namausaha" type="text" class="field size1" value="<?echo $r['namausaha'];?>"/>
								</p>
								<p>
									
									<label>Alamat <span>(Required Field)</span></label>
									<textarea name="alamat" class="field size1" rows="10" cols="30"><?echo $r['alamat'];?></textarea>
								</p>
								
								
								
									
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							
							<input name="action" type="submit" class="button" value="submit" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->