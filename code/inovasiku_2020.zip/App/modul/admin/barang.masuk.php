<?
if(($_POST['action']=='submit')and ($_POST['jml']>'0')){
mysql_query("insert into stok_barang (idbarang,jml) values ('".$_POST['idbarang']."','".$_POST['jml']."')");
}
if($_POST['idbarang']>0){
$q1=mysql_query("select * from master_barang where id='".$_POST['idbarang']."'");
$r1=mysql_fetch_array($q1);

}
?>
<script language="javascript" type="text/javascript">
<!--
function popitup(url) {
	self.name = 'mainWin';
	newwindow=window.open(url,'name','height=400,width=800,toolbar=0,status=0,left=150,top=100');
	if (window.focus) {newwindow.focus()}
	return false;
}

// -->
</script>
<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=stok.barang",$key2));?>">Stok Produk</a>
			
		</div>
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Barang Masuk STOK</h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									
									<label>Kode Barang <span>(Required Field)</span></label>
									<input name="idbarang" type="text" class="field size2" value="<?echo $r1['id'];?>"/>
									<input type="button" value="Daftar Barang"
						onclick="return popitup('flat.php?pid=<? echo rawurlencode(encrypt("?modul=admin&page=popupstok.daftar.produk",$key2));?>')"
						>
								</p>
								
								<p>
									
									<label>Nama <span>(Required Field)</span></label>
									<input name="nama" type="text" class="field size1" value="<?echo $r1['nama'];?>" readonly/>
								</p>
								
								
								<p>
									
									<label>Jumlah Masuk <span></span></label>
									<input name="jml" type="text" class="field size2" />
								</p>
								
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							
							<input name="action" type="submit" class="button" value="submit" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->