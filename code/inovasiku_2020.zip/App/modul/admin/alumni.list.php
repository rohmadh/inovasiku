<style type="text/css">

.page
{
float: right;
margin: 0;
padding: 0;
}
.page li
{
	list-style: none;
	display:inline-block;
}
.page li a, .current
{
display: block;
padding: 5px;
text-decoration: none;
color: #8A8A8A;
}
.current
{
	font-weight:bold;
	font-size:14px;
	color: #000;
}
.button
{

float: left;
}
</style>
<?
$start=0;
	$limit=25;

	if(isset($data['id']))
		{
			$id=$data['id'];
			$start=($id-1)*$limit;
	}
if($data['mode']=='del'){
mysql_query("delete from data_alumni where id='".$data['id']."'");
}
if($_POST['q']){
$q1=mysql_query("select * from data_alumni where nama like '%".$_POST['q']."%' or alamat like '%".$_POST['q']."%'");}else{
$q1=mysql_query("select * from data_alumni order by nama ASC LIMIT ".$start.", ".$limit."");}

?>
	<!-- Small Nav -->
		
		<!-- End Small Nav -->	
			<?
			$qdata=mysql_query("select count(id) as ja from data_alumni");
			$rdata=mysql_fetch_array($qdata);
			?>
		
				
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Daftar alumni   ----[ Total data: <?echo $rdata['ja'];?>]</h2>
						<div class="right">
							
							<form method="post">
							<input type="text" class="field small-field" name="q"/>
							<input type="submit" class="button" value="search" />
							</form>
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								<th>Nama</th>
								<th>Alamat</th>
								<th>Telp</th>
								<th>Instansi</th>
								
								<th width="110" class="ac">Content Control</th>
							</tr>
							<?
							while($rq1=mysql_fetch_array($q1)) {
							?>
							<tr>
								
								<td><h3><a href="#"><?echo $rq1['nama'];?></a></h3></td>
								<td><?echo $rq1['alamat'];?></td>
								<td><?echo $rq1['notelp'];?></td>
								<td><?echo $rq1['instansi'];?></td>
								<td><a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=alumni.list&mode=del&id=".$rq1['id']."",$key2));?>" class="ico del">Delete</a>
								<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=alumni.add&mode=edit&id=".$rq1['id']."",$key2));?>" class="ico edit">Edit</a>
								
								</td>
							</tr>
							<?}?>
						<tr>
						<td colspan="5">
						
						<?
	$rows=mysql_num_rows(mysql_query("select * from data_alumni"));
$total=ceil($rows/$limit);

if($id>1)
{ ?>
	
	<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=alumni.list&id=".($id-1)."",$key2));?>" class='button'><< SEBELUMNYA</a>
	<?
}
if($id!=$total)
{?>
	<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=alumni.list&id=".($id+1)."",$key2));?>" class='button' >LANJUT >></a>
	<?
}

echo "<ul class='page'> Total: ".$rows." data, &nbsp;&nbsp;&nbsp;Halaman Ke- ";
		for($i=1;$i<=$total;$i++)
		{
			if($i==$id) { echo "<li class='current'>".$i."</li>"; }
			
			else { ?><li><a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=alumni.list&id=".$i."",$key2));?>">
			<? echo $i;?></a></li><? }
		}
echo "</ul>";
	?>
						
						</td>
						</tr>
							
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
				
			
			