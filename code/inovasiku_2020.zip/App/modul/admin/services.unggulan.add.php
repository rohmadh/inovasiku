<?


if($_POST['action']=='update'){
mysql_query("update services set depan='".$_POST['depan']."',gbrdepan='".$_POST['gbrdepan']."',unggulan='1'

where id='".$_POST['ide']."'");
}
if($data['mode']=='edit'){
$qc=mysql_query("select * from services where id='".$data['id']."'");
$rqc=mysql_fetch_array($qc);
}

echo mysql_error();
?>
<script type="text/javascript" src="js/nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>
<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=services.list",$key2));?>">Daftar Layanan</a>
			
		</div>
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>LAYANAN UNGGULAN</h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									
									<label>Judul <span>(Required Field)</span></label>
									<input name="judul" type="text" class="field size1" value="<?echo $rqc['judul'];?>" readonly/>
								</p>
								
								
								
								
								<p>
									
									<label>INFO SINGKAT</label>
									<textarea name="depan" class="field size1" rows="10" cols="30"><?echo $rqc['depan'];?></textarea>
								</p>
								<p>
									
									<label>Gambar</label>
									<input name="gbrdepan" type="text" class="field size1" value="<?echo $rqc['gbrdepan'];?>" />
								</p>
								
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							<input type="hidden" name="ide" value="<?echo $data['id']?>">
							<input name="action" type="submit" class="button" value="<?if($data['mode']=='edit'){echo "update";}else{echo "submit";}?>" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->