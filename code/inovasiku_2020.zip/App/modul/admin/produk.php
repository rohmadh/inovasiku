<?
if($_POST['action']=='submit'){
mysql_query("insert into master_barang (idsup,nama,satuan,harga,kat,info,gbr) values ('".$_POST['idsup']."','".$_POST['nama']."','".$_POST['satuan']."','".$_POST['harga']."','".$_POST['kat']."',
'".$_POST['info']."','".$_POST['gbr']."')");
}

if($_POST['action']=='update'){
mysql_query("update master_barang set idsup='".$_POST['idsup']."',nama='".$_POST['nama']."',satuan='".$_POST['satuan']."',harga='".$_POST['harga']."',kat='".$_POST['kat']."',
info='".$_POST['info']."',gbr='".$_POST['gbr']."' 
where id='".$_POST['ide']."'");
}
if($data['mode']=='edit'){
$qc=mysql_query("select * from master_barang where id='".$data['id']."'");
$rqc=mysql_fetch_array($qc);
}

echo mysql_error();
?>
<script type="text/javascript" src="js/nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>
<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.produk",$key2));?>">Daftar Produk</a>
			
		</div>
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Add PRODUK</h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									
									<label>Nama <span>(Required Field)</span></label>
									<input name="nama" type="text" class="field size1" value="<?echo $rqc['nama'];?>"/>
								</p>
								
								<p>
									
									<label>Kategori </label>
									<select name="kat">
									<?
									$qk=mysql_query("select * from kategori");
									while($rqk=mysql_fetch_array($qk)){
									?>
									<option value="<?echo $rqk['id'];?>" <?if($rqk['id']==$rqc['kat']){echo "selected";}?>><?echo $rqk['kat'];?></option>
									<?}?>
									</select>
									
								</p>
								<p>
									
									<label>Satuan <span>(Required Field)</span></label>
									<input name="satuan" type="text" class="field size2" value="<?echo $rqc['satuan'];?>"/>
								</p>
								<p>
									
									<label>Harga <span>(Rupiah)</span></label>
									<input name="harga" type="text" class="field size1" value="<?echo $rqc['harga'];?>"/>
								</p>
								<p>
									
									<label>SUPPLIER </label>
									<select name="idsup">
									<?
									$qk=mysql_query("select * from master_supplier");
									while($rqk=mysql_fetch_array($qk)){
									?>
									<option value="<?echo $rqk['id'];?>" <?if($rqk['id']==$rqc['idsup']){echo "selected";}?>><?echo $rqk['nama'];?></option>
									<?}?>
									</select>
								</p>
								<p>
									
									<label>Gambar</label>
									<textarea name="gbr" class="field size1" rows="10" cols="30">
									<?if (strlen($rqc['gbr'])>10) {echo $rqc['gbr'];}else{?>
									<div class="img">
  <a target="_blank" href="fjords.jpg">
    <img src="fjords.jpg" alt="pic1" width="150" height="150">
  </a>
  <div class="desc">Add a description of the image here</div>
</div>

<div class="img">
  <a target="_blank" href="forest.jpg">
    <img src="forest.jpg" alt="pic2" width="150" height="150">
  </a>
  <div class="desc">Add a description of the image here</div>
</div>

<div class="img">
  <a target="_blank" href="lights.jpg">
    <img src="lights.jpg" alt="pic3" width="150" height="150">
  </a>
  <div class="desc">Add a description of the image here</div>
</div>
									<?}?>
									
									</textarea>
								</p>
								<p>
									
									<label>Deskripsi Produk</label>
									<textarea name="info" class="field size1" rows="10" cols="30"><?echo $rqc['info'];?></textarea>
								</p>
								
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							<input type="hidden" name="ide" value="<?echo $data['id']?>">
							<input name="action" type="submit" class="button" value="<?if($data['mode']=='edit'){echo "update";}else{echo "submit";}?>" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->