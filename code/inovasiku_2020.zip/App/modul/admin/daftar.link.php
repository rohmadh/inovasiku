<?
if($data['mode']=='del'){
mysql_query("delete from links where id='".$data['id']."'");
}
if($_POST['q']){
$q1=mysql_query("select * from links where url like '%".$_POST['q']."%' or text like '%".$_POST['q']."%'");}else{
$q1=mysql_query("select * from links");}

?>
	<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=kategori",$key2));?>">Tambah </a>
			
		</div>
		<!-- End Small Nav -->	
		
		
				
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Daftar Link</h2>
						<div class="right">
							
							<form method="post">
							<input type="text" class="field small-field" name="q"/>
							<input type="submit" class="button" value="search" />
							</form>
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								<th>URL</th>
								
								
								
								<th width="110" class="ac">Content Control</th>
							</tr>
							<?
							while($rq1=mysql_fetch_array($q1)) {
							?>
							<tr>
								
								<td><h3><a href="#"><?echo $rq1['url'];?></a></h3></td>
								
								
								<td><a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.link&mode=del&id=".$rq1['id']."",$key2));?>" class="ico del">Delete</a>
								<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=add.link&mode=edit&id=".$rq1['id']."",$key2));?>" class="ico edit">Edit</a>
								
								</td>
							</tr>
							<?}?>
							
							
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
				
			
			