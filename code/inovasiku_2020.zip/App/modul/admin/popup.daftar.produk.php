<?
$q1=mysql_query("select * from master_barang");

?>
		
<script langauge="javascript">
function post_value(){
opener.document.form.kprd.value = document.frm.kprd.value;
 
}
</script>		
		
				
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Daftar Produk</h2>
						<div class="right">
							<label></label>
							
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								<th>Nama</th>
								<th>satuan</th>
								<th>Harga</th>
								
								<th width="110" class="ac">Content Control</th>
							</tr>
							<?
							while($rq1=mysql_fetch_array($q1)) {
							?>
							<tr>
								
								<td><h3><a href="#"><?echo $rq1['nama'];?></a></h3></td>
								<td><?echo $rq1['satuan'];?></td>
								<td><?echo $rq1['harga'];?></td>
								<td>
								<form name="frm" method=post action="admin.php?pid=<? echo rawurlencode(encrypt("?modul=admin&page=new_order&idklien=".$data['idklien']."",$key2));?>" target="mainWin">
								<input type=hidden name="kprd" value="<?echo $rq1['id'];?>">
								<input type=submit value="INSERT" onclick="submit();self.close();">
								</form>
								</td>
							</tr>
							<?}?>
							
							
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
				
			
			