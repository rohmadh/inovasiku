<?
if($_POST['action']=='submit'){
mysql_query("insert into staff (gbr,nama,ahli,praktik,lainnya) values ('".$_POST['gbr']."','".$_POST['nama']."','".$_POST['ahli']."','".$_POST['praktik']."','".$_POST['lainnya']."')");
}

if($_POST['action']=='update'){
mysql_query("update staff set gbr='".$_POST['gbr']."',nama='".$_POST['nama']."',ahli='".$_POST['ahli']."',praktik='".$_POST['praktik']."',lainnya='".$_POST['lainnya']."'

where id='".$_POST['ide']."'");
}
if($data['mode']=='edit'){
$qc=mysql_query("select * from staff where id='".$data['id']."'");
$rqc=mysql_fetch_array($qc);
}

echo mysql_error();
?>
<script type="text/javascript" src="js/nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>
<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.dokter",$key2));?>">Daftar Dokter</a>
			
		</div>
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Data Dokter</h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									
									<label>Nama <span>(Required Field)</span></label>
									<input name="nama" type="text" class="field size1" value="<?echo $rqc['nama'];?>"/>
								</p>
								
								<p>
									
									<label>Bidang Keahlian <span>(Required Field)</span></label>
									<input name="ahli" type="text" class="field size1" value="<?echo $rqc['ahli'];?>"/>
								</p>
								<p>
									
									<label>Foto <span>(Required Field)</span></label>
									<input name="gbr" type="text" class="field size" value="<?echo $rqc['gbr'];?>"/>
								</p>
								
								<p>
									
									<label>Informasi Praktik</label>
									<textarea name="praktik" class="field size1" rows="10" cols="30"><?echo $rqc['praktik'];?></textarea>
								</p>
								<p>
									
									<label>Informasi Lainnya</label>
									<textarea name="lainnya" class="field size1" rows="10" cols="30"><?echo $rqc['lainnya'];?></textarea>
								</p>
								
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							<input type="hidden" name="ide" value="<?echo $data['id']?>">
							<input name="action" type="submit" class="button" value="<?if($data['mode']=='edit'){echo "update";}else{echo "submit";}?>" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->