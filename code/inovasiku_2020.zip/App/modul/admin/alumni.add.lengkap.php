<?
if($_POST['action']=='submit'){
mysql_query("insert into data_alumni 
(nama,alamat,notelp,nowa,nobb,email,fb,alamatskrg,instansi,jabatan,alamatktr,narasumber,jobfair,cpkeg) 
values ('".$_POST['nama']."','".$_POST['alamat']."','".$_POST['notelp']."','".$_POST['nowa']."','".$_POST['nobb']."','".$_POST['email']."',
'".$_POST['fb']."','".$_POST['alamatskrg']."','".$_POST['instansi']."','".$_POST['jabatan']."','".$_POST['alamatktr']."','".$_POST['narasumber']."',
'".$_POST['jobfair']."','".$_POST['cpkeg']."'
)");
}

if($_POST['action']=='update'){

mysql_query("update data_alumni set 
nama='".$_POST['nama']."',alamat='".$_POST['alamat']."',notelp='".$_POST['notelp']."',nowa='".$_POST['nowa']."',nobb='".$_POST['nobb']."',
email='".$_POST['email']."',
fb='".$_POST['fb']."',alamatskrg='".$_POST['alamatskrg']."',instansi='".$_POST['instansi']."',jabatan='".$_POST['jabatan']."',
alamatktr='".$_POST['alamatktr']."',narasumber='".$_POST['narasumber']."',
jobfair='".$_POST['jobfair']."',cpkeg='".$_POST['cpkeg']."'
where id='".$_POST['ide']."'");
echo mysql_error();
}
if($data['mode']=='edit'){
$qc=mysql_query("select * from data_alumni where id='".$data['id']."'");
$rqc=mysql_fetch_array($qc);
}

echo mysql_error();
?>
<script type="text/javascript" src="js/nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>
<!-- Small Nav -->
		
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Add Alumni </h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									
									<label>Nama <span>(Required Field)</span></label>
									<input name="nama" type="text" class="field size1" value="<?echo $rqc['nama'];?>"/>
								</p>
								<p>
									
									<label>Alamat <span>(Required Field)</span></label>
									<input name="alamat" type="text" class="field size1" value="<?echo $rqc['alamat'];?>"/>
								</p>
								<p>
									
									<label>HP <span>(Required Field)</span></label>
									<input name="notelp" type="text" class="field size2" value="<?echo $rqc['notelp'];?>"/>
									<label>WA <span>(Required Field)</span></label>
									<input name="nowa" type="text" class="field size2" value="<?echo $rqc['nowa'];?>"/>
									<label>Pin BB <span>(Required Field)</span></label>
									<input name="nobb" type="text" class="field size2" value="<?echo $rqc['nobb'];?>"/>
									<label>E-mail <span>(Required Field)</span></label>
									<input name="email" type="text" class="field size2" value="<?echo $rqc['email'];?>"/>
								</p>
								<p>
									
									<label>Akun FB<span>(Required Field)</span></label>
									<input name="fb" type="text" class="field size1" value="<?echo $rqc['fb'];?>"/>
								</p>
								<p>
									
									<label>Alamat Saaat ini<span>(Required Field)</span></label>
									<input name="alamatskrg" type="text" class="field size1" value="<?echo $rqc['alamatskrg'];?>"/>
								</p>
								<p>
									
									<label>Instansi<span>(Required Field)</span></label>
									<input name="instansi" type="text" class="field size1" value="<?echo $rqc['instansi'];?>"/>
								</p>
								<p>
									
									<label>Jabatan<span>(Required Field)</span></label>
									<input name="jabatan" type="text" class="field size1" value="<?echo $rqc['jabatan'];?>"/>
								</p>
								<p>
									
									<label>Alamat Kantor<span>(Required Field)</span></label>
									<input name="alamatktr" type="text" class="field size1" value="<?echo $rqc['alamatktr'];?>"/>
								</p>
								<p>
									
									<label>Kesediaanmenjadinarasumberuntukkuliahtamu </label>
									<select name="narasumber">
									
									<option value="1" <?if ($rqc['narasumber']=='1'){echo "selected";}?>>Ya</option>
									<option value="0" <?if ($rqc['narasumber']=='0'){echo "selected";}?>>Tidak</option>
									</select>
									
								</p>
								<p>
									
									<label>KesediaanInstansiuntukberpartisipasidalamacaraCareer Day (Job Fair) dalamrangka melakukan open recruitment</label>
									<select name="jobfair">
									
									<option value="1" <?if ($rqc['jobfair']=='1'){echo "selected";}?>>Ya</option>
									<option value="0" <?if ($rqc['jobfair']=='0'){echo "selected";}?>>Tidak</option>
									</select>
									
								</p>
								<p>
									
									<label>
									
									Kesediaan menjadi Contact Person untuk kegiatan kuliahlapangan (field trip)
									</label>
									<select name="cpkeg">
									
									<option value="1" <?if ($rqc['cpkeg']=='1'){echo "selected";}?>>Ya</option>
									<option value="0" <?if ($rqc['cpkeg']=='0'){echo "selected";}?>>Tidak</option>
									</select>
									
								</p>
								
								
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							<input type="hidden" name="ide" value="<?echo $data['id']?>">
							<input name="action" type="submit" class="button" value="<?if($data['mode']=='edit'){echo "update";}else{echo "submit";}?>" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->