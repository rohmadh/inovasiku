
<!-- slider -->

							<div class="slider-holder">
								<div class="flexslider">
									<ul class="slides">
<?
if ($handle = opendir('slider/')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
			?>
										<li><img src="slider/<?echo "$entry";?>" width="720" height="334" border="0" usemap="#Map" /></li>
										
									<?
        }
    }

    closedir($handle);
}
?>
										
									</ul>
								</div>
							</div>
							
							<!-- end of slider -->	
<div class="about">
					<div>
						
						<div>
							<div>
								<h3>
								Artikel</h3>
								<p>
								<?
							$q=mysql_query("select *,news.id as idd,kategori.kat as kate from news left join kategori on news.kat=kategori.id
							where kategori.kat='Artikel' or kategori.kat='Berita' order by date DESC");
							echo mysql_error();
							while($r=mysql_fetch_array($q)){
							
							?>
							
								
								<b><?echo $r['judul']?></b>
								
									<p><?echo $r['depan']?>
									
									</p>
								<p>
								<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=news.read&id=".$r['idd']."",$key2));?>">Baca Berita</a>
								</p>
								<br />
							<?}?>
							</p>
								
							</div>
						</div>
						
						
						
					</div>
				</div>