<?


?>
<!-- slider -->

							<div class="slider-holder">
								<div class="flexslider">
									<ul class="slides">
<?
if ($handle = opendir('slider/')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
			?>
										<li><img src="slider/<?echo "$entry";?>" width="720" height="334" border="0" usemap="#Map" /></li>
										
									<?
        }
    }

    closedir($handle);
}
?>
										
									</ul>
								</div>
							</div>
							
							<!-- end of slider -->	
<div class="about">
					<div>
						
						<div>
							<div>
								<h3>DOKTER RSIA Gunung Sawo Semarang</h3>
								<p>
								<table>
								<tr>
								<th><p>Nama Dokter</p></th><th><p></p></th><th><p>Jadwal</p></th>
								</tr>
								<?
								$q1=mysql_query("select * from staff group by ahli order by id ASC");
								while($r1=mysql_fetch_array($q1)){
								?>
								<tr>
								<td><p><b><u><?echo $r1['ahli'];?> :</u></b></p></td><td></td><td></td>
								</tr>
								
								<?
								$q=mysql_query("select * from staff where ahli='".$r1['ahli']."' order by id ASC");
								while($r=mysql_fetch_array($q)){
								?>
								<tr>
								<td><p>&nbsp;&nbsp;<?echo $r['nama'];?> </p></td><td><p> </p></td>
								<td align="center"><p><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=dokter.read&id=".$r['id']."",$key2));?>"> Lihat</a></p></td>
								</tr>
								<?}?>
								<?}?>
								</table>
								</p>
							</div>
						</div>
						
						
						
					</div>
				</div>