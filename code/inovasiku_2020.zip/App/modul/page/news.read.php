<?
$q=mysql_query("select *,kategori.kat as kate from news 
left join kategori
on news.kat=kategori.id
where news.id='".$data['id']."'");
$r=mysql_fetch_array($q);
?>
<h2><?echo $r['judul'];?></h2>