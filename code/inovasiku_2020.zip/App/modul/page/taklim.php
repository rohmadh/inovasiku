<?
$q=mysql_query("select * from setting limit 0,1");

$r=mysql_fetch_array($q);
?>
<div class="clearfix content">
						
						<h1>Jadwal Ta'lim</h1>
						<div class="clearfix post-meta">
							<p><span><i class="fa fa-user"></i> Admin</span> <span><i class="fa fa-clock-o"></i> 20 Jan 2014</span> <span><i class="fa fa-comment"></i> 4 comments</span> <span><i class="fa fa-folder"></i> Category</span></p>
						</div>
						<? echo $r['taklim'];?><br />
						
						
					
					</div>