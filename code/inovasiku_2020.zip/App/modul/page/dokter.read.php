<?
$q=mysql_query("select * from staff where id='".$data['id']."'");
$r=mysql_fetch_array($q);
?>
<!-- slider -->

							<div class="slider-holder">
								<div class="flexslider">
									<ul class="slides">
<?
if ($handle = opendir('slider/')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
			?>
										<li><img src="slider/<?echo "$entry";?>" width="720" height="334" border="0" usemap="#Map" /></li>
										
									<?
        }
    }

    closedir($handle);
}
?>
										
									</ul>
								</div>
							</div>
							
							<!-- end of slider -->	
<div class="about">
					<div>
						
						<div>
							<div>
								<h3>Informasi Dokter<br />
								
								
								<table>
								<tr>
								<td><p><img src="<?if (str_word_count($r['gbr'])>0){echo $r['gbr'];}else{?>images/noimage.jpg<?}?>" width="180" height="180"></p></td>
								<td><p>
								<b>
								Nama: <?echo $r['nama'];?> <br />
								Keahlian: <?echo $r['ahli'];?> <br /><br />
								</b>
								</p>
								</td>
								</tr>
								</table>
								<p>
								<b>Jadwal Praktik:</b> <br /><br />
								
								<?echo $r['praktik'];?>
								</p>
								<p>
								
								<b>Informasi Tambahan:</b><br>
								<?echo $r['lainnya'];?>
								</p>
							</div>
						</div>
						
						
						
					</div>
				</div>