<?
$q=mysql_query("select * from setting limit 0,1");
$r=mysql_fetch_array($q);
?>
<!-- slider -->

							<div class="slider-holder">
								<div class="flexslider">
									<ul class="slides">
<?
if ($handle = opendir('slider/')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
			?>
										<li><img src="slider/<?echo "$entry";?>" width="720" height="334" border="0" usemap="#Map" /></li>
										
									<?
        }
    }

    closedir($handle);
}
?>
										
									</ul>
								</div>
							</div>
							
							<!-- end of slider -->	
<div class="about">
					<div>
						
						<div>
							<div>
								<h3>FASILITAS KAMAR </h3>
								<p>
								<?echo $r['staff'];?>
								</p>
							</div>
						</div>
						
						
						
					</div>
				</div>