<?
header("Location: ../");
?>
<!DOCTYPE html>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>.: RSIA Gunung Sawo Semarang :.</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<script type="text/javascript" src="js/jquery-1.7.0.min.js"></script>	
	<link rel="stylesheet" href="css/slider/flexslider.css" type="text/css" media="all" />
	<script src="js/slider/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/slider/functions.js" type="text/javascript"></script>
	<script type="text/javascript">
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
//-->
</script>
</head>
<body>
	<div class="background">
		<div class="page">
			<img src="images/logorsia.png" width="100"><img src="images/tulisan.png">
			<div class="sidebar">
				<ul>
					<li <?if($data['page']==''){?>class="selected"<?}?>>
						<a href="?">Home</a>
					</li>
					<li <?if($data['page']=='staff'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=staff",$key2));?>"><font size="1">FASILITAS KAMAR</font></a>
					</li>
					<li <?if($data['page']=='about'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=about",$key2));?>">About</a>
					</li>
					<li <?if($data['page']=='dokter_new'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=dokter_new",$key2));?>">DOKTER</a>
					</li>
					<li <?if($data['page']=='visimisi'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=visimisi",$key2));?>">Visi dan Misi</a>
					</li>
					<li <?if($data['page']=='contact'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=contact",$key2));?>">Contact</a>
					</li>
					<li <?if($data['page']=='gallery'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=gallery",$key2));?>">GALLERY</a>
					</li>
				</ul>
				<div class="first">
					<div>
						
						<img src="images/unggulanhead.png" alt="" width="180">
						<p>
							
						</p>
					</div>
				</div>
				<div>
				<?
				$q=mysql_query("select * from services where unggulan='1'");
				while($r=mysql_fetch_array($q)){
				?>
					<div>
						<h3><?echo $r['judul'];?></h3>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=services.read&id=".$r['id']."",$key2));?>">
						<img src="<?echo $r['gbrdepan'];?>" alt="" width="180">
						</a>
						
					</div>
				<?}?>
					
				</div>
			</div>
			<div class="body">
			<?php
if($data['page']) {
$page=$data['page'];
$modul=$data['modul'];
} else {
$page='home';
$modul='page';
}
include("modul/".$modul."/".$page.".php");
?>  	
			</div>
			<div class="footer">
				<div>
					<div>
					<?
						$q=mysql_query("select * from setting");
						$r=mysql_fetch_array($q);
						?>
						<h4><?echo $r['namausaha'];?>	</h4>
						
						<p>
						<?echo $r['alamat'];?>	
						</p>
						
					</div>
					<div>
						<h4>Links</h4>
						<ul>
					<li <?if($data['page']==''){?>class="selected"<?}?>>
						<a href="?">Home</a>
					</li>
					<li <?if($data['page']=='staff'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=staff",$key2));?>">Fasilitas Kamar</a>
					</li>
					<li <?if($data['page']=='about'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=about",$key2));?>">About</a>
					</li>
					<li <?if($data['page']=='dokter'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=dokter",$key2));?>">DOKTER</a>
					</li>
					<li <?if($data['page']=='visimisi'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=visimisi",$key2));?>">Visi dan Misi</a>
					</li>
					<li <?if($data['page']=='contact'){?>class="selected"<?}?>>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=contact",$key2));?>">Contact</a>
					</li>
				</ul>
					</div>
					<div class="connect">
						<h4>Keep In Touch</h4>
						<a href="http://twitter.com/" id="twitter">twitter</a> <a href="www.facebook.com/RSIA-Gunung-Sawo-382179138558787" id="facebook">facebook</a> 
					</div>
				</div>
				<p>
					www.rsiagunungsawo.co.id &#169; Copyright 2015. All rights reserved
				</p>
			</div>
		</div>
	</div>
</body>
</html>