
<span class="titl">Web Transate</span> 
	
	<span class="txt">  <br />
      
      </span> 
	  
	  <img src="App/template/images/c_tp.gif" alt="" width="596" height="6" style="margin:10px 0 0 0;" /> 
	  <span class="modl"> <span class="titl2" style="color:#DB4801;">&nbsp;</span> 
	  
	 <div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'id', layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL, autoDisplay: false}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
         
	  
	  </span> <img src="App/template/images/c_btm.gif" alt="" width="596" height="6" />
	  
	  