<?
$q=mysql_query("select * from master_barang where id='".$data['id']."'");
$r=mysql_fetch_array($q);
##############################
########

if($_POST['tblbeli']=='Beli'){
if($_SESSION['notrx']>0){} else {$_SESSION['notrx']=rand();}
mysql_query("insert into temporer_data (notrx,idbarang,jml,total) value ('".$_SESSION['notrx']."','".$_POST['idbarang']."','".$_POST['jml']."','".$_POST['jml']*$_POST['hrg']."')");

}

?>
<?if (isset($_SESSION['notrx'])){?>
     <span class="kranjang">Total Belanja: Rp. <?echo uang($rs['tot']);?></span>
	<span class="dat2"><a href="?pid=<? echo rawurlencode(encrypt("?modul=addons&page=checkout",$key2));?>">Checkout</a>
	
	</span>
	
	<span class="dat2"><a href="http://jne.co.id" target="new">Cek Tarif JNE</a></span>
	<span class="dat2"><a href="http://posindonesia.co.id" target="new">Tarif POS</a></span>
	<?}?>
<span class="titl">Product Detail</span> 
	
	<span class="txt">  <br />
      
      </span> 
	  
	  <img src="App/template/images/c_tp.gif" alt="" width="596" height="6" style="margin:10px 0 0 0;" /> 
	  <span class="modl"> <span class="titl2" style="color:#DB4801;">&nbsp;</span> 
	  
	  <span class="txt" style="width:90%;"> 
	<h2>
	<?
	echo $r['nama'];
	?></h2>
	<b>Harga Rp. <?echo uang($r['harga']);?></b> 
	<form method="post">
					<b>Qty: <input type="text" name="jml" value="1" size="5">.. <?echo $r['satuan'];?></b>
					<input type="submit" value="Beli" name="tblbeli" align=left >
					<input type="hidden" name="idbarang" value="<?echo $r['id'];?>" size="5">
					<input type="hidden" name="hrg" value="<?echo $r['harga'];?>">
					</form>
	
	<br/>
	<div class="info">
	<?
	echo $r['info'];
	?>
	</div>
	<?echo str_replace('gambar','App/gambar',$r['gbr']);?>
	
	
	<br />
	
	</span> 
	  
	  </span> <img src="App/template/images/c_btm.gif" alt="" width="596" height="6" />
	  
	  <?
$q=mysql_query("select * from master_barang where kat='".$r['kat']."' order by nama ASC");


?>

	 
	 <img src="App/template/images/c_tp.gif" alt="" width="596" height="6" style="margin:10px 0 0 0;align:center;" /> 
	  <span class="modl"> <span class="titl2" style="color:#DB4801;">Produk Terkait..</span>
	  <br /><br />
	  <div id="items">
	  <?while($r=mysql_fetch_array($q)){ ?>
	  <div class="item">
	  <?
	  $doc = new DOMDocument();
				@$doc->loadHTML($r['gbr']);

				$tags = $doc->getElementsByTagName('img');

				foreach ($tags as $tag) {
					$sgbr=$tag->getAttribute('src');
					
				}
	  
	  
	  ?>
	  <img src="App/<? if(strlen($sgbr)>0){echo $sgbr;}else{echo"App/template/images/noimage.jpg";}?>" height="140" width="140">
	  <p><a href="?pid=<? echo rawurlencode(encrypt("?modul=addons&page=product.read&id=".$r['id']."",$key2));?>"><?echo $r['nama'];?></a></p><span class="price">Rp. <?
	  if($r['harga']>0){
	  echo uang($r['harga']);}else{echo "call us";}?></span>
	  </div>
	  <?}?>
	  
	  </div> 
	  
	  </span> <img src="App/template/images/c_btm.gif" alt="" width="596" height="6" />