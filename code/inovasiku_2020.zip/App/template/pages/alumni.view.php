<?

if($data['mode']=='view'){
$qc=mysql_query("select * from data_alumni where id='".$data['id']."'");
$rqc=mysql_fetch_array($qc);
}

echo mysql_error();
?>

<!-- Small Nav -->
		
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Profil Data Alumni</h2>
					</div>
					<!-- End Box Head -->
	<table cellspacing='0'>				
					    <!-- Table Header -->
	<thead>
		<tr>
			<th colspan="2">Biodata Alumni</th>
			
			
		</tr>
	</thead>
	<!-- Table Header -->

	<!-- Table Body -->
	<tbody>
	<tr>
	<td>Nama Lengkap dan Gelar</td><td><?echo $rqc['nama'];?></td>
	</tr>
	
	
	</tbody>
	</table>
	<table cellspacing='0'>				
					    <!-- Table Header -->
	<thead>
		<tr>
			<th>Jenjang</th>
			<th>Universitas</th>
			<th>Departemen</th>
			<th>Tahun masuk</th>
			<th>Tahun Lulus</th>
			<th>Prodi</th>
		</tr>
	</thead>
	<!-- Table Header -->

	<!-- Table Body -->
	<tbody>
	<?
$qa=mysql_query("select * from akademik where idorg='".$rqc['id']."'");
while($rqa=mysql_fetch_array($qa)) {
?>
	<tr>
	<td><?echo $rqa['jenjang'];?></td><td><?echo $rqa['universitas'];?></td><td><?echo $rqa['departemen'];?></td>
	<td><?echo $rqa['tmasuk'];?></td><td><?echo $rqa['tlulus'];?></td><td><?echo $rqa['prodi'];?></td>
	</tr>
<?}?>
	
	</tbody>
	</table>
	<table cellspacing='0'>				
					    <!-- Table Header -->
	<thead>
		<tr>
			<th colspan="2">Biodata Alumni</th>
			
			
		</tr>
	</thead>
	<!-- Table Header -->

	<!-- Table Body -->
	<tbody>
	
	
	<tr>
	<td>Akun FB/Twitter</td><td><?echo $rqc['fb'];?></td>
	</tr>
	
	<tr>
	<td>Instansi</td><td><?echo $rqc['instansi'];?></td>
	</tr>
	<tr>
	<td>Jabatan</td><td><?echo $rqc['jabatan'];?></td>
	</tr>
	<tr>
	<td>Alamat Kantor</td><td><?echo $rqc['alamatktr'];?></td>
	</tr>
	
	
	</tbody>
	</table>

    	
						
					
				</div>
				<!-- End Box -->