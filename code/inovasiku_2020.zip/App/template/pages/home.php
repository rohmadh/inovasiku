<form method="POST" action="?pid=<? echo rawurlencode(encrypt("?modul=page&page=alumnisearch",$key2));?>">
	<table>
	<tr>
	<td><label>Pencarian Berdasarkan:</label></td>
	<td><select name="data">
	<option value="nama">Nama</option>
	<option value="alamat">Alamat</option>
	<option value="alamatktr">Alamat Instansi</option>
	<option value="s1">S1</option>
	<option value="s2">S2</option>
	<option value="s3">S3</option>
	</select> </td>
	<td><input type="text" name="t" id="name" value="" size="50" /> </td>
	</tr>
	
	</table>
	
	</form>
	
      <table cellspacing='0' width="100%"> <!-- cellspacing='0' is important, must stay -->

	<!-- Table Header -->
	<thead>
		<tr>
			<th>Nama Lengkap dan Gelar</th>
			<th>Studi</th>
			<th>Akun FB/Twitter</th>
			<th>Instansi</th>
			<th>Jabatan</th>
			<th>Alamat Kantor</th>
			<th>Lihat</th>
		</tr>
	</thead>
	<!-- Table Header -->

	<!-- Table Body -->
	<tbody>
	<?
	
	
	   
	$q=mysql_query("select * from data_alumni order by nama ASC limit 0,25");
	echo mysql_error();
	$i=1;	
    while($r=mysql_fetch_array($q)){
    
    ?>

		<tr>
			<td><?echo $r['nama'];?></td>
			<td align="left">
			
			<?
			$qs=mysql_query("select * from akademik where idorg='".$r['id']."'");
			while($rs=mysql_fetch_array($qs)) {
			echo $rs['jenjang'];
			echo "&nbsp;-&nbsp;";
			echo $rs['universitas'];
			echo "<br />";
			}
			?>
			
			</td>
			<td><?echo $r['fb'];?></td>
			<td><?echo $r['instansi'];?></td>
			<td><?echo $r['jabatan'];?></td>
			<td><?echo $r['alamatktr'];?></td>
			<td><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=alumni.view&mode=view&id=".$r['id']."",$key2));?>">lihat</a></td>
		</tr><!-- Table Row -->
	<?$i=$i+1;}?>
	
	
		

	</tbody>
	<!-- Table Body -->

</table>