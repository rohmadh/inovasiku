<?
$s=$_GET['q'];
$cari="%$s%";
#$q="select * from keu_mastertagihan where status='1' and (nim=:s or nama like :cari)";
$q="select *,month(thn) as bulan,date(thn) as dtgl from keu_mastertagihan where (va1 like :cari or nama like :cari) and year(thn)='".$_SESSION['thn']."' 
order by month(thn) ASC";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->bindValue(':cari', $cari, PDO::PARAM_STR);
$stmt->bindValue(':s', $s, PDO::PARAM_STR);
$stmt->execute();
?>
<table>

<?
while ($row = $stmt->fetch()) {
?>							
<tr>
<td>
<?echo txthtml($row['nama']).'-['.txthtml($row['va1']).']';?>
</td><td>-<?echo txthtml(bulan($row['bulan']));?>-<?echo $_SESSION['thn'];?> <input type="button" onclick="pilih('<?echo txthtml($row['nama']);?>','<?echo txthtml($row['va1']);?>','<?echo txthtml($row['va2']);?>','<?echo txthtml($row['id']);?>','<?echo txthtml($row['bulan']);?>','<?echo txthtml($row['dtgl']);?>');gettagihan(<?echo txthtml($row['id']);?>);" value="ok"></td>
</tr>
<?}?>
</table>
<?$conn = null;?>
<script>
function pilih(n,i,i2,d,b,t){
$("#dari").val(n);
$("#klien").html('');
$("#idklien").val(i);
$("#idklien2").val(i2);
$("#idtag").val(d);
$("#bln").val(b);
$("#dtgl").val(t);
refreshtabel();
}
</script>
<script>
function gettagihan(q) {
		var x = $("#q").val();
		$("#klien").html("<b>Loading data....</b>");
        $.ajax({url: 'App/api.php?m=keu.tagihan.murid&mode=one&murid='+q, success: function(result){
            $("#klien").html(result);
        }});
    }
</script>