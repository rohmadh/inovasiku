<?
####hapus
$no=$_GET['id'];
$q="select * from keu_transaksi 
left join murid on keu_transaksi.klien=murid.nim
where notransaksi=:no and murid.nim!=''";
$stmt = $conn->prepare($q);
$stmt->bindValue(':no', $no, PDO::PARAM_STR);
$stmt->execute();
$row = $stmt->fetch();
#echo txthtml($row['kodeakun']);
$conn = null;
?>
<script>
$("#mode").val('edit');
$("#akun").val('<?echo txthtml($row['kodeakun']);?>');
$("#ket").val('<?echo txthtml($row['ket']);?>');
$("#jml").val('<?echo txthtml($row['jml']);?>');
$("#idklien").val('<?echo txthtml($row['klien']);?>');
$("#dari").val('<?echo txthtml($row['nama']);?>');
$("#idd").val('<?echo txthtml($row['notransaksi']);?>');
</script>