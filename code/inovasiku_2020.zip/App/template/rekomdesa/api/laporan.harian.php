<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

<?
$q="SELECT keu_transaksi.waktu as wkt,murid.nama,murid.kelas,
sum(case when keu_transaksi.kodeakun='0001' then jml else 0 end) as spp,
sum(case when keu_transaksi.kodeakun='0002' then jml else 0 end) as extra,
sum(case when keu_transaksi.kodeakun='0003' then jml else 0 end) as infaq,
sum(case when keu_transaksi.kodeakun='0004' then jml else 0 end) as kbm, 
sum(case when keu_transaksi.kodeakun='0005' then jml else 0 end) as anjem,
sum(case when keu_transaksi.kodeakun='0006' then jml else 0 end) as catering,
sum(case when keu_transaksi.kodeakun='0007' then jml else 0 end) as atkbuku,
sum(case when keu_transaksi.kodeakun='0008' then jml else 0 end) as jamiyyah
FROM keu_transaksi
left join murid on keu_transaksi.klien=murid.nim
where murid.nim !=''
group by murid.nim";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
?>

<center>
<h2>REKAPITULASI HARIAN PENERIMAAN<br />
Tahun <?echo $_SESSION['thn'];?>
</h2>
</center>
<table class="table" width="100%" class="table table-striped table-bordered table-hover" id="dataTables">
<tr>
<th>Nama</th><th>Kelas</th><th>SPP</th><th>EXTRA MANDIRI</th><th>INFAQ</th><th>KBM</th><th>ANJEM</th><th>KATERING</th><th>ATK-BUKU</th><th>JAMIYYAH</th><th>JUMLAH</th>
</tr>

<?
$a=0;$b=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;$i=0;
while ($row = $stmt->fetch()) {
?>
<tr>
<td style='text-align:left;'><?echo txthtml($row['nama']);?></td>
<td><?echo txthtml($row['kelas']);?></td><td><?echo txthtml(uang($row['spp']));?></td><td><?echo txthtml(uang($row['extra']));?></td><td><?echo txthtml(uang($row['infaq']));?></td>
<td><?echo txthtml(uang($row['kbm']));?></td><td><?echo txthtml(uang($row['anjem']));?></td><td><?echo txthtml(uang($row['katering']));?></td>
<td><?echo txthtml(uang($row['atk']));?></td><td><?echo txthtml(uang($row['jamiyyah']));?></td>
<td><?echo txthtml(uang($row['spp']+$row['extra']+$row['infaq']+$row['kbm']+$row['anjem']+$row['katering']+$row['atk']+$row['jamiyyah']));?></td>
</tr>
<?
$a=$a+$row['spp'];$b=$b+$row['extra'];$c=$c+$row['infaq'];$d=$d+$row['kbm'];$e=$e+$row['anjem'];$f=$f+$row['katering'];$g=$g+$row['atk'];
$h=$h+$row['jamiyyah'];$i=$i+($row['spp']+$row['extra']+$row['infaq']+$row['kbm']+$row['anjem']+$row['katering']+$row['atk']+$row['jamiyyah']);
}?>
<tr>
<td style='text-align:left;'><?echo txthtml("TOTAL");?></td>
<td><?echo txthtml($row['kelas']);?></td><td><?echo txthtml(uang($a));?></td><td><?echo txthtml(uang($b));?></td><td><?echo txthtml(uang($c));?></td>
<td><?echo txthtml(uang($d));?></td><td><?echo txthtml(uang($e));?></td><td><?echo txthtml(uang($f));?></td>
<td><?echo txthtml(uang($g));?></td><td><?echo txthtml(uang($h));?></td>
<td><?echo txthtml(uang($i));?></td>
</tr>

<?$conn = null;?>
</table>
<script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>