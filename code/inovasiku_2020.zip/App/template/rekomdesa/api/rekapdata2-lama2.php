<?
mysql_query("truncate table laporankendali2");
mysql_query("
insert into laporankendali2 (idprog,idkeg,uraian,gv,tu,ls,panjar,lalu,ini,sdini)
SELECT program.id as idprog,tblspj.idkeg,txtkegiatan,
sum(case when tipespj='1' then jml else 0 end) as j1,
sum(case when tipespj='2' then jml else 0 end) as j2,
sum(case when tipespj='3' then jml else 0 end) as j3,
0,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj.tgl,'%d/%m/%Y'))<month(now())) then jml else 0 end) as lalu,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj.tgl,'%d/%m/%Y'))=month(now())) then jml else 0 end) as ini,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj.tgl,'%d/%m/%Y'))<=month(now())) then jml else 0 end) as sdini 
from tblspj 
left join tblkegiatan on tblkegiatan.id=tblspj.idkeg
left join program on tblkegiatan.kprogram=program.id
where program.tahun='".$_SESSION['thn']."'
group by tblspj.idkeg
");
mysql_query("
insert into laporankendali2 (idprog,idkeg,uraian,panjar)
SELECT kprogram,tblpanjar.idkeg,txtkegiatan,sum(tblpanjar.npanjar) as jpanjar 
FROM `tblpanjar`
left join tblkegiatan on tblkegiatan.id=tblpanjar.idkeg
left join program on tblkegiatan.kprogram=program.id
where program.tahun='".$_SESSION['thn']."'
group by idkeg
");
mysql_query("
insert into laporankendali2 (idprog,idkeg,uraian,angg)
SELECT tblkegiatan.kprogram,idkeg, txtkegiatan,sum(tw1+tw2+tw3+tw4) as angg
FROM `tblpenyediaandana`
left join tblkegiatan on tblkegiatan.id=tblpenyediaandana.idkeg
left join program on tblkegiatan.kprogram=program.id
where program.tahun='".$_SESSION['thn']."'
group by idkeg
");
?>