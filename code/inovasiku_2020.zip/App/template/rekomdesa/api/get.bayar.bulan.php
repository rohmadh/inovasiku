<?
$q="
SELECT kode2,sum(jml) as bayar
FROM keu_rincian_potong_trxbank
where kode2='".$_GET['k']."'
GROUP BY kode2
";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
$row = $stmt->fetch();
if($row['bayar']==''){echo "0";}else{echo uang($row['bayar']);}

?>

