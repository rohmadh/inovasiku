<?

#echo count($cars);
if($_GET['mode']=='one'){
$q="SELECT *,spp+pendukung+extra+kbm+infaq+jamiyah+atk+bukupaket+seragam+anjem+catering+osis+lain as jml from keu_mastertagihan
where id='".$_GET['murid']."'
";
$stmt = $conn->prepare($q);
$stmt->execute();
}else{
$q="SELECT *,spp+pendukung+extra+kbm+infaq+jamiyah+atk+bukupaket+seragam+anjem+catering+osis+lain as jml from keu_mastertagihan

";
$stmt = $conn->prepare($q);
$stmt->execute();
}
### index data
$x=0;
?>

<style>

* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
  font-size:9pt;
  font-family:"Courier New", Courier, monospace;
  float: left;
  width: 50%;
  padding: 10px;
  height: 450px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>


<div class="row">
<?$box=1;while ($row = $stmt->fetch()) { 
##### ambil tanggal
$qs="SELECT *,date(thn) as dmy, day(thn) as tgl,month(thn) as bln, year(thn) as tahun
FROM keu_mastertagihan
where id='".$row['id']."'
";
$stmts = $conn->prepare($qs);
$stmts->execute();
$rowtgl = $stmts->fetch();
##
########### sisa tagihan
$qs="SELECT id,nama,va1,va2,sum(spp)-sum(bspp) as ba,sum(pendukung)-sum(bpendukung) as bb, sum(extra)-sum(bextra) as bc,
sum(kbm)-sum(bkbm) as bd,sum(infaq)-sum(binfaq) as be,sum(jamiyah)-sum(bjamiyah) as bf,
sum(atk)-sum(batk) as bg,sum(bukupaket)-sum(bbukupaket) as bh, 
sum(seragam)-sum(bseragam) as bi,sum(anjem)-sum(banjem) as bj, sum(catering)-sum(bcatering) as bk, sum(osis)-sum(bosis) as bl, 
sum(lain)-sum(blain) as bm,
sum(spp+pendukung+extra+kbm+infaq+jamiyah+atk+bukupaket+seragam+anjem+catering+osis+lain)-
sum(bspp+bpendukung+bextra+bkbm+binfaq+bjamiyah+batk+bbukupaket+bseragam+banjem+bcatering+bosis+blain) as btagih,
month(thn) as bulan,year(thn) as tahun 
FROM keu_mastertagihan
where thn<'".$rowtgl['thn']."' and (va1='".$rowtgl['va1']."' and va2='".$rowtgl['va2']."')
group by va1
order by nama,bulan,tahun ASC
";
#echo $qs;
$stmts = $conn->prepare($qs);
$stmts->execute();
$rows = $stmts->fetch();
#echo $rowtgl['dmy'];
######### pembayaran sisa
$qb="select va,sum(jml) as sisabayar 
FROM keu_rincian_potong_trxbank
where kode='byrsisa' and pdate<'".$rowtgl['dmy']."' and (va='".$rowtgl['va1']."' or va='".$rowtgl['va2']."')
group by va
";
#echo $qs;
$stmtsb = $conn->prepare($qb);
$stmtsb->execute();
$rowsb = $stmtsb->fetch();
###


?>
  <div class="column" style="background-color:#;">
  
	Nama: <? echo $row['nama'];?><br/>
	Kelas: <? echo $row['kelas'];?><br />
	Bulan: <? echo bulan($rowtgl['bln']);?><br />
    <table width="100%" align="left" border="1" cellpadding="1" cellspacing="0">
	<tr>
	<th>Uraian</th><th>Jumlah</th>
	</tr>
	<?if($row['spp']>0){?>
	<tr>
	<td>SPP</td><td align="right"><?echo uang($row['spp']);?></td>
	</tr>
	<?}?>
	<?if($row['pendukung']>0){?>
	<tr>
	<td>Pendukung</td><td align="right"><?echo uang($row['pendukung']);?></td>
	</tr>
	<?}?>
	<?if($row['extra']>0){?>
	<tr>
	<td>Extra</td><td align="right"><?echo uang($row['extra']);?></td>
	</tr>
	<?}?>
	<?if($row['kbm']>0){?>
	<tr>
	<td>KBM</td><td align="right"><?echo uang($row['kbm']);?></td>
	</tr>
	<?}?>
	<?if($row['infaq']>0){?>
	<tr>
	<td>Infaq</td><td align="right"><?echo uang($row['infaq']);?></td>
	</tr>
	<?}?>
	<?if($row['jamiyah']>0){?>
	<tr>
	<td>Jamiyah</td><td align="right"><?echo uang($row['jamiyah']);?></td>
	</tr>
	<?}?>
	<?if($row['atk']>0){?>
	<tr>
	<td>ATK</td><td align="right"><?echo uang($row['atk']);?></td>
	</tr>
	<?}?>
	<?if($row['bukupaket']>0){?>
	<tr>
	<td>Buku Paket</td><td align="right"><?echo uang($row['bukupaket']);?></td>
	</tr>
	<?}?>
	<?if($row['seragam']>0){?>
	<tr>
	<td>Seragam</td><td align="right"><?echo uang($row['seragam']);?></td>
	</tr>
	<?}?>
	<?if($row['anjem']>0){?>
	<tr>
	<td>Antar Jemput</td><td align="right"><?echo uang($row['anjem']);?></td>
	</tr>
	<?}?>
	<?if($row['catering']>0){?>
	<tr>
	<td>Katering</td><td align="right"><?echo uang($row['catering']);?></td>
	</tr>
	<?}?>
	<?if($row['osis']>0){?>
	<tr>
	<td>Osis</td><td align="right"><?echo uang($row['osis']);?></td>
	</tr>
	<?}?>
	<?if($row['lain']>0){?>
	<tr>
	<td>Lain2</td><td align="right"><?echo uang($row['lain']);?></td>
	</tr>
	<?}?>
	<tr>
	<td><b>- Tagihan </b></td><td align="right"><b><?echo uang($row['jml']);?></b></td>
	</tr>
	<tr>
	<td><b>- Sisa Tagihan Sebelumnya</b></td><td align="right"><b><input type='hidden' id='utang' value='<?echo ($rows['btagih']-$rowsb['sisabayar']);?>'><?echo uang($rows['btagih']-$rowsb['sisabayar']);?></b></td>
	</tr>
	<tr>
	<tr>
	<td><b>Total Tagihan</b></td><td align="right"><b><?echo uang($row['jml']+($rows['btagih']-$rowsb['sisabayar']));?></b></td>
	</tr>
	
	<td colspan="2">Ket: Abaikan jika sudah membayar</td>
	</tr>
	</table>
  </div>
  
<?$box=$box+1;}?>
</div>


