<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>Kode</th><th>PROGRAM/KEGIATAN</th><th>KEGIATAN</th><th>Tri Wulan I</th><th>Tri Wulan II</th><th>Tri Wulan III</th><th>Tri Wulan IV</th>
							</tr>
<?$q=mysql_query("select * from master where (kode !='' and kprog!='')or (kode !='' and kkeg!='') order by kode ASC");
							while($r=mysql_fetch_array($q)){
							
							?>
							<tr>
							<td><?echo htmlspecialchars($r[kode]);?></td>
							<td style="font-weight:bold;"><?echo htmlspecialchars($r[kprog]);?></td>
							<td><?echo htmlspecialchars($r[kkeg]);?></td>
							<td><?echo htmlspecialchars(uang($r[tw1]));?></td>
							<td><?echo htmlspecialchars(uang($r[tw2]));?></td>
							<td><?echo htmlspecialchars(uang($r[tw3]));?></td>
							<td><?echo htmlspecialchars(uang($r[tw4]));?></td>
							</tr>
							<?}?>
</table>
<script>
function pilihkeg(k) {
var txt = $("#txt"+k+"").text();
$("#namakeg").val(txt);
$("#idkeg").val(k);
$("#targetlistkeg").html('');
}
</script>