<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>NO</th><th>NAMA KEGIATAN</th><th>Angg</th><th>BAGIAN</th><?if($_SESSION['iduser']==0){?><th>PROSES</th><?}?>
							</tr>
<?
$q=mysql_query("select *,tbl_keg_bagian.id as idd from master 
left join tbl_keg_bagian on tbl_keg_bagian.koderek=master.kode
left join pengguna on tbl_keg_bagian.kodeuser=pengguna.id
where tbl_keg_bagian.kodeuser='".$_GET['kuser']."' and master.tahun='".$_SESSION['thn']."' and tbl_keg_bagian.tahun='".$_SESSION['thn']."' order by tbl_keg_bagian.kodeuser ASC");echo mysql_error();
							$n=1;
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><?echo htmlspecialchars($n);?></td>
							<td>
							[<?echo htmlspecialchars($r['kode']);?> ]
							<div id="txt<?echo $r['idd'];?>" <?if($r['status']=='0'){?>style='color:red;'<?}?>><?echo htmlspecialchars($r['kkeg']);?></div></td>
							<td>Rp.<?echo htmlspecialchars(uang($r['angg']));?></td>
							<td><?echo htmlspecialchars($r['nama']);?></td>
							<?if($_SESSION['iduser']==0){?>
							<td>
							
							<a href="#" onclick="editk('<?echo $r['idd'];?>','<?echo $r['kodeuser'];?>','<?echo $r['kode'];?>');">EDIT</a>,
							<a href="#" onclick="delk('<?echo $r['idd'];?>');">HAPUS</a>
							
							</td><?}?>
							</tr>
							
							<?$n=$n+1;}?>
</table>
<script>
function editk(k,l,m) {
$("#kodebag").val(l);
$("#kodekeg").val(m);
$("#iddata").val(k);
$("#mode").val('edit');
}
</script>