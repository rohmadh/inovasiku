<?

if($_GET['mode']=='save'){
mysql_query("update setting set nbendahara='".$_GET['namab']."',npenggunaangg='".$_GET['namapa']."',nipbend='".$_GET['nipb']."',nippa='".$_GET['nippa']."' where user='".$_SESSION['iduser']."'");
}
?>