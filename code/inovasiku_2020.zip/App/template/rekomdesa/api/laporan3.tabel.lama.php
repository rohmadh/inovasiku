<table class="table">
<tr>
<th>Tanggal</th><th>Kode Rekening</th><th>Uraian</th><th>Penerimaan</th><th>Pengeluaran</th>
</tr>
<?
$tb=mysql_escape_string($_GET['tb']);
$ta=mysql_escape_string($_GET['ta']);
$a=0;$b=0;	
$q=mysql_query("select * from tblspj 
left join tblkegiatan on tblspj.idkeg=tblkegiatan.id
left join program on tblkegiatan.kprogram=program.id
where (str_to_date(tgl,'%d/%m/%Y')) between str_to_date('".$ta."','%d/%m/%Y') and str_to_date('".$tb."','%d/%m/%Y') 
and program.status='1'
order by tgl ASC");
echo mysql_error();
while($r=mysql_fetch_array($q)){?>
<tr>
<td><? echo $r['tgl'];?></td><td></td><td><? echo htmlspecialchars($r['uraian']);?></td><td></td><td style='text-align:right;'><? echo uang($r['jml']);?></td>
</tr>

<?if($r['pajak']>0){?>
<tr>
<td><? echo $r['tgl'];?></td><td></td><td>Diterima Pajak-<? echo htmlspecialchars($r['uraian']);?></td><td style='text-align:right;'><? echo uang($r['pajak']);?></td><td style='text-align:right;'><? echo uang(0);?></td>
</tr>
<tr>
<td><? echo $r['tgl'];?></td><td></td><td>Dikeluarkan Pajak-<? echo htmlspecialchars($r['uraian']);?></td><td style='text-align:right;'><? echo uang(0);?></td><td style='text-align:right;'><? echo uang($r['pajak']);?></td>
</tr>
<?}?>

<?
$a=$a+$r['pajak'];
$b=$b+$r['jml']+$r['pajak'];
}?>
<tr>
<td></td><td></td><td>Total</td><td style='text-align:right;'><? echo uang($a);?></td><td style='text-align:right;'><? echo uang($b);?></td>
</tr>
</table>