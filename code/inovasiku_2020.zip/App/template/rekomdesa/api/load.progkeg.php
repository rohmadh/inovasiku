<?
if($_GET['id']){
$q=mysql_query("select * from tblpanjar where id='".$_GET['id']."' ");
$r=mysql_fetch_array($q);
$qk=mysql_query("select * from master where kode='".$r['idkeg']."'");
$rk=mysql_fetch_array($qk);
$qp=mysql_query("select * from master where kode='".substr($r['idkeg'],0,6)."'");
$rp=mysql_fetch_array($qp);
}
?>
<script>
$("#idkeg").val('<?echo $r['idkeg'];?>');
$("#idprog").val('<?echo substr($r['idkeg'],0,6);?>');
$("#namakeg").val('<?echo $rk['kkeg'];?>');
$("#namaprog").val('<?echo $rp['kprog'];?>');
</script>