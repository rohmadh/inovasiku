<?
if($_GET['ide']>0){
$q="select * from pendaftar where id_event='".$_GET['ide']."'";
$stmt = $conn->prepare($q);
$stmt->execute();
while($row1=$stmt->fetch()){
		$q="select * from juri where id_event='".$_GET['ide']."'";
		$stmt3 = $conn->prepare($q);
		$stmt3->execute();
		while($row2=$stmt3->fetch()){
			$q="
			insert into data (id_event,id_usr,id_juri,id_var)
			SELECT id_event,'".$row1['id']."','".$row2['id']."',id FROM var_penilaian WHERE id_event='".$_GET['ide']."' and formdaftar=0
			";
			$stmt2 = $conn->prepare($q);
			$stmt2->execute();
			}
	}
}
$conn = null;
?>