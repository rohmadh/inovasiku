<?
$q="
insert into keu_rincian_potong_trxbank (noinv,va,kode,kode2,ket,jml,pdate,wkt,sts)
select noinv,va,kode,kode2,ket,-(jml),pdate,wkt,'r' from keu_rincian_potong_trxbank where id='".$_GET['k']."'
";
$stmt = $conn->prepare($q);
$stmt->execute();
#####
$q="
update keu_mastertagihan set b".$_GET['kode']."=(b".$_GET['kode']."-".$_GET['jml'].") where id='".$_GET['idt']."'
";
$stmt = $conn->prepare($q);
$stmt->execute();
#####
$conn = null;
?>