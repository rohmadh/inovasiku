<?
$data=explode(':',$_GET['k']);
$q="select (".$data['1']."-b".$data['1'].") as stag from keu_mastertagihan where id='".$data['0']."'";
$stmt = $conn->prepare($q);
$stmt->execute();
$row = $stmt->fetch();
?>
<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                       <div class="panel-heading">
                            TRX PEMBAYARAN MURID - <input type="text" id="noinv" value="mtx<?echo time();?>" disabled style="border:none;">
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<b>Jumlah Tagihan <?echo $data['1'];?></b> <input type="text" class="form-control2" id="jml" value="<?echo strtoupper($row['stag']);?>">
							<input type="button" class="button" value="SIMPAN" id="" onclick="savebayaritem();">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			

<div class="table-responsive" id="idtarget">                              
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>

<script>
function savebayaritem() {
		
		var va1=$("#tva1").val();
		var noinv=$("#noinv").val();
		var jml=$("#jml").val();
        $.ajax({url: 'App/api.php?m=keu_input_item&mode=save&va1='+va1+'&jml='+jml+'&noinv='+noinv+'&k=<?echo $data['0'];?>&kode=<?echo $data['1'];?>', success: function(result){
            alert('DATA TERSIMPAN...');
			$("#frmbayaritem").hide();

        }});
    }
</script>
