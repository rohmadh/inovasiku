<?
if($_GET['k']){
$q=mysql_query("select (tw1+tw2+tw3+tw4) as nspd from tblpenyediaandana where idkeg='".$_GET['k']."' and koderekbelanja='".$_GET['rek']."'");
$r=mysql_fetch_array($q);
echo htmlspecialchars($r['nspd']);
}
?>