<?
#$q="select * from data where id_event='1' order by id ASC";
$q="SELECT *
from pendaftar where id_event='".$_GET['ide']."'
";
$stmt = $conn->prepare($q);
$stmt->execute();
#####
$q2="SELECT *
from juri where id_event='".$_GET['ide']."'
";
$stmt2 = $conn->prepare($q2);
$stmt2->execute();
###
$q3="SELECT *
from kelompok_event where id='".$_GET['ide']."'
";
$stmt3 = $conn->prepare($q3);
$stmt3->execute();
$row3=$stmt3->fetch();
$tipeblok=array('success','info','warning','danger');
$lapprint="rincian.skor";
?>

<table width="100%" cellpadding="2" cellspacing="2" border="0">

<tr>
<td colspan="3"><div class="alert alert-success">Informasi Peserta "<?echo txthtml($row3['nama']);?>"</div></td>
</tr>
<tr>
<td>Penilai</td><td>:</td>
<td>
<select class="form-control" id="idjuri">
<option value="0000">...PILIH PENILAI...</option>
<?while($row=$stmt2->fetch()){?>
<option value="<?echo $row['id'];?>"><?echo $row['nama_juri'];?></option>
<?}?>
</select>
</td>
</tr>
<tr>
<tr>
<td>Nama Peserta</td><td>:</td>
<td>
<select class="form-control" id="idp" onchange="getpesertainfo();">
<option value="0000">...PILIH PESERTA...</option>
<?while($row=$stmt->fetch()){?>
<option value="<?echo $row['id'];?>"><?echo $row['nama'];?></option>
<?}?>
</select>
</td>
</tr>
<td>Judul</td><td>:</td><td>
<textarea class="form-control" style="width:95%;height:100px;" id="judul"></textarea>
</td>
</tr>
<tr>
<td>Deskripsi</td><td>:</td><td><textarea class="form-control" style="width:95%;height:100px;" id="deskripsi"></textarea>
<br />
<input type="button" value="cetak" onclick="loadp();">
</td>
</tr>

</table>
<div id='proses'></div>
<br />
<br />
<txt id='formpenilaian'></txt>
<script>
function getpesertainfo() {	
		var idp=$("#idp").val();
		var data={'idp':idp};
		$("#proses").html('..GET DATA..');
		
        $.ajax({url: 'App/<?echo $base;?>/api.php?m=peserta.info',type:'get',data:data, success: function(result){
            $("#proses").html(result);
        }});
		loadfrmpeserta(idp);
    }
</script>
<script>
function loadfrmpeserta(k) {	
		var idj=$("#idjuri").val();
		$("#txtheader").html('PENILAIAN PESERTA');
		$("#proses").html('..LOADING..');
        $.ajax({url: 'App/<?echo $base;?>/api.php?m=form.penilaian.peserta&idp='+k+'&idj='+idj, success: function(result){
            $("#formpenilaian").html(result);
        }});
    }
</script>
<script>
function loadp() {
		var idp=$("#idp").val();
		var idj=$("#idjuri").val();
		window.open("./?action=print&idp="+idp+"&idj="+idj+"&page=<?echo $lapprint;?>", "_blank");
    }
</script>	