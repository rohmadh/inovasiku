<div class="row" id='formspj'>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT SPJ
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>REKENING BELANJA</label></td><td><label>:</label></td><td><input name="nama" id="rekbelanja" class="form-controls" type="text" size="100" disabled><input type="hidden" id="idrek" value="">
							<br />
							<div id="targetlistrekbelanja"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qr" ><input type="button" value="CARI" onclick='getlrek();'></td>
							</tr>
							
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>TANGGAL </label></td><td><label>:</label></td><td><input name="tgl" id="tgl" type="text" size="20">
							<label>NO. SPJ </label> <input name="tgl" id="nospj" type="text" size="35">
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>JENIS SPJ  </label></td><td><label>:</label></td><td>
							<select id='jspj'>
							<option value='0'>...PILIH...</option>
							<option value='1'>GU</option>
							<option value='2'>TU</option>
							<option value='3'>LS</option>
							</select>
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>KETERANGAN </label></td><td><label>:</label></td><td><input name="nama" id="ket" type="text" size="80">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>NILAI RUPIAH </label></td><td><label>:</label></td><td>Rp.<input name="nama" id="jml" type="text" size="30">
							Pembayaran:
							<select id='jbayar'>
							<option value='0'>...PILIH...</option>
							<option value='tunai'>TUNAI</option>
							<option value='bank'>BANK</option>
							
							</select>
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>PAJAK Ke 1</label></td><td><label>:</label></td><td>
							<select id='jpajak'>
							<option value='0'>...PILIH...</option>
							<?$q=mysql_query("select * from jenispajak");while($r=mysql_fetch_array($q)){?>
							<option value='<?echo $r['id'];?>'><?echo $r['txtpajak'];?></option>
							<?}?>
							
							</select>
							Rp.<input name="nama" id="pajak" type="text" size="30">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>PAJAK Ke 2 </label></td><td><label>:</label></td><td>
							<select id='jpajak2'>
							<option value='0'>...PILIH...</option>
							<?$q=mysql_query("select * from jenispajak");while($r=mysql_fetch_array($q)){?>
							<option value='<?echo $r['id'];?>'><?echo $r['txtpajak'];?></option>
							<?}?>
							
							</select>
							Rp.<input name="nama" id="pajak2" type="text" size="30">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>PAJAK Ke 3</label></td><td><label>:</label></td><td>
							<select id='jpajak3'>
							<option value='0'>...PILIH...</option>
							<?$q=mysql_query("select * from jenispajak");while($r=mysql_fetch_array($q)){?>
							<option value='<?echo $r['id'];?>'><?echo $r['txtpajak'];?></option>
							<?}?>
							
							</select>
							Rp.<input name="nama" id="pajak3" type="text" size="30">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td>
							</td><td></td><td><input type="button" value="SIMPAN" id="btninputpanjar" onclick="inputspj();setawal();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<script>
function inputspj() {
		var mode=$("#mode").val();
		var idkeg=$("#idkeg").val();
		var idrek=$("#idrek").val();
		var tgl=$("#tgl").val();
		var nospj=$("#nospj").val();
		var jenis=$("#jspj").val();
		var ket=$("#ket").val();
		var jml=$("#jml").val();
		var jbayar=$("#jbayar").val();
		var idpanjar=$("#idpanjar").val();
		var pajak=$("#pajak").val();
		var jpajak=$("#jpajak").val();
		var pajak2=$("#pajak2").val();
		var jpajak2=$("#jpajak2").val();
		var pajak3=$("#pajak3").val();
		var jpajak3=$("#jpajak3").val();
        $.ajax({url: 'App/api.php?m=spj.input&mode='+mode+'&idkeg='+idkeg+'&idrek='+idrek+'&idpanjar='+idpanjar+'&tgl='+tgl+'&nospj='+nospj+'&jenis='+jenis+'&ket='+ket+'&jml='+jml+'&jbayar='+jbayar+'&pajak='+pajak+'&jpajak='+jpajak+'&pajak2='+pajak2+'&jpajak2='+jpajak2+'&pajak3='+pajak3+'&jpajak3='+jpajak3, success: function(result){
            alert('DATA TERSIMPAN...');
			refreshtabel();
			getdatapanjar();
        }});
    }
function setawal() {
$("#jspj").val(0);
$("#ket").val('');
$("#jml").val('');
$("#pajak").val('');
}
</script>
<script>
function getlrek() {
		$("#targetlistrekbelanja").html('<h1>...LOADING...</h1>');
		var k=$("#qr").val();
		var idkeg=$("#idkeg").val();
        $.ajax({url: 'App/api.php?m=list.rekbelanja.spj&mode=getspd&idkeg='+idkeg+'&q='+k, success: function(result){
            $("#targetlistrekbelanja").html(result);
        }});
    }
</script>
<script>
function refreshtabel() {
		var k=$("#idkeg").val();
        $.ajax({url: 'App/api.php?m=spj.tabel&idkeg='+k, success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>

  <script>
  $( function() {
    $( "#tgl" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
  } );
  </script>
  <script>$("#idpanjar").val('<?echo $_GET['id'];?>');refreshtabel();</script>