<?
if($_POST['mode']=='insert'){
$q="
insert into kelompok_event (id_grup,nama,uraian,date1,date2,status) values ('".$_POST['idg']."','".$_POST['namaevent']."','".$_POST['descevent']."',
'".$_POST['d1']."','".$_POST['d2']."','".$_POST['status']."')
";

}
$stmt = $conn->prepare($q);
$stmt->execute();
$conn = null;
?>