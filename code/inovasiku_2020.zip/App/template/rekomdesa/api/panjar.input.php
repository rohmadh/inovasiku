<?
if($_GET['mode']=='save'){
if(($_GET['idkeg']=='')or($_GET['npanjar']=='')or($_GET['tgl']=='')){ echo"...MOHON PILIH PROGRAM KEGIATAN DAN LENGKAPI FORM";}else{
mysql_query("insert into tblpanjar (idkeg,jenispanjar,npanjar,tgl,ket,user,tahun) values('".$_GET['idkeg']."','".$_GET['jp']."','".$_GET['npanjar']."','".$_GET['tgl']."','".$_GET['ket']."','".$_SESSION['iduser']."','".$_SESSION['thn']."') ");
echo "...DATA TERSIMPAN...";
}
}
if($_GET['mode']=='edit'){
mysql_query("update tblpanjar set idkeg='".$_GET['idkeg']."',jenispanjar='".$_GET['jp']."',npanjar='".$_GET['npanjar']."',tgl='".$_GET['tgl']."',ket='".$_GET['ket']."' where id='".$_GET['idpanjar']."' ");
}
if($_GET['mode']=='del'){
mysql_query("delete from tblpanjar where id='".$_GET['id']."'");
}
?>