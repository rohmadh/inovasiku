<?
if($_POST['mode']=='update'){
$eror=0;
### cek
if(strlen($_POST['username'])<6){$eror=1;$msg="USERNAME KURANG DARI 6 KARAKTER";}
if(strlen($_POST['password'])<6){$eror=1;$msg .=";PASSWORD KURANG DARI 6 KARAKTER";}
if($eror==0){
$q1="update keu_pengguna set nama='".$_POST['nama']."' ,nip='".$_POST['username']."',passwd='".md5($_POST['password'])."' where id='".$_POST['id']."'";
$stmt = $conn->prepare($q1);
$stmt->execute();
echo "DATA TERSIMPAN";
}else{
###
echo $msg;
}
}
$conn = null;
?>