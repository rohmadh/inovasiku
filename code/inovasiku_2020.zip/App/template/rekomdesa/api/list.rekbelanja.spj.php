<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>REKENING BELANJA</th><th>PILIH</th>
							</tr>
<?$no=1;$q=mysql_query("select * from master where krek4 !='' and kode like'".$_GET['idkeg']."%' and krek4 like'%".$_GET['q']."%' and tahun='".$_SESSION['thn']."' order by kode ASC");
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><?echo $r['kode'];?>.<div id="txt<?echo $no;?>"><?echo htmlspecialchars($r['krek4']);?></div></td><td><input type="button" value="PILIH" onclick="pilihrekbelanja('<?echo $no;?>','<?echo $r['kode'];?>');"></td>
							</tr>
							
							<?$no=$no+1;}?>
</table>
<script>
function pilihrekbelanja(k,p) {
var txt = $("#txt"+k+"").text();
$("#rekbelanja").val(txt);
$("#idrek").val(p);
$("#targetlistrekbelanja").html('');
<?
if($_GET['mode']=='getspd'){
?>
getnilaispd();
<?
}
?>
}
</script>