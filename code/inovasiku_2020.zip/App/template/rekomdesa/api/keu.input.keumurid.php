<?
###
include("config/db.php.inc");
$conn = mysqli_connect($serv, $user, "", $db);
###
####hapus
if($_GET['mode']=='hapus'){
$no=$_GET['id'];
$q="delete from keu_transaksi where notransaksi=:no";
$stmt = $conn->prepare($q);
$stmt->bindValue(':no', $no, PDO::PARAM_STR);
$stmt->execute();
$conn = null;
}
#####insert
if(($_GET['mode']=='save')and($_GET['kode']!='')){
echo $_GET['kode'];
####
$column[10]=$_GET['klien'];
#$column[1]=date('Y-m-d');
$column[1]=$_GET['tgl'];
$column[9]=$_GET['jml'];
$inv=$_GET['inv'];
$b=$_GET['b'];
$utang=$_GET['utang'];
#$b=12;
$prioritas=array("spp","pendukung","kbm","bukupaket");
$kodetag=$_GET['kode'];
if ($_GET['mode']=='save') {
				##### insert history
				$sqlhist="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','0010','".$column[1]."','CASH ".$_GET['ket']." a.n ".$_GET['nama']."','".$column[9]."')";
				$resulthist = mysqli_query($conn, $sqlhist);
				##### proses sequencing pembayaran bertingkat
				$a=0;
				$jmlpemb=0;
				$sisauang=$column[9];
				$flag=0;
				####get prioritas
				$sqlp="select * from keu_prioritas_tagihan order by no ASC";
				$resultp = mysqli_query($conn, $sqlp);
				#while($a<count($prioritas)){
				while($rowp=mysqli_fetch_array($resultp)){
				$prioritas[$a]=$rowp['kode'];
				###jika ada kode terpilih manual
				if(($kodetag!='')and($kodetag!='0000')){$prioritas[$a]=$kodetag;}
				#### cek sudah dibayar?
				$sqlcek="select ".$prioritas[$a]." as dt, b".$prioritas[$a]." as dc from keu_mastertagihan where va1='".$column[10]."' and month(thn)='".$b."' and year(thn)='" . $_SESSION['thn'] . "'";
				#echo $sqlcek;
				$resultc = mysqli_query($conn, $sqlcek);
				$dcek=mysqli_fetch_array($resultc);
				##if(($dcek['dc']==0)and($dcek['dt']>0)){
				if(($dcek['dc']<$dcek['dt'])and($dcek['dt']>0)){
				##echo "sisa-".$sisauang;
				#### ambil nilai tagihan
				$sqltagih="select ".$prioritas[$a].",b".$prioritas[$a]." from keu_mastertagihan where va1='".$column[10]."' and month(thn)='".$b."' and year(thn)='" . $_SESSION['thn'] . "'";
				##echo $sqltagih;
				$resultt = mysqli_query($conn, $sqltagih);
				$tagih=mysqli_fetch_array($resultt);
				##echo $tagih[0];
				### update bayar
				if(($sisauang>=($tagih['0']-$tagih['1']))and($flag==0)){
				$sqlbayar="update keu_mastertagihan set b".$prioritas[$a]."='".$tagih['0']."' where va1='".$column[10]."' and month(thn)='".$b."' and year(thn)='" . $_SESSION['thn'] . "'";
				##echo $sqlbayar;
				$resultb = mysqli_query($conn, $sqlbayar);
				#####isi rincian potong
				$sqlrincian="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','".$prioritas[$a]."','".$column[1]."','bayar-".$prioritas[$a]."','".($tagih['0']-$tagih['1'])."')";
				$resultr = mysqli_query($conn, $sqlrincian);
				#$sisauang=$sisauang-$tagih['0'];
				}
				if(($sisauang<($tagih['0']-$tagih['1']) and $sisauang>0)and($flag==0)){
				$flag=1;
				####isikan bayar sisanya semua
				$sql1="update keu_mastertagihan set b".$prioritas[$a]."='".$sisauang."' where va1='".$column[10]."' and month(thn)='".$b."' and year(thn)='" . $_SESSION['thn'] . "'";
				$resultr = mysqli_query($conn, $sql1);
				$sql2="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','".$prioritas[$a]."','".$column[1]."','bayar-".$prioritas[$a]."[kurang]','".$sisauang."')";
				$resultr = mysqli_query($conn, $sql2);
				$sqlrincian="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','0030','".$column[1]."','SALDO SISA KURANG-STOP','0')";
				$resultr = mysqli_query($conn, $sqlrincian);
				}
				}
				$a=$a+1;
				$sisauang=$sisauang-($tagih['0']-$tagih['1']);
				
				}
				###### jika ada sisa uang bayar sisa tagihan
				echo $sisauang;
				if($sisauang>0){
				if($sisauang>$utang){
				$sqlbayarsisa="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','byrsisa','".$column[1]."','Bayar Sisa Tagihan sebelumnya','".$utang."')";
				$resultbayarsisa = mysqli_query($conn, $sqlbayarsisa);}
				if($sisauang<$utang){
				$sqlbayarsisa="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','byrsisa','".$column[1]."','Bayar Sisa Tagihan sebelumnya','".$sisauang."')";
				$resultbayarsisa = mysqli_query($conn, $sqlbayarsisa);}
				}
				###
                $type = "success";
                $message = "CSV Data Imported into the Database";
            } else {
                $type = "error";
                $message = "Problem in Importing CSV Data";
            }
####
}

#####edit
if($_GET['mode']=='edit'){
$a=$_GET['kode'];
$b=$_GET['ket'];
$c=$_GET['jml'];
$klien=$_GET['klien'];
$not=$_GET['id'];
$q="update keu_transaksi set notransaksi=:not,klien=:klien,kodeakun=:kode,ket=:ket,jml=:jml where notransaksi=:not";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->bindValue(':not', $not, PDO::PARAM_STR);
$stmt->bindValue(':kode', $a, PDO::PARAM_STR);
$stmt->bindValue(':ket', $b, PDO::PARAM_STR);
$stmt->bindValue(':jml', $c, PDO::PARAM_INT);
$stmt->bindValue(':klien', $klien, PDO::PARAM_STR);
$stmt->execute();
$conn = null;
echo "<script>alert('..DATA TERSIMPAN..');</script>";
}

?>