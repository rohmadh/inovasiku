<?
if($_POST['mode']=='insert'){
$q="
insert into juri (id_event,nama_juri,status) values ('".$_POST['ide']."','".$_POST['nama']."','1')
";

}
$stmt = $conn->prepare($q);
$stmt->execute();
$conn = null;
?>