<?
#echo $q;
$q="update keu_mastertagihan set b".$_GET['kode']."=(b".$_GET['kode']."+".$_GET['jml'].") where id='".$_GET['k']."'";
$stmt = $conn->prepare($q);
$stmt->execute();
#$row = $stmt->fetch();
#######catat ke history
$q="select * from keu_mastertagihan where id='".$_GET['k']."'";
$stmt = $conn->prepare($q);
$stmt->execute();
$rtag = $stmt->fetch();
######
$q="insert into keu_rincian_potong_trxbank (va,noinv,kode,kode2,pdate,ket,jml) value ('".$rtag['va1']."','".$_GET['noinv']."','".$_GET['kode']."','".$_GET['k']."',now(),'Bayar ".$_GET['kode']."(".$rtag['thn'].") a.n ".$rtag['nama']."-[".$rtag['nama']."]','".$_GET['jml']."')";
$stmt = $conn->prepare($q);
$stmt->execute();
?>