<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 150%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<table align="center" id="customers">
  <tr>
    <th rowspan=2>No</th>
    <th rowspan=2>Nama</th>
    <th rowspan=2>Kelas</th>
    <th colspan=2>Jan</th>
    <th colspan=2>Feb</th>
    <th colspan=2>Mar</th>
    <th colspan=2>Apr</th>
    <th colspan=2>Mei</th>
    <th colspan=2>Jun</th>
    <th colspan=2>Jul</th>
    <th colspan=2>Ags</th>
    <th colspan=2>Sep</th>
    <th colspan=2>Okt</th>
    <th colspan=2>Nov</th>
    <th colspan=2>Des</th>
  </tr>
  <tr>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  </tr>
  <?php
  include("konek.php");
  if(isset($_GET['q'])){
  $query ="SELECT *,
  case when month(thn)=1 then infaq else 0 end as t1,
  case when month(thn)=1 then binfaq else 0 end as b1,
  case when month(thn)=2 then infaq else 0 end as t2,
  case when month(thn)=2 then binfaq else 0 end as b2,
  case when month(thn)=3 then infaq else 0 end as t3,
  case when month(thn)=3 then binfaq else 0 end as b3,
  case when month(thn)=4 then infaq else 0 end as t4,
  case when month(thn)=4 then binfaq else 0 end as b4,
  case when month(thn)=5 then infaq else 0 end as t5,
  case when month(thn)=5 then binfaq else 0 end as b5,
  case when month(thn)=6 then infaq else 0 end as t6,
  case when month(thn)=6 then binfaq else 0 end as b6,
  case when month(thn)=7 then infaq else 0 end as t7,
  case when month(thn)=7 then binfaq else 0 end as b7,
  case when month(thn)=8 then infaq else 0 end as t8,
  case when month(thn)=8 then binfaq else 0 end as b8,
  case when month(thn)=9 then infaq else 0 end as t9,
  case when month(thn)=9 then binfaq else 0 end as b9,
  case when month(thn)=10 then infaq else 0 end as t10,
  case when month(thn)=10 then binfaq else 0 end as b10,
  case when month(thn)=11 then infaq else 0 end as t11,
  case when month(thn)=11 then binfaq else 0 end as b11,
  case when month(thn)=12 then infaq else 0 end as t12,
  case when month(thn)=12 then binfaq else 0 end as b12
  FROM keu_mastertagihan where kelas like'%".$_GET['q']."%'
  order by b9 ASC
  ";
  $ambil = mysql_query ($query);
  $no=1;
  while($data=mysql_fetch_array($ambil)){


  echo "
  <tr>
    <td>$no</td>
    <td>$data[nama]</td>
    <td>$data[kelas]</td>
    <td>$data[t1]</td>
    <td>$data[b1]</td>
    <td>$data[t2]</td>
    <td>$data[b2]</td>
    <td>$data[t3]</td>
    <td>$data[b3]</td>
    <td>$data[t4]</td>
    <td>$data[b4]</td>
    <td>$data[t5]</td>
    <td>$data[b5]</td>
    <td>$data[t6]</td>
    <td>$data[b6]</td>
    <td>$data[t7]</td>
    <td>$data[b7]</td>
    <td>$data[t8]</td>
    <td>$data[b8]</td>
    <td>$data[t9]</td>
    <td>$data[b9]</td>
    <td>$data[t10]</td>
    <td>$data[b10]</td>
    <td>$data[t11]</td>
    <td>$data[b11]</td>
    <td>$data[t12]</td>
    <td>$data[b12]</td>

  </tr>";
  $no++;

}}
?>
</table>

</body>
</html>