<?
if($_GET['id']){
$q=mysql_query("select * from tblspj2 where id='".$_GET['id']."' ");
$r=mysql_fetch_array($q);
$qr=mysql_query("select * from master where kode='".$r['idrek']."'");
$rr=mysql_fetch_array($qr);
}
?>
<script>
$("#tgl").val('<?echo $r['tgl'];?>');
$("#nospj").val('<?echo $r['nospj'];?>');
$("#jspj").val('<?echo $r['tipespj'];?>');
$("#ket").val('<?echo $r['uraian'];?>');
$("#jml").val('<?echo $r['jml'];?>');
$("#jbayar").val('<?echo $r['jbayar'];?>');
$("#jpajak").val('<?echo $r['jpajak'];?>');
$("#pajak").val('<?echo $r['pajak'];?>');
$("#idrek").val('<?echo $r['idrek'];?>');
$("#idkeg").val('<?echo $r['idkeg'];?>');
$("#rekbelanja").val('<?echo $rr['krek4'];?>');
</script>