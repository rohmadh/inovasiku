<?
####hapus
if($_GET['mode']=='hapus'){
$no=$_GET['id'];
$q="delete from keu_transaksi where notransaksi=:no";
$stmt = $conn->prepare($q);
$stmt->bindValue(':no', $no, PDO::PARAM_STR);
$stmt->execute();
$conn = null;
}
#####insert
if($_GET['mode']=='save'){
$a=$_GET['kode'];
$b=$_GET['ket'];
$c=$_GET['jml'];
$klien=$_GET['klien'];
$not='02'.time();
$q="insert into keu_transaksi (notransaksi,klien,kodeakun,ket,jml) value (:not,:klien,:kode,:ket,:jml)";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->bindValue(':not', $not, PDO::PARAM_STR);
$stmt->bindValue(':kode', $a, PDO::PARAM_STR);
$stmt->bindValue(':ket', $b, PDO::PARAM_STR);
$stmt->bindValue(':jml', $c, PDO::PARAM_INT);
$stmt->bindValue(':klien', $klien, PDO::PARAM_STR);
$stmt->execute();
$conn = null;
echo "<script>alert('..DATA TERSIMPAN..');</script>";
}

#####edit
if($_GET['mode']=='edit'){
$a=$_GET['kode'];
$b=$_GET['ket'];
$c=$_GET['jml'];
$klien=$_GET['klien'];
$not=$_GET['id'];
$q="update keu_transaksi set notransaksi=:not,klien=:klien,kodeakun=:kode,ket=:ket,jml=:jml where notransaksi=:not";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->bindValue(':not', $not, PDO::PARAM_STR);
$stmt->bindValue(':kode', $a, PDO::PARAM_STR);
$stmt->bindValue(':ket', $b, PDO::PARAM_STR);
$stmt->bindValue(':jml', $c, PDO::PARAM_INT);
$stmt->bindValue(':klien', $klien, PDO::PARAM_STR);
$stmt->execute();
$conn = null;
echo "<script>alert('..DATA TERSIMPAN..');</script>";
}

?>