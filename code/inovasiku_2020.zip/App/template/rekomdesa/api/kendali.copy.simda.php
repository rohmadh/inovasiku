<?
if($_GET['mode']=='copy'){
mysql_query("delete from master where tahun='".$_SESSION['thn']."' ");
mysql_query("insert into master 
select * from master_import where tahun='".$_SESSION['thn']."'");
}
?>