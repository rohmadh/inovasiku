<?

if($_GET['k']){
$_SESSION['setprog']=$_GET['k'];
$_SESSION['txtprog']=$_GET['txt'];
}
?>