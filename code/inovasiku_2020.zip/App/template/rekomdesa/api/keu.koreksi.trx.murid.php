<?
$q="select * from keu_rincian_potong_trxbank where id='".$_GET['k']."'";
$stmt = $conn->prepare($q);
$stmt->execute();
$row = $stmt->fetch();
?>
<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                    </div>
                </div>

                <hr />
				<div class="row" style="position:fixed;z-index:1;display:block">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                       <div class="panel-heading">
                            KOREKSI TRX MURID
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><?echo $row['ket'];?> <? echo uang($row['jml']);?>
							<input type='text' id='kode' value="<?echo $row['kode']?>">
							<input type='text' id='jml' value="<?echo $row['jml']?>">
							<input type='text' id='idd' value="<?echo $row['id']?>">
							<input type='text' id='idt' value="<?echo $row['kode2']?>">
							</td><td></td>
							<td>
							
							</td>
							
							</tr>
							
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" class="button" value="KONFIRM" id="" onclick="savekoreksi();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			



<script>
function savekoreksi() {
		var k=$("#idd").val();
		var kode=$("#kode").val();
		var jml=$("#jml").val();
		var idt=$("#idt").val();
        $.ajax({url: 'App/api.php?m=keu.koreksi.trx&idt='+idt+'&kode='+kode+'&jml='+jml+'&k='+k, success: function(result){
            alert('DATA TERSIMPAN...');
			$("#frmkoreksi").hide();
			load1();
        }});
    }
</script>
