<?
if($_GET['mode']=='detail'){
$stmt = $conn->prepare("select * from rekomkkn where id=:idd");
$stmt->execute(array(':idd'=>$_GET['id']));
$r=$stmt->fetch();
?>
<script>
$("#tema").val('<?echo $r['tema'];?>');
$("#jmlklp").val('<?echo $r['klp'];?>');
$("#lokasi").val('<?echo $r['lokasi'];?>');
$("#univ").val('<?echo $r['univ'];?>');
$("#longlat").val('<?echo $r['longlat'];?>');
$("#status").val('<?echo $r['status'];?>');
$("#tipekkn").val('<?echo $r['tipekkn'];?>');
</script>
<?
}

$conn = null;
?>