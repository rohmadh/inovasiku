<?
$q="SELECT * FROM keu_kodeakun where kode like'101%' order by kode ASC";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
?>
<select id="akun">
<option value='0000'>--PILIH--</option>
<?
while ($row = $stmt->fetch()) {
?>							
<option value="<? echo txthtml($row['kode2']);?>">
<?echo txthtml($row['kode']).'-'.txthtml($row['uraian']);?>
</option>
<?$conn = null;}?>
</select>