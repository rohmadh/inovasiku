<?
if($_GET['password']=='rohmad'){
$q="
insert into keu_mastertagihan2 (va1,va2,kelas,nama,spp,pendukung,extra,kbm,infaq,jamiyah,atk,bukupaket,seragam,anjem,catering,osis,lain,creator)
select va1,va2,kelas,nama,
(select rupiah from keu_prioritas_tagihan where kode='spp') as spp,
(select rupiah from keu_prioritas_tagihan where kode='pendukung') as pendukung,
(select rupiah from keu_prioritas_tagihan where kode='extra') as extra,
(select rupiah from keu_prioritas_tagihan where kode='kbm') as kbm,
(select rupiah from keu_prioritas_tagihan where kode='infaq') as infaq,
(select rupiah from keu_prioritas_tagihan where kode='jamiyah') as jamiyah,
(select rupiah from keu_prioritas_tagihan where kode='atk') as atk,
(select rupiah from keu_prioritas_tagihan where kode='bukupaket') as bukupaket,
(select rupiah from keu_prioritas_tagihan where kode='seragam') as seragam,
(select rupiah from keu_prioritas_tagihan where kode='anjem') as anjem,
(select rupiah from keu_prioritas_tagihan where kode='catering') as catering,
(select rupiah from keu_prioritas_tagihan where kode='osis') as osis,
(select rupiah from keu_prioritas_tagihan where kode='lain') as lain,
'sistem'

from keu_master_vamurid where nama like'abdul%'
";
$stmt = $conn->prepare($q);
$stmt->execute();
$conn = null;
}else{echo "--DENIED--";}
?>