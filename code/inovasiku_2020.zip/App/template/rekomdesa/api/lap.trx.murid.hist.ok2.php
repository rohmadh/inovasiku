<script>
function loadbayar(t,k,v) {
		$("#tbayar"+t+"").html('<i>..load..</i>');
        $.ajax({url: 'App/api.php?m=get.bayar.bulan&v='+v+'&k='+k, success: function(result){
            $("#tbayar"+t+"").html(result);
        }});
    }
</script>
<script>
function loadhistrx(t,k,v) {
		$("#histtrx").html('<h2>..loading..</h2>');
        $.ajax({url: 'App/api.php?m=lap.trx.murid.hist&v='+v+'&k='+k, success: function(result){
            $("#histtrx").html(result);
        }});
    }
</script>
<?
#$a="88000000123";
#$f=str_split($a,8);
#echo $f[0];
####
######### sisa uang sebelumnya jika ada
$qb="SELECT va,
sum(case when (kode='0010' or kode='0020') then jml else 0 end) as debet, 
sum(case when (kode!='0010' and kode!='0020') and kode !='' then jml else 0 end) as kredet
FROM keu_rincian_potong_trxbank
where (va='".$_GET['v1']."' or va='".$_GET['v2']."') and month(pdate)<'".$_GET['b']."' and year(pdate)='".$_GET['t']."'
group by va
";
#echo $qb;
$stmtsb = $conn->prepare($qb);
$stmtsb->execute();
$rowsb = $stmtsb->fetch();
$sisauangsbl=$rowsb['debet']-$rowsb['kredet'];
###

###
$q="SELECT * from keu_mastertagihan
where va1='".$_GET['q']."'
group by va1
";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
$row1 = $stmt->fetch();
###### query data
#####
$q2="
SELECT id,va,ket,day(pdate) as tgl,month(pdate) as bln,year(pdate) as thn, 
case when (ket like'TRF%' or ket like'CASH%') then jml else 0 end as trf,
case when ket like'bayar%' then jml else 0 end as pemotongan
FROM keu_rincian_potong_trxbank
where kode2='".$_GET['b']."'
order by id ASC
";

?>

<div id='histtrx'>
<table class="table" style="font-size:9pt;" width="100%" class="table table-striped table-bordered table-hover" id="dataTables">
<tr>
					<th>Tanggal</th>
					<th>URAIAN</th>
					<th>TRF</th>
					<th>PEMBAYARAN</th>
                </tr>
<tr>
                    <td></td>
					<td>Sisa Uang sebelumnya</td>
					<td><?php  echo uang($sisauangsbl); ?></td>
					<td><?php  echo uang(0); ?></td>

</tr>
<?
$stmt = $conn->prepare($q2);
$stmt->execute();
$n=1;
$a=0+$sisauangsbl;$b=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;$i=0;$j=0;$k=0;$l=0;$m=0;$tagih=0;
while ($row = $stmt->fetch()) {
?>
<tr>
                    <td><?php  echo $row['tgl']."-".$row['bln']."-".$row['thn']; ?></td>
					<td><?php  echo $row['ket']; ?></td>
					<td><?php  echo uang($row['trf']); ?></td>
					<td><?php  echo uang($row['pemotongan']); ?></td>

</tr>
<?
$n=$n+1;
$a=$a+$row['trf'];$b=$b+$row['pemotongan'];$c=$c+$row['c'];$d=$d+$row['d'];$e=$e+$row['e'];$f=$f+$row['f'];$g=$g+$row['g'];
$h=$h+$row['h'];$i=$i+$row['i'];$j=$j+$row['j'];$k=$k+$row['k'];$l=$l+$row['l'];$m=$m+$row['m'];$tagih=$tagih+$row['tagih'];
$n=$i+($row['i']+$row['j']+$row['k']+$row['l']+$row['m']+$row['katering']+$row['atk']+$row['jamiyyah']);
}?>
<tr>
<td style='text-align:left;' colSPAN='2'><?echo txthtml("TOTAL");?></td>
<td><?echo txthtml(uang($a));?></td><td><?echo txthtml(uang($b));?></td>
</tr>
<tr>
<td style='text-align:left;' colSPAN='2'><?echo txthtml("SISA");?></td>
<td><?echo txthtml(uang($a-$b));?></td><td></td>
</tr>

<?$conn = null;?>
</table>
</div>