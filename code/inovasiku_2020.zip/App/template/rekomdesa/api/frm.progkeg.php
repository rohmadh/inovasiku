<table>
<tr>
<td>&nbsp;&nbsp;&nbsp;
<input type="hidden" id="mode" value="save">
<input type="hidden" id="idprog" value="">
<input type="hidden" id="idkeg" value="">
<input type="hidden" id="idpanjar" value="<?echo $_GET['id'];?>">
</td>
<td><label>NAMA PROGRAM </label></td><td><label>:</label></td><td><input name="nama" id="namaprog" class="form-controls" type="text" size="100" disabled>
<br />
<div id="targetlistprog"></div>
</td>
<td><label>KATA KUNCI :</label><input type="text" id="qp" onfocus='setawal();'><input type="button" value="CARI" onclick='getlprog();'></td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>NAMA KEGIATAN</label></td><td><label>:</label></td><td><input name="nama" id="namakeg" class="form-controls" type="text" size="100" disabled>
<br />
<div id="targetlistkeg"></div>
</td>
<td><label>KATA KUNCI :</label><input type="text" id="qk" onfocus='setawal();'><input type="button" value="CARI" onclick='getlkeg();'></td>
</tr>
</table>