<div class="col-lg-12">
<table width="100%" cellpadding="2" cellspacing="10" border="0">

<tr>
<td colspan="3"><div class="alert alert-info"><?echo strtoupper('FORM PENENTUAN ASPEK PENILAIAN DAN BOBOT');?></div></td>
</tr>
<tr>
<td width="30%">ID EVENT</td><td>:</td>
<td><input type="text" class="form-control" size="10%" id="idevent" value="<?echo $_GET['ide'];?>" disabled></td>
</tr>

<tr>
<td width="30%">Uraian Penilaian</td><td>:</td>
<td>
<textarea class="form-control" style="width:95%;height:100px;" id="krit"></textarea></td>
</tr>
<tr>
<td width="30%">Bobot (%)</td><td>:</td>
<td><input type="text" class="form-control" size="10%" id="bobot" value=""></td>
</tr>
<tr>
<td width="30%">Tipe Jawaban</td><td>:</td>
<td>
<select id="tipe">
<option value="t" selected>Text</option>
<option value="p">Paragraf</option>
</select>

</td>
</tr>
<tr>
<td width="30%">Text Kelompok</td><td>:</td>
<td>
<select id="askat">
<option value="1">Ya</option>
<option value="0" selected>Tidak</option>
</select>

</td>
</tr>
<tr>
<td width="30%">Rincian</td><td>:</td>
<td>
<select id="asrin">
<option value="1">Ya</option>
<option value="0" selected>Tidak</option>
</select>
</td>
</tr>
<tr>
<td width="30%"></td><td></td><td><br /><input type="button" value="Simpan" onclick="simpan_var(<?echo $_GET['ide'];?>);"></td>

</tr>
</table>
<hr>
<div id="tblvar">

</div>
</div>
<script>
function loadtblvar() {	
		$("#tblvar").html('..LOADING..');
        $.ajax({url: 'App/<?echo $base;?>/api.php?m=tbl.var&ide='+<?echo $_GET['ide'];?>, success: function(result){
            $("#tblvar").html(result);
        }});
    }
function simpan_var(k) {
		var ide=$('#idevent').val();
		var askat=$('#askat').val();
		var asrin=$('#asrin').val();
		var tipe=$('#tipe').val();
		var krit=$('#krit').val();
		var bobot=$('#bobot').val();
		var data={'mode':'insert','krit':krit,'ide':ide,'bobot':bobot,'askat':askat,'asrin':asrin,'tipe':tipe};
        $.ajax({url: 'App/<?echo $base;?>/api.php?m=input.var',type:'post',data:data, success: function(result){
            alert('..DATA TERSIMPAN..');
			loadtblvar();
        }});
    }
loadtblvar();
</script>