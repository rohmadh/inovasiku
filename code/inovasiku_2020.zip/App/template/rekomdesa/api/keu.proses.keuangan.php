<?
if($_GET['mode']=='copy'){
#mysql_query("delete from master where tahun='".$_SESSION['thn']."' ");
$prioritas=array("spp","pendukung","extra","kbm","infaq");
$kdd=time();
$q=mysql_query("select * from keu_autodebet_grupspp where kode='".$_GET['id']."'");
while($r=mysql_fetch_array($q)){
	############
	$column[0]=$r['nama'];
	$column[1]=$r['rekening'];
	$column[2]=$r['spp'];
	$column[3]=$r['extra'];
	$column[4]=$r['angup'];
	$column[5]=$r['lunup'];
	$column[6]=$r['wktupload'];
	$column[7]=$r['kode'];
	###########
	###############################proseskeuangan
			echo $sqlInsert;
			echo mysql_error();
			$uang=$column['2']+$column['3']+$column['4']+$column['5'];
			echo $uang;
			$bayar=0;
			###
			$sql="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[1]."BNI','".$kdd."','0020',now(),'TRF  a.n ".$column[0]."','".$uang."')";
			mysql_query($sql);
			####
			if($uang>0){
			#iterasi tagihan sesuai prioritas
			foreach($prioritas as $pr){
			
			##### proses bayar
			#cek sisa tagihan sesuai prioritas
			$qt=mysql_query("select id,thn,va1,(".$pr."-b".$pr.") as sisa,".$pr." as tag from tagihan_autodebet where rek1='".$column[1]."'");
			while($rtag=mysql_fetch_array($qt)){
			if($rtag['sisa']>0){
				if(($uang-$rtag['sisa'])>=0){
				####bayarkan
				$byr="update keu_mastertagihan set b".$pr."='".$rtag['tag']."' where id='".$rtag['id']."'";
				echo $byr;
				mysql_query($byr);
				#######catat ke history
				$sqlhist="insert into keu_rincian_potong_trxbank (va,noinv,kode,kode2,pdate,ket,jml) value ('".$rtag['va1']."','".$kdd."','".$pr."','".$rtag['id']."',now(),'Bayar ".$pr."(".$rtag['thn'].") a.n ".$column[0]."','".$rtag['sisa']."')";
				mysql_query($sqlhist);
				$uang=$uang-$rtag['sisa'];
				###
				echo mysql_error();
				}else{
					####bayarkan sisa kurang
					echo "KURANG";
				$byr="update keu_mastertagihan set b".$pr."='".$uang."' where id='".$rtag['id']."'";
				echo $byr;
				mysql_query($byr);
				#######catat ke history
				$sqlhist="insert into keu_rincian_potong_trxbank (va,noinv,kode,kode2,pdate,ket,jml) value ('".$rtag['va1']."','".$kdd."','".$pr."','".$rtag['id']."',now(),'Bayar Kurang ".$pr."(".$rtag['thn'].") a.n ".$column[0]."','".$uang."')";
				mysql_query($sqlhist);
				$uang=$uang-$uang;
				###
					
					}
			}
			}
			#####
			}
			#####end iterasi prio
			
			}
			echo $qs;
			$qt=mysql_query($qs);
			echo mysql_error();
	#######
}
}
echo mysql_error();
?>