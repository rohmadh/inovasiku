<?
if($_POST['mode']=='insert'){
$q="
insert into var_penilaian (id_event,as_kat,as_rin,uraian,bobot,tipe) values ('".$_POST['ide']."','".$_POST['askat']."','".$_POST['asrin']."',
'".$_POST['krit']."','".$_POST['bobot']."','".$_POST['tipe']."')
";

}
$stmt = $conn->prepare($q);
$stmt->execute();
$conn = null;
?>