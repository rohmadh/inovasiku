<script>
function loadbayar(t,k,v,y) {
		$("#tbayar"+t+"").html('<i>..load..</i>');
        $.ajax({url: 'App/api.php?m=get.bayar.bulan&v='+v+'&thn='+y+'&k='+k, success: function(result){
            $("#tbayar"+t+"").html(result);
        }});
    }
</script>
<script>
function loadhistrx(v1,v2,b,t) {
		$("#histtrx").html('<h2>..loading..</h2>');
        $.ajax({url: 'App/api.php?m=lap.trx.murid.hist&v1='+v1+'&v2='+v2+'&t='+t+'&b='+b, success: function(result){
            $("#histtrx").html(result);
        }});
    }
</script>
<?
#$a="88000000123";
#$f=str_split($a,8);
#echo $f[0];
$q="SELECT * from keu_mastertagihan
where va1='".$_GET['q']."'
group by va1
";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
$row1 = $stmt->fetch();
###### query data
#####
$q2="
SELECT id,nama,va1,va2,sum(spp)as a,sum(bspp) as a1,sum(pendukung) as b,sum(bpendukung) as b1, sum(extra) as c,sum(bextra) as c1,
sum(kbm) as d,sum(bkbm) as d1,sum(infaq) as e,sum(binfaq) as e1,sum(jamiyah) as f,sum(bjamiyah) as f1,
sum(atk) as g,sum(batk) as g1,sum(bukupaket)as h,sum(bbukupaket) as h1, 
sum(seragam) as i,sum(bseragam) as i1,sum(anjem) j,sum(banjem) as j1, 
sum(catering) as k,sum(bcatering) as k1, sum(osis) as l,sum(bosis) as l1, sum(lain) as m,sum(blain) as m1,
sum(spp+pendukung+extra+kbm+infaq+jamiyah+atk+bukupaket+seragam+anjem+catering+osis+lain) as tagih,month(thn) as bulan,year(thn) as tahun 
FROM keu_mastertagihan
where va1='".$_GET['q']."'
group by va1,bulan,tahun
order by nama,bulan,tahun
";
###### array prioritas
$prioritas=array('spp','extra','kbm');

?>

<table class="table" style="font-size:9pt;" width="100%" class="table table-striped table-bordered table-hover" id="dataTables">
<tr>
<td rowspan='2' width="7%"><img src="App/<?echo $base;?>/assets/img/noimage.gif"></td><td><b>Nama</b></td><td><?php  echo $row1['nama']; ?></td>
</tr>
<tr>
<td><b>Kelas</b></td><td><?php  echo txthtml($row1['kelas']); ?></td>
</tr>
</table>
<div id='histtrx'>
<table class="table" style="font-size:9pt;" width="100%" class="table table-striped table-bordered table-hover" id="dataTables">
<tr>
					<th>bln/thn</th>
					<th>spp</th>
					<th>pendukung</th>
					<th>extra</th>
					<th>kbm</th>
					<th>infaq</th>
					<th>jamiyah</th>
					<th>atk</th>
					<th>b.paket</th>
					<th>seragam</th>
					<th>anjem</th>
					<th>catering</th>
					<th>osis</th>
					<th>lain</th>
					<th>Tagihan</th>
					<th>Pembayaran</th>
					<th>action</th>
                </tr>

<?
$stmt = $conn->prepare($q2);
$stmt->execute();
$n=1;
$a=0;$b=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;$i=0;$j=0;$k=0;$l=0;$m=0;$tagih=0;
while ($row = $stmt->fetch()) {
?>
<tr>
                    <td><?php  echo $row['bulan']."-".$row['tahun']; ?></td>
					<td <?if ($row['a1']==$row['a']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['a']; ?></td>
					<td <?if ($row['b1']==$row['b']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['b']; ?></td>
					<td <?if ($row['c1']==$row['c']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['c']; ?></td>
					<td <?if ($row['d1']==$row['d']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['d']; ?></td>
					<td <?if ($row['e1']==$row['e']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['e']; ?></td>
					<td <?if ($row['f1']==$row['f']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['f']; ?></td>
					<td <?if ($row['g1']==$row['g']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['g']; ?></td>
					<td <?if ($row['h1']==$row['h']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['h']; ?></td>
					<td <?if ($row['i1']==$row['i']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['i']; ?></td>
					<td <?if ($row['j1']==$row['j']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['j']; ?></td>
					<td <?if ($row['k1']==$row['k']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['k']; ?></td>
					<td <?if ($row['l1']==$row['l']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['l']; ?></td>
					<td <?if ($row['m1']==$row['m']){echo "bgcolor=white-blue";}else{echo "bgcolor=red";}?>><?php  echo $row['m']; ?></td>
					<td><?php  echo uang($row['tagih']); ?></td>
					<td><div id="tbayar<?echo $n;?>"></div><script>loadbayar('<?echo $n?>','<?echo $row['id'];?>','<?echo $_GET['q'];?>','<?echo $row['tahun'];?>')</script></td>

<td><input type="button" value="TRX" onclick="loadhistrx('<?echo txthtml($row['va1']);?>','<?echo txthtml($row['va2']);?>','<?echo txthtml($row['id']);?>','<?echo txthtml($row['tahun']);?>')"></td>
</tr>
<?
$n=$n+1;
$a=$a+$row['a'];$b=$b+$row['b'];$c=$c+$row['c'];$d=$d+$row['d'];$e=$e+$row['e'];$f=$f+$row['f'];$g=$g+$row['g'];
$h=$h+$row['h'];$i=$i+$row['i'];$j=$j+$row['j'];$k=$k+$row['k'];$l=$l+$row['l'];$m=$m+$row['m'];$tagih=$tagih+$row['tagih'];
$n=$i+($row['i']+$row['j']+$row['k']+$row['l']+$row['m']+$row['katering']+$row['atk']+$row['jamiyyah']);
}?>
<tr>
<td style='text-align:left;'><?echo txthtml("TOTAL");?></td>
<td><?echo txthtml(uang($a));?></td><td><?echo txthtml(uang($b));?></td><td><?echo txthtml(uang($c));?></td>
<td><?echo txthtml(uang($d));?></td><td><?echo txthtml(uang($e));?></td><td><?echo txthtml(uang($f));?></td>
<td><?echo txthtml(uang($g));?></td><td><?echo txthtml(uang($h));?></td>
<td><?echo txthtml(uang($i));?></td><td><?echo txthtml(uang($j));?></td><td><?echo txthtml(uang($k));?></td>
<td><?echo txthtml(uang($l));?></td><td><?echo txthtml(uang($m));?></td>
<td><?echo txthtml(uang($tagih));?></td><td></td><td></td>
</tr>

<?$conn = null;?>
</table>
</div>