<?
if($_GET['mode']=='save'){
mysql_query("insert into tblpenyediaandana (idkeg,koderekbelanja,tw1,tw2,tw3,tw4) value ('".$_GET['idkeg']."','".$_GET['idrek']."','".$_GET['tw1']."','".$_GET['tw2']."','".$_GET['tw3']."','".$_GET['tw4']."')");
}
?>