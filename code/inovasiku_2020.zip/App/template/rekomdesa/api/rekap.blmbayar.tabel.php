<?
if(strlen($_GET['ta'])>3){
$q="SELECT nama,thn, 
spp+pendukung+extra+kbm+infaq+jamiyah+atk+bukupaket+seragam+anjem+catering+osis+lain as tag,
bspp+bpendukung+bextra+bkbm+binfaq+bjamiyah+batk+bbukupaket+bseragam+banjem+bcatering+bosis+blain as bayar
from keu_mastertagihan
where thn between date_format(str_to_date('".$_GET['ta']."','%d/%m/%Y'),'%Y-%m-%d') and date_format(str_to_date('".$_GET['tb']."','%d/%m/%Y'),'%Y-%m-%d')
order by nama ASC";
}else{
$q="SELECT nama,thn, 
spp+pendukung+extra+kbm+infaq+jamiyah+atk+bukupaket+seragam+anjem+catering+osis+lain as tag,
bspp+bpendukung+bextra+bkbm+binfaq+bjamiyah+batk+bbukupaket+bseragam+banjem+bcatering+bosis+blain as bayar
from keu_mastertagihan
";	
}
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
#echo $q;
?>


<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables">
<thead>
<tr>
<th>Nama</th><th>Tanggal Tagihan</th>
</tr>
</thead>
<tbody>
<?
$a=0;$b=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;$i=0;
while ($row = $stmt->fetch()) {
	if(($row['tag']-$row['bayar'])>0){
?>
<tr>
<td style='text-align:left;'><?echo txthtml($row['nama']);?></td>
<td><?echo txthtml($row['thn']);?></td>

</tr>
<?
	}
}?>

</tbody>
<?$conn = null;?>
</table>
<script>
$("#dataTables").DataTable();
</script>