<table class="table">
<tr>
<th>Program/Kegiatan</th><th>Jumlah Anggaran</th><th>GU</th><th>TU</th><th>LS</th><th>JML PANJAR</th><th>S/D BLN LALU</th><th>BLN INI</th><th>S/D BLN INI</th><th>SISA ANGGARAN</th><th>(%) serapan</th>
</tr>
<?
$a=0;$b=0;$i=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;

$q=mysql_query("select * from program where tahun='".$_SESSION['thn']."' and status='1'");
while($r=mysql_fetch_array($q)){
?>
<tr>
<td style='text-align:left;'><b><?echo strtoupper($r['txtprogram']);?></b></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<?

$q2=mysql_query("
SELECT idprog,idkeg,uraian,gv,tu,ls,
sum(case when angg>0 then angg else 0 end) as angg,
sum(case when panjar>0 then panjar else 0 end) as panjar,
lalu,ini,sdini
from laporankendali2
where idprog='".$r['id']."'
group by laporankendali2.idkeg
");
#echo mysql_error();
while($r2=mysql_fetch_array($q2)){
?>
<tr>
<td style='text-align:left;'><i><?echo $r2['uraian'];?></i></td>
<td><?echo uang($r2['angg']);?></td><td><?echo uang($r2['gv']);?></td><td><?echo uang($r2['tu']);?></td><td><?echo uang($r2['ls']);?></td>
<td><?echo uang($r2['panjar']);?></td><td><?echo uang($r2['lalu']);?></td><td><?echo uang($r2['ini']);?></td><td><?echo uang($r2['sdini']);?></td><td><?echo uang($r2['angg']-$r2['tu']-$r2['ls']-$r2['sdini']);?></td>
<td><?$atas=$r2['tu']+$r2['ls']+$r2['sdini'];if($atas>0){echo number_format(($r2['tu']+$r2['ls']+$r2['sdini'])/$r2['angg'],4)*100;}else echo '0';?></td>
</tr>
<?
$a=$a+$r2['angg'];$f=$f+$r2['lalu'];
$b=$b+$r2['gv'];$g=$g+$r2['ini'];
$c=$c+$r2['tu'];$h=$h+$r2['sdini'];
$d=$d+$r2['ls'];
$e=$e+$r2['panjar'];
}}?>
<tr>
<td style='text-align:left;'><b>Total</b></td>
<td><?echo uang($a);?></td><td><?echo uang($b);?></td><td><?echo uang($c);?></td><td><?echo uang($d);?></td>
<td><?echo uang($e);?></td><td><?echo uang($f);?></td><td><?echo uang($g);?></td><td><?echo uang($h);?></td><td><?echo uang($a-$c-$d-$h);?></td><td><?echo number_format((($c+$d+$h)/$a)*100,3);?></td>
</tr>
</table>