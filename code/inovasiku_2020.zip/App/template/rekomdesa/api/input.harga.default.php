<?
$q="update keu_prioritas_tagihan set rupiah='".$_GET['n']."' where kode='".$_GET['k']."'
";
$stmt = $conn->prepare($q);
$stmt->execute();
$conn = null;
?>