<table class="table" style="font-size:9pt;">
<tr>
<th>Program/Kegiatan</th><th>Penyediaan Dana</th><th>Pengesahan SPJ</th><th>Sisa SPD</th>
</tr>
<?
$q=mysql_query("select * from master where kode !='' and kprog !=''");
while($r=mysql_fetch_array($q)){
$qp=mysql_query("select sum(jml) as jspj from tblspj2 where idrek like'".$r['kode']."%'");
$rp=mysql_fetch_array($qp);
?>
<tr>
<td><b><?echo $r['kprog'];?></b></td><td></td><td></td><td></td>
</tr>
<?
$q2=mysql_query("select * from master where kkeg !='' and kode like'".$r['kode']."%'");
while($r2=mysql_fetch_array($q2)){
$qk=mysql_query("select sum(jml) as jspj from tblspj2 where idrek like'".$r2['kode']."%'");
$rk=mysql_fetch_array($qp);
?>
<tr>
<td><b><?echo $r2['kkeg'];?></b></td><td></td><td></td><td></td>
</tr>

<?
$q3=mysql_query("select * from master where kode !='' and kprog='' and kkeg='' and kode like'".$r2['kode']."%' order by kode ASC");
while($r2=mysql_fetch_array($q3)){
$q4=mysql_query("select sum(jml) as jspj from tblspj2 where idrek like'".$r2['kode']."%'");
$r4=mysql_fetch_array($q4);
?>
<tr>
<td><?echo $r2['kode'];?>.<?echo $r2['krek1'];?><?echo $r2['krek2'];?><?echo $r2['krek3'];?><?echo $r2['krek4'];?></td><td style='text-align:right;'><?echo uang($r2['angg']);?></td>
<td style='text-align:right;'><?echo uang($r4['jspj']);?></td>
<td style='text-align:right;'><?echo uang($r2['angg']-$r4['jspj']);?></td>
</tr>
<?}}

echo mysql_error();
}?>

</table>