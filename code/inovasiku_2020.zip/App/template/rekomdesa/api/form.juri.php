<div class="col-lg-12">
<table width="100%" cellpadding="2" cellspacing="10" border="0">

<tr>
<td colspan="3"><div class="alert alert-info"><?echo strtoupper('FORM DEWAN JURI');?></div></td>
</tr>
<tr>
<td width="30%">ID EVENT</td><td>:</td>
<td><input type="text" class="form-control" size="10%" id="idevent" value="<?echo $_GET['ide'];?>" disabled>
</td>
</tr>
<tr>
<td width="30%">Nama (Lengkap dg gelar)</td><td>:</td>
<td><input type="text" class="form-control" size="80%" id="nama" value=""></td>
</tr>
<tr>
<td width="30%">Keterangan</td><td>:</td>
<td>
<textarea class="form-control" style="width:95%;height:100px;" id="ket"></textarea></td>
</tr>

<tr>
<td width="30%"></td><td></td><td><br /><input type="button" value="Simpan" onclick="simpan_juri(<?echo $_GET['ide'];?>);"></td>

</tr>
</table>
<hr>
<div id="tbljuri">

</div>
</div>
<script>
function loadtbljuri() {	
		$("#tbljuri").html('..LOADING..');
        $.ajax({url: 'App/<?echo $base;?>/api.php?m=tbl.juri&ide='+<?echo $_GET['ide'];?>, success: function(result){
            $("#tbljuri").html(result);
        }});
    }
function simpan_juri(k) {
		var ide=$('#idevent').val();
		var nama=$('#nama').val();
		var ket=$('#ket').val();
		var data={'mode':'insert','nama':nama,'ide':ide,'ket':ket};
        $.ajax({url: 'App/<?echo $base;?>/api.php?m=input.juri',type:'post',data:data, success: function(result){
            alert('..DATA TERSIMPAN..');
			loadtbljuri();
        }});
    }
loadtbljuri();
</script>