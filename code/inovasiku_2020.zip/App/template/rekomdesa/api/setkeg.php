<?

if($_GET['k']){
$_SESSION['setkeg']=$_GET['k'];
$_SESSION['txtkeg']=$_GET['txt'];
}
?>