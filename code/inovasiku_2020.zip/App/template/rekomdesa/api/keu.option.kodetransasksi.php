
<?
$q="SELECT * FROM keu_kodeakun";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
?>
<table class="table">
<tr>
<th>KODE AKUN</th><th>KETERANGAN</th><th>JUMLAH</th><th>PROSES</th>
</tr>
<?
while ($row = $stmt->fetch()) {
?>							
<tr>
<td><? echo(txthtml($row['kodeakun']));?></td><td><? echo txthtml($row['ket']);?></td><td><? echo txthtml(uang($row['jml']));?></td><td>--</td>
<tr/>
<?$conn = null;}?>
</table>