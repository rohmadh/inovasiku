<?
if($_GET['k']){
$q=mysql_query("select * from tblup where id='".$_GET['k']."'");
$r=mysql_fetch_array($q);}
?>
<script>
$("#tgl").val('<?echo $r['tgl'];?>');
$("#jml").val('<?echo $r['jml'];?>');
$("#uraian").val('<?echo $r['uraian'];?>');
$("#mode").val('edit');
$("#idup").val('<?echo $r['id'];?>');
</script>