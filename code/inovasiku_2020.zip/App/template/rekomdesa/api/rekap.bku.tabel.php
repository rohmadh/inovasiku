<?
$tb=mysql_escape_string($_GET['tb']);
$ta=mysql_escape_string($_GET['ta']);
$a=0;$b=0;$d=0;$k=0;
$q="SELECT date_format(waktu,'%d/%m/%Y') as tgl,time(waktu) as tm,kodeakun,ket,keu_kodeakun.uraian as rek,
case when notransaksi like'01%' or kodeakun like'01%' then jml else 0 end as debet,
case when notransaksi like'02%' or kodeakun like'02%' then jml else 0 end as kredit
FROM keu_transaksi 
left join keu_kodeakun on keu_transaksi.kodeakun=keu_kodeakun.kode
where waktu between str_to_date(:ta,'%d/%m/%Y') and str_to_date(:tb,'%d/%m/%Y')
order by waktu ASC";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->bindValue(':ta', $ta, PDO::PARAM_STR);
$stmt->bindValue(':tb', $tb, PDO::PARAM_STR);
$stmt->execute();
?>
<table class="table" style="font-size:9pt;">
<tr>
<th>Tanggal</th><th>Kode Rekening</th><th>Uraian</th><th>Penerimaan</th><th>Pengeluaran</th>
</tr>

<?
while ($row = $stmt->fetch()) {
?>	
<tr>
<td><?echo txthtml($row['tgl']);?>-<?echo txthtml($row['tm']);?></td><td><?echo txthtml($row['kodeakun']);?>-<?echo txthtml($row['rek']);?></td><td><?echo txthtml($row['ket']);?></td>
<td style='text-align:right;'><?echo txthtml(uang($row['debet']));?></td><td style='text-align:right;'><?echo txthtml(uang($row['kredit']));?></td>
</tr>
<?$a=$a+$row['debet'];$b=$b+$row['kredit'];}?>

<tr>
<td></td><td>Total</td><td></td><td style='text-align:right;'><? echo txthtml(uang($a));?></td><td style='text-align:right;'><? echo txthtml(uang($b));?></td>
</tr>
<tr>
<td></td><td>Saldo</td><td></td><td style='text-align:right;' colspan="2"><b><? echo txthtml(uang($a-$b));?></b></td>
</tr>
</table>
<?
$q=mysql_query("select sum");
?>
