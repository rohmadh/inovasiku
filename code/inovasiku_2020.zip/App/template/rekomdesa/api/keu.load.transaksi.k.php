<?
####hapus
$no=$_GET['id'];
$q="select * from keu_transaksi 
where notransaksi=:no";
$stmt = $conn->prepare($q);
$stmt->bindValue(':no', $no, PDO::PARAM_STR);
$stmt->execute();
$row = $stmt->fetch();
#echo txthtml($row['kodeakun']);
$conn = null;
?>
<script>
$("#mode").val('edit');
$("#akun").val('<?echo txthtml($row['kodeakun']);?>');
$("#ket").val('<?echo txthtml($row['ket']);?>');
$("#jml").val('<?echo txthtml($row['jml']);?>');
$("#idklien").val('<?echo txthtml($row['klien']);?>');
$("#dari").val('<?echo txthtml($row['nama']);?>');
$("#idd").val('<?echo txthtml($row['notransaksi']);?>');
</script>