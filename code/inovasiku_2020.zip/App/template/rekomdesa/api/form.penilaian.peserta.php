<?
#$q="select * from data where id_event='1' order by id ASC";
$q="SELECT *
FROM data
LEFT JOIN var_penilaian ON data.id_var = var_penilaian.id
where id_usr='".$_GET['idp']."' and id_juri='".$_GET['idj']."'
order by urutan ASC
";
$stmt = $conn->prepare($q);
$stmt->execute();
$tipeblok=array('success','info','warning','danger');
$n=1;
?>
<div id='prosesnilai'>
</div>
<div class="row">
<table width="90%" cellpadding="2" cellspacing="2">
<?while ($row = $stmt->fetch()) {
if($row['as_kat']=='1'){
?>
<tr>
<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
<td colspan="5"><div class="alert alert-<?echo txthtml($tipeblok[fmod($n,4)]);?>"><?echo strtoupper($row['uraian']);?></div></td>
</tr>
<?}else{?>
<tr>
<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
<td width="30%"><?echo $row['uraian'];?></td><td>:</td>
<?if($row['tipe']=='t'){?>
<td><input type="text" class="form-control" size="80%" id="isi_<?echo $row['id_event'];?>_<?echo $row['id_usr'];?>_<?echo $row['id_var'];?>_<?echo $row['id_juri'];?>" value="<?echo strtoupper($row['isi']);?>"></td>
<?}?>
<?if($row['tipe']=='p'){?>
<td><textarea class="form-control" style="width:95%;height:100px;" id="isi_<?echo $row['id_event'];?>_<?echo $row['id_usr'];?>_<?echo $row['id_var'];?>_<?echo $row['id_juri'];?>"><?echo strtoupper($row['isi']);?></textarea></td>
<?}?>
<td>Skor</td><td><input type="text" class="form-control" size="3" id="skor_<?echo $row['id_event'];?>_<?echo $row['id_usr'];?>_<?echo $row['id_var'];?>_<?echo $row['id_juri'];?>" value="<?echo strtoupper($row['skor']);?>">
<i class="fa fa-fw" aria-hidden="true" title="Copy to use save" style="cursor: pointer;" onclick="updatenilai('<?echo $row['id_event'];?>','<?echo $row['id_usr'];?>','<?echo $row['id_var'];?>','<?echo $row['id_juri'];?>');">&#xf0c7</i>
</td>
</tr>
<tr>
<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
<td width="30%"></td><td></td><td></td><td></td><td></td>

</tr>
<?}$n=$n+1;}?>
</table>
</div>
<script>
function updatenilai(a,b,c,d) {	
		var skor=$("#skor_"+a+"_"+b+"_"+c+"_"+d+"").val();
		var isi=$("#isi_"+a+"_"+b+"_"+c+"_"+d+"").val();
		var data={'mode':'update','id_event':a,'id_usr':b,'id_var':c,'id_juri':d,'skor':skor,'isi':isi};
		$("#prosesnilai").html('..UPDATING DATA..');
		
        $.ajax({url: 'App/<?echo $base;?>/api.php?m=input.nilai.peserta',type:'post',data:data, success: function(result){
            $("#prosesnilai").html('');
			alert('..Data Tersimpan..');
        }});
    }
</script>