<!-- slider -->

							<div class="slider-holder">
								<div class="flexslider">
									<ul class="slides">
<?
if ($handle = opendir(''.$base.'/images/slider/')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
			?>
										<li><img src="<?echo "$base";?>/images/slider/<?echo "$entry";?>" width="636" height="334" border="0" usemap="#Map" /></li>
										
									<?
        }
    }

    closedir($handle);
}
?>
										
									</ul>
								</div>
							</div>
							
							<!-- end of slider -->	
							<br class="clear" />
<br class="clear" />
<br class="clear" />					
<div id="comments">
        
        <ul class="commentlist">
          <li class="comment_even">
            <div class="author"><span class="name"><a href="#">PENDAFTARAN BEASISWA UNGGULAN S2 MSTT UGM</a></span> </div>
            <div class="submitdate"><a href="#">August 4, 2009 at 8:35 am</a></div>
			<img class="avatar" src="App/template/images/demo/80x80.gif" width="80" height="80" alt="" />
            <p>
			Kesempatan terbuka bagi FRESH GRADUATE, KARYAWAN BUMN, PNS (kecuali DOSEN) Alumni Jur. Teknik Sipil Universitas Negeri Terakredititasi A
dengan IP minimal 3.25 (S1 Reguler), 3.40 (Program Swadaya UGM), 3.50 (Prog.Swadaya diluar UGM).Informasi selengkapnya di
http://mstt.ugm.ac.id/
mstt.ugm.ac.id


			
			</p>
          </li>
		  <?
		  $q=mysql_query("select * from news order by date DESC limit 0,2");
		  while($r=mysql_fetch_array($q)){
		  $doc = new DOMDocument();
				@$doc->loadHTML($r['depan']);

				$tags = $doc->getElementsByTagName('img');

				foreach ($tags as $tag) {
					$sgbr=$tag->getAttribute('src');
					
				}
		  ?>
		  <li class="comment_even">
            <div class="author"><span class="name"><a href="#"><?echo $r[judul];?></a></span> </div>
            <div class="submitdate"><a href="#">August 4, 2009 at 8:35 am</a></div>
			<img class="avatar" src="<? echo $sgbr;?>" width="80" height="80" alt="" />
            <p><?echo $r[depan];?></p>
          </li>
		  
		  <?}?>
		  </ul>
</div>

<div id="services">
<br class="clear" />
<br class="clear" />
<br class="clear" />
      <ul>
        <li>
          
		  <?
		  $q=mysql_query("select * from news where kat='7' order by date DESC limit 0,1");
		  $r=mysql_fetch_array($q);
		  
		  ?>
          <h2><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=news.read&id=".$r['id']."",$key2));?>" style="background-color:#EFEFEF;"><?echo $r['judul'];?></a></h2>
          <p>
		  <img src="<?echo $sgbr;?>" width="150">
		  <?echo $r['depan'];?>
		  </p>
          
          
        </li>
        <li>
          <div class="imgholder"><a href="#"><img src="images/demo/290x100.gif" alt="" /></a></div>
          <?
		  $q=mysql_query("select * from news where kat='8' order by date DESC limit 0,1");
		  $r=mysql_fetch_array($q);
		  ?>
          <h2><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=news.read&id=".$r['id']."",$key2));?>" style="background-color:#EFEFEF;"><?echo $r['judul'];?></a></h2>
          <p><?echo $r['depan'];?>
        </li>
		</ul>
		</div>
		<br class="clear" />
<br class="clear" />
<br class="clear" />
<br class="clear" />
<br class="clear" />
<br class="clear" />
<br class="clear" />
<br class="clear" />
<br class="clear" />
<br class="clear" />
<br class="clear" />
<br class="clear" />
		