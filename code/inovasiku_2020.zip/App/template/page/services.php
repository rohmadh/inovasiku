<?
$q=mysql_query("select * from news where kat='14'");
$r=mysql_fetch_array($q);

?>
<span class="titl">Kerjasama dan Layanan</span> 
	<span class="txt" style="width:400px;"> 
	<?
	echo $r['depan'];
	?>
	<br/>
	<br />
	
	</span> <img src="App/template/images/grl.jpg" alt="" width="167" height="109" style="margin:10px 0 0 10px;" /> 
	<span class="txt">  <br />
      
      </span> <img src="App/template/images/c_tp.gif" alt="" width="596" height="6" style="margin:10px 0 0 0;" /> 
	  <span class="modl"> <span class="titl2" style="color:#DB4801;">Foto Kegiatan</span> 
	  <a href="#" class="vw">View Full Gallery</a> 
	  <span style="width:595px; float:left;"> 
	  <iframe src="App/gallery/" width="100%" height="450" scrolling="no" frameborder="0"></iframe> 

	  </span> 
	  
	  </span> <img src="App/template/images/c_btm.gif" alt="" width="596" height="6" />