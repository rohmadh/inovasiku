<?
$q=mysql_query("select * from kategori where id='".$data['katid']."'");
$r=mysql_fetch_array($q);

?>

	<span class="txt" style="width:100%;"> 
	
	
	</span> 
	<span class="titkat">  
      Kategori>> <?echo $r['kat'];?>
      </span> <img src="App/template/images/c_tp.gif" alt="" width="596" height="6" style="margin:10px 0 0 0;align:center;" /> 
	  <span class="modl"> <span class="titl2" style="color:#DB4801;"></span> 
	  <div id="items">
	  <?
	  $q=mysql_query("select * from master_barang where kat='".$data['katid']."' order by nama ASC");
	  while($r=mysql_fetch_array($q)){ ?>
	  <div class="item">
	  <?
	  $doc = new DOMDocument();
				@$doc->loadHTML($r['gbr']);

				$tags = $doc->getElementsByTagName('img');

				foreach ($tags as $tag) {
					$sgbr=$tag->getAttribute('src');
					
				}
	  
	  
	  ?>
	  <img src="App/<? if(strlen($sgbr)>0){echo $sgbr;}else{echo"App/template/images/noimage.jpg";}?>" height="140" width="140">
	  
	  <p><a href="?pid=<? echo rawurlencode(encrypt("?modul=addons&page=product.read&id=".$r['id']."",$key2));?>"><?echo $r['nama'];?></a></p><span class="price">Rp. <?echo uang($r['harga']);?></span>
	  </div>
	  <?}?>
	  
	  </div> 
	  
	  </span> <img src="App/template/images/c_btm.gif" alt="" width="596" height="6" />