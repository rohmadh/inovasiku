<!-- slider -->

							<div class="slider-holder">
								<div class="flexslider">
									<ul class="slides">
<?
if ($handle = opendir(''.$base.'/images/slider/')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
			?>
										<li><img src="<?echo "$base";?>/images/slider/<?echo "$entry";?>" width="636" height="334" border="0" usemap="#Map" /></li>
										
									<?
        }
    }

    closedir($handle);
}
?>
										
									</ul>
								</div>
							</div>
							
							<!-- end of slider -->	
							<br class="clear" />
<br class="clear" />
<br class="clear" />
					
<div id="comments">
        <h2>Informasi Terbaru</h2>
        <ul class="commentlist">
          
		  <?
		  $q=mysql_query("select *,news.id as idd,kategori.kat as kate from news left join kategori on news.kat=kategori.id order by date DESC limit 0,4");
		  while($r=mysql_fetch_array($q)){
		  $sgbr="";
		  $doc = new DOMDocument();
				@$doc->loadHTML($r['isi']);

				$tags = $doc->getElementsByTagName('img');

				foreach ($tags as $tag) {
					$sgbr=$tag->getAttribute('src');
					
				}
			
		  ?>
		  
		  <li class="comment_even">
		  
            <div class="author"><span class="name"><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=news.read&id=".$r['idd']."",$key2));?>"><?echo stripslashes($r[judul]);?></a></span> </div>
            <div class="submitdate"><a href="#">Kategori:<?echo $r['kate'];?>,Update:<?echo $r['date'];?></a></div>
			
			<?if(strlen($sgbr)>1){?>
			<img class="avatar" src="<? echo $sgbr;?>" width="160" height="160" alt="" />
			<?}else{?>
			
            <p><? if(strlen($r['depan'])<150){echo stripslashes($r['depan']);}?></p>
			
			<?}?>
			
			<p align="right"><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=news.read&id=".$r['idd']."",$key2));?>" style="padding:5px 10px; font-weight:bold; color:#FFFFFF; background-color:#666666;">Baca</a></p>
          </li>
		  
		  <?}?>
		  </ul>
</div>
 <br class="clear" />
 <br class="clear" />
