<?
session_start();
include('.../header.php');
#$base='../A';
if($_GET['m']){
include(''.$base.'/api/'.$_GET['m'].'.php');
}
?>