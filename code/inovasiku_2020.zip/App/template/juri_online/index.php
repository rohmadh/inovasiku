﻿<?
include("App/header.php");
$base="App/template/".$_SESSION['apps']."";
include("".$base."/libs/php/fungsi.sinovida.php");
if(isset($_SESSION['login'])){}else{session_destroy();header("Location: App/login");}
if(isset($data['temp'])){
if($data['temp']==$_SESSION['temp']){}else{session_destroy();header("Location: App/login");}}

####ambil data master desa
$url = ''.$apiserv.'kelurahan:detil:'.$_SESSION['idskpduser'].'';
$json= file_get_contents($url);
$desa = json_decode($json,true);
####ambil data master kapanewon
$url = ''.$apiserv.'kapanewon:detil:'.$desa[0]['k1'].'';
$json= file_get_contents($url);
$kapanewon = json_decode($json,true);  
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Bappeda Integrated V.01 [PENILAIAN ONLINE]</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?echo $base;?>/assets/css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="<?echo $base;?>/assets/css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?echo $base;?>/assets/css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="<?echo $base;?>/assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
		<!-- jQuery -->
        <script src="<?echo $base;?>/assets/js/jquery.min.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="?">SINOVIDA V.01</a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> Bappeda Integrated [INOVASIKU] </a></li>
                </ul>

                <ul class="nav navbar-right navbar-top-links">
                    
                    </li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <?echo $_SESSION['namauser'];?><i class="fa fa-user fa-fw"></i>  <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            
                            <li><a href="App/login_juri/?mode=logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li class="sidebar-search">
                                <div class="input-group custom-search-form">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </span>
                                </div>
                                <!-- /input-group -->
                            </li>
                            <li>
                                <a href="?"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            </li>
                            
                            <li>
                                <a href="tables.html"><i class="fa fa-table fa-fw"></i> PENILAIAN <span class="fa arrow"></span></a>
								<ul class="nav nav-second-level">
									<li>
                                        <a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=sinovda_home",$key2));?>">Mulai</a>
                                    </li>
									
									
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                            
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>

            <!-- Page Content -->
            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                     <?php
					if($data['page']) {
					$page=$data['page'];
					$modul=$data['modul'];
					} else {
					  if($_SESSION['leveluser']=='0'){$page='home';}else{
					$page='sinovda_home';}
					$modul='page';
					}
					include("App/template/".$_SESSION['apps']."/".$modul."/".$page.".php");
					?>    
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>

        </div>
        <!-- /#wrapper -->
		<div id="targetrun">
		</div>
        
        <!-- Bootstrap Core JavaScript -->
        <script src="<?echo $base;?>/assets/js/bootstrap.min.js"></script>
		<script src="<?echo $base;?>/assets/js/dataTables/jquery.dataTables.min.js"></script>
        <script src="<?echo $base;?>/assets/js/dataTables/dataTables.bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="<?echo $base;?>/assets/js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="<?echo $base;?>/assets/js/startmin.js"></script>

    </body>
</html>
