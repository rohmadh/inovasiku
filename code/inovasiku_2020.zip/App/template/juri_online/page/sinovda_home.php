<?
$stmt=$conn->prepare("select *,case when now() between str_to_date(date1,'%d-%m-%Y') and str_to_date(date2,'%d-%m-%Y') then 'buka' else 'tutup' end as statusp from kelompok_event where id=:id");
$stmt->execute(array(':id'=>$_SESSION['idevent']));
$row=$stmt->fetch();
$tulisan=array('buka'=>'Mulai Penilaian','tutup'=>'Kegiatan telah selesai dilakukan.');
?>
<h1 class="page-header">Penjurian Online</h1>
                   <!-- /.col-lg-12 -->
<div class="row">
					
                        <div class="col-lg-12">

<div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3>Lembar Penilaian</h3>
                                </div>
                                <div class="panel-body">
									<div id="txtinfo">
									<p>
									Nama Juri : <?echo txthtml($_SESSION['namauser']);?> <br />
									Keterangan : <?echo txthtml($_SESSION['ket']);?> <br />
									<hr>
									Nama Event/Kegiatan : <?echo txthtml($row['nama']);?> <br />
									Keterangan : <?echo txthtml($row['uraian']);?> <br />
									</p>
									
                                    <hr>
									<p>
									<button type="button" class="btn btn-danger" onclick="loadpenilaian1('<?echo $_SESSION['idevent'];?>');" <?if($row['statusp']=='tutup'){echo "disabled";}?> >
									<i class="fa fa-list"></i>&nbsp;<?echo $tulisan[$row['statusp']]?></button>
									</p>
									</div>
									
									<div id='frmutama'></div>
                                </div>
                                <div class="panel-footer">
                                    <?echo date('Y');?>
                                </div>
                            </div>
</div>

</div>
<script>
function loadpenilaian1(k) {	
		$("#txtheader").html('PENILAIAN PESERTA');
		$("#frmutama").html('..LOADING..');
        $.ajax({url: '<?echo $base;?>/api.php?m=form.penilaian.peserta.1&ide='+k, success: function(result){
            $("#frmutama").html(result);
			$("#idjuri").val('<?echo $_SESSION['idjuri'];?>');
			$("#idjuri").attr('disabled','disabled');
			$("#txtinfo").hide('slide');
        }});
    }
</script>