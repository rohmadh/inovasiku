<?
$q="
select * from pendaftar where id='".$_GET['idp']."'
";
$stmt = $conn->prepare($q);
$stmt->execute();
$row = $stmt->fetch();
$conn = null;
?>
<script>
$("#judul").val("<?echo sanitize($row['judul']);?>");
$("#deskripsi").val("<?echo sanitize($row['deskripsi']);?>");
</script>