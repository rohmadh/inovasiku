<?
$q="select * from pendaftar where id='".$_GET['idp']."'";
$stmt = $conn->prepare($q);
$stmt->execute();
$row=$stmt->fetch();
?>
<center>
<h3>"<?echo $row['judul']?>"</h3>
<?echo $row['deskripdi']?><br />
<?$v=explode('=',$row['ytube']);?>
 <object data="http://www.youtube.com/embed/<?echo $v['1'];?>"
   width="560" height="315"></object>
</center>
<?

$conn = null;
?>
<br />
<br />