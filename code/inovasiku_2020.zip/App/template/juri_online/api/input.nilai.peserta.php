<?
if($_POST['mode']=='update'){
$q="select count(skor) as dcek from data where id_event='".$_POST['id_event']."' and id_usr='".$_POST['id_usr']."' and id_var='".$_POST['id_var']."'
";
$stmt = $conn->prepare($q);
$stmt->execute();
$row = $stmt->fetch();
if($row['dcek']<0){
$q2="insert into data (id_event,id_usr,id_var,isi,skor) values ('".$_POST['id_event']."','".$_POST['id_usr']."','".$_POST['id_var']."','".$_POST['isi']."','".$_POST['skor']."') 
";
}else{
$q2="update data set isi='".$_POST['isi']."',skor='".$_POST['skor']."' where id_event='".$_POST['id_event']."' and id_usr='".$_POST['id_usr']."' and id_var='".$_POST['id_var']."' and id_juri='".$_POST['id_juri']."'
";}
}
$stmt2 = $conn->prepare($q2);
$stmt2->execute();
$conn = null;
?>