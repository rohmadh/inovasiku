<?
function eksekusi($conn,$stmt) {
$stmt = $conn->prepare($q);
$stmt->execute();
}
?>