<?
function txtgroup($a,$conn) {
$q="select * from kelompok_penghargaan where id='".$a."'";
$stmt = $conn->prepare($q);
$stmt->execute();
$row=$stmt->fetch();
return $row['nama'];
}
function txtevent($a,$conn) {
$q="select * from kelompok_event where id='".$a."'";
$stmt = $conn->prepare($q);
$stmt->execute();
$row=$stmt->fetch();
return $row['nama'];
}
function txteventdetil($a,$conn) {
$q="select * from kelompok_event where id='".$a."'";
$stmt = $conn->prepare($q);
$stmt->execute();
$row=$stmt->fetch();
return array('nama'=>$row['nama'],'uraian'=>$row['uraian'],'mulai'=>$row['date1'],'akhir'=>$row['date2']);
}
function txtpendaftar($a,$conn) {
$q="select count(id) as jml from pendaftar where id_event='".$a."'";
$stmt = $conn->prepare($q);
$stmt->execute();
$row=$stmt->fetch();
return $row['jml'];
}
?>