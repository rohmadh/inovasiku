<?
session_start();
include("../header.php");
if($_GET['mode']=='save'){
mysql_query("insert into skpd_kegiatan (kode_program,kegiatan,skpd,tahun) value ('".$_GET['kprog']."','".$_GET['keg']."','".$_SESSION['idskpduser']."','".$_SESSION['thn']."')");
}
if($_GET['mode']=='del'){
mysql_query("delete from skpd_kegiatan where id='".$_GET['keg']."'");
mysql_query("delete from skpd_aktivitas where idkegiatan='".$_GET['keg']."'");

}
if($_GET['mode']=='update'){
mysql_query("update skpd_kegiatan set kegiatan='".$_GET['keg']."',tahun='".$_GET['uthn']."' where id='".$_GET['idd']."'");

}

?>