<?
session_start();
include("../header.php");
if($_GET['mode']=='monitor'){
$q=mysql_query("select * from skpd_kegiatan where skpd='".$_GET['id']."' and tahun='".$_SESSION['thn']."'");
}else{
$q=mysql_query("select * from skpd_kegiatan where skpd='".$_SESSION['idskpduser']."' and tahun='".$_SESSION['thn']."'");
}
?>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Nama Kegiatan</th>
											<th>ASB Aktivitas</th>
											<th>Belanja Non ASB <br />(Honorarium, Perjalanan Dinas)</th>
											<th>Total Anggaran</th>
											<th>Rincian Aktivitas</th>
											
                                        </tr>
                                    </thead>
                                    <tbody>
									<?while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            <td><text id="id<? echo $r['id'];?>"><? echo $r['id'];?></text></td>
                                            <td><text id="txt<? echo $r['id'];?>"><? echo $r['kegiatan'];?></text></td>
											<td align="right"><? echo uang($r['totalanggaran']);?></td>
											<td align="right"><? echo uang($r['totalnonasb']);?></td>
											<td align="right"><? echo uang($r['totalanggaran']+$r['totalnonasb']);?></td>
                                            <td><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=skpd.aktivitas&id=".$r['id']."",$key2));?>"><input type="button" value="RINCIAN"></a>
											<input type="button" value="EDIT" onclick="formedit('<?echo $r['id'];?>','<?echo $r['tahun'];?>');">
											<input type="button" value="X" onclick="delskpdkegiatan('<?echo $r['id'];?>');">
											</td>
                                        </tr>
									<?}?>
									</tbody>
								</table>
<script>
function delskpdkegiatan(val) {
		alert("hapus Kegiatan..??");
        $.ajax({url: 'App/api/skpd.kegiatan.php?mode=del&keg='+val, success: function(result){
            refreshtabel();
        }});
    }
</script>
