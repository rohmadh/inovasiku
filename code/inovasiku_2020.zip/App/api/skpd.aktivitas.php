<?
include("../header.php");
if($_GET['mode']=='save'){
mysql_query("insert into skpd_aktivitas (idkegiatan,aktivitas,idasb,nilaidriver) value ('".$_GET['idkeg']."','".$_GET['nama']."','".$_GET['idasb']."','".$_GET['nvar']."')");
}
if($_GET['mode']=='del'){
mysql_query("delete from skpd_aktivitas where id='".$_GET['idaktv']."'");
}
if($_GET['mode']=='update'){
mysql_query("update skpd_aktivitas set aktivitas='".$_GET['nama']."', nilaidriver='".$_GET['nvar']."' where id='".$_GET['idaktv']."'");
}

?>