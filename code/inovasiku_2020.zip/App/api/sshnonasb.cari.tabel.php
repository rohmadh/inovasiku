<?
session_start();
include("../header.php");
$q=mysql_query("select * from satuanharga".$_SESSION['thn']."
where nama like'%".$_GET['k']."%' and kode !=''");

?>
<div class="table-responsive">
                                 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>NAMA BARANG</th>
											<th>SATUAN</th>
											<th>HARGA</th>
											<th>PROSES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            <td><? echo $r['id'];?></td>
                                            <td id="txt<?echo $r['id'];?>"><? echo $r['nama'];?></td>
											<td id="sat<?echo $r['id'];?>"><? echo $r['satuan'];?></td>
											<td id="harga<?echo $r['id'];?>"><? echo $r['harga'];?></td>
                                            <td><input type="button" onclick="pilihssh(<? echo $r[id];?>);" value="pilih"></td>
                                        </tr>
									<?}?>
									
									</tbody>
								</table>
</div>
<script>
function pilihssh(val){
var txtssh=$("#txt"+val+"").text();
var txtsat=$("#sat"+val+"").text();
var txtharga=$("#harga"+val+"").text();
$("#idssh").attr("value",val);
$("#ur").val(txtssh);
$("#txtsat").val(txtsat);
$("#rpssh").val(txtharga);
$("#ssh").hide();
$("#jl").focus();
}
</script>