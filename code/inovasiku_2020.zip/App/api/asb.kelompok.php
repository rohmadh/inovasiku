<?
session_start();
include("../header.php");

############ simpan
if($_POST['mode']=='SAVE'){
$q=mysql_query("insert into kelompok (nama) value ('".sanitize($_POST['nama'])."')");
$rdata=array("status"=>"sukses","data"=>"".sanitize($_POST['nama'])."");
}
###################
if($_GET['mode']=='edit'){
mysql_query("update kelompok set nama='".$_GET['nama']."' where id='".$_GET['k']."'");
$rdata=array("status"=>"DATA BERHASIL [".$_GET['k']."]DIEDIT");
}
##############

if($_GET['mode']=='delete') {
#### hapus rincian asb
$q=mysql_query("select * from aktivitas where idkelompok='".$_GET['k']."'");
while($r=mysql_fetch_array($q)){
mysql_query("delete from asb".$_SESSION['thn']." where idaktivitas='".$r['id']."'");
}
### hapus aktivitas
mysql_query("delete from aktivitas where idkelompok='".$_GET['k']."'");
### hapus kelompok
mysql_query("delete from kelompok where id='".$_GET['k']."'");

$rdata=array("status"=>"DATA BERHASIL [".$_GET['kode']."]DIHAPUS");
}

########### hasil
header('Content-type: application/json');
echo json_encode($rdata);
?>