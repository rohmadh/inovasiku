<?
session_start();
include("../header.php");
if($_GET['mode']=='save'){
###cek max id
$q=mysql_query("select max(id) as idm from pengguna");
$r=mysql_fetch_array($q);
$idm=intval($r['idm'])+1;
###
mysql_query("insert into pengguna (id,nip,nama,passwd,skpd,level)
value ('".$idm."','".$_GET['nip']."','".$_GET['nama']."','".md5($_GET['psw'])."','".$_GET['skpd']."','1')
");

}

if($_GET['mode']=='update'){
if(strlen($_GET['psw'])>5){
#mysql_query("update pengguna set nip='".$_GET['nip']."',nama='".$_GET['nama']."',passwd='".md5($_GET['psw'])."',skpd='".$_GET['skpd']."' where nip='".$_GET['enip']."'");
mysql_query("update pengguna set nip='".$_GET['nip']."',nama='".$_GET['nama']."',passwd='".md5($_GET['psw'])."',skpd='".$_GET['skpd']."' where id='".$_GET['ide']."'");
}else{
#mysql_query("update pengguna set nip='".$_GET['nip']."',nama='".$_GET['nama']."',skpd='".$_GET['skpd']."' where nip='".$_GET['enip']."'");
mysql_query("update pengguna set nip='".$_GET['nip']."',nama='".$_GET['nama']."',skpd='".$_GET['skpd']."' where id='".$_GET['ide']."'");
}
}
echo mysql_error();
?>