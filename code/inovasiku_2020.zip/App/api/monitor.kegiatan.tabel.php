<?
session_start();
include("../header.php");
$qw=mysql_query("select *,skpd.id as id, count(skpd_kegiatan.id) as jmlkeg, sum(totalanggaran+totalnonasb) as jmlall from skpd_kegiatan 
left join skpd on skpd_kegiatan.skpd=skpd.id
where tahun='".$_SESSION['thn']."'
group by skpd.id
");
$q=mysql_query("select skpd.id as idd,skpd.namaskpd, 
sum(case when skpd_kegiatan.tahun='".$_SESSION['thn']."' then 1 else 0 end) as jmlkeg,
sum(case when skpd_kegiatan.tahun='".$_SESSION['thn']."' then totalanggaran+totalnonasb else 0 end) as jmlall
from skpd
left join skpd_kegiatan on skpd.id=skpd_kegiatan.skpd
group by skpd.id
order by jmlall DESC
");
echo mysql_error();
?>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            
											<th>SKPD</th>
                                            <th>Jumlah Kegiatan</th>
											<th>Total Anggaran</th>
											<th>Rincian Kegiatan</th>
											
                                        </tr>
                                    </thead>
                                    <tbody>
									<?$t=0;while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            
											<td><? echo $r['namaskpd'];?></td>
                                            <td><? echo $r['jmlkeg'];?></td>
											<td align="right"><? echo uang($r[jmlall]);?></td>
                                            <td><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=monitoring.kegiatan.skpd&id=".$r['idd']."",$key2));?>">[LIHAT]</a>
											
											</td>
                                        </tr>
									<?$t=$t+$r[jmlall];}?>
									</tbody>
								</table>
<script>
$("#totangg").html('<?echo uang($t);?>');
</script>