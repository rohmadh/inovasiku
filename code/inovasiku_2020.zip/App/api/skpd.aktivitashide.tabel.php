<?
session_start();
include("../header.php");
$q=mysql_query("select * from skpd_aktivitas where idkegiatan ='".$_GET['id']."'");
?>

<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Aktivitas</th>
											<th>Variabel Pengali</th>
											
											<th>PROSES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?
									
									$tall=0;
									while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            <td><text id="i<? echo $r['id'];?>"><? echo $r['id'];?></text></td>
                                            <td><b><text id="n<? echo $r['id'];?>"><? echo $r['aktivitas'];?></text></b>  (<label id="t<?echo $r[id];?>">0,00</label>)</td>
											<td><text id="p<? echo $r['id'];?>"><? echo $r['nilaidriver'];?></text>&nbsp;&nbsp;</td>
											
                                            <td>
											<input type="button" value="EDIT" onclick="formeditshow(<? echo $r['id'];?>);">&nbsp;<input type="button" value="X" onclick="hapusaktv(<?echo $r['id'];?>);">
											</td>
                                        </tr>
										
										<?
										$q2=mysql_query("select aktivitas as naktivitas, id as idd,vdriver,spesifikasi from aktivitas
										where id='".$r['idasb']."'");
										while($r2=mysql_fetch_array($q2)){
										###
										#### buat array driver
									
											$av = explode(",", $r2['vdriver']);
											$anv = explode(",", $r['nilaidriver']);
											#echo print_r($v);
											$dv=array();
											$idv=0;
											foreach ($av as $dr){
											$dv[$dr]=$anv[$idv];
											$idv=$idv+1;
											}
											#echo print_r($dv);
										###
										
										?>
										<tr>
                                            <td>ASB</td>
                                            <td><i><? echo $r2['naktivitas'];?></i> 
											<br />
											<i><? echo $r2['spesifikasi'];?></i>
											</td>
                                            <td><text id="txtp<? echo $r['id'];?>"><? echo $r2['vdriver'];?></text></td>
											<td></td>
											
                                        </tr>
										
										
										<?
										
										$q3=mysql_query("select * from asb".$_SESSION['thn']." 
										left join satuanharga".$_SESSION['thn']." on asb".$_SESSION['thn'].".idssh=satuanharga".$_SESSION['thn'].".id
										where asb".$_SESSION['thn'].".idaktivitas='".$r2['idd']."'
										");
										$t1=0;
										$tsub=0;
										while($r3=mysql_fetch_array($q3)){
										$t1=$t1+($r3['volume']*$r3['harga']);
										###########
										
										?>
										
										
										<?
										########buat array nilaidrivernya
										$nv=explode(",", $r['nilaidriver']);
										#echo print_r($nv);
										#$driver = array("Orang"=>"8", "Hari"=>"2");
										$v = explode(",", $r3['idvar']);
										
										
										$driver=$dv;
										#echo print_r($driver);
										###
										$t=1;
										foreach ($v as $value) {
										#if($value=='0'){echo 'ssh';}else{echo $value;}
										$t=$t*$driver[$value];
										}
										if($t=='0'){$t=1;}
										#echo "&nbsp;Total=".$t.",";
										#echo uang($r3['harga']*$r3['volume']*$t);
										$tsub=$tsub+($r3['harga']*$r3['volume']*$t);
										?>
										
										
										
										<?}$tall=$tall+$tsub;?>
										
										<script>
										$("#t<?echo $r['id'];?>").html('Rp.<?echo uang($tsub);?>');
										</script>
										
										<?}?>
									<?}?>
									</tbody>
								</table>
	<h3>Belanja Non ASB (Honorarium Selain Uang saku peserta,Perjalanan Dinas)</h3><br />
	
	<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            
                                            <th colspan="3">Uraian</th>
											<th>Total</th>
											<th>PROSES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<tr>
									<td colspan="2">SSH:<input type="text" id="ur" size="70" onfocus="hidebebas();"><input type="button" value="CARI" onclick="carissh();"><input type="button" value="manual" onclick="showbebas();">
									<div id="bebas">
									<hr>
									Uraian<input type="text" id="bu" size="70"><br/>
									Harga Satuan:<input type="text" id="bh" size="10"> Satuan:<input type="text" id="bs" size="5">x Volume:<input type="text" id="bv" size="10">
									<input type="button" value="PROSES" onclick="savebebas();">
									</div>
									<div id="ssh"></div>
									</td>
									<td><input type="text" id="jl" size="5"><input type="text" id="txtsat" size="10" disabled><input type="hidden" id="idssh" size="5">
									<input type="hidden" id="rpssh" size="12">
									</td>
									<td><input type="button" value="SIMPAN" onclick="savenonasb();"></td>
									</tr>
									<?$qn=mysql_query("select * from non_asb where idkegiatan='".$_GET['id']."'");
									$tnon=0;
									while($rn=mysql_fetch_array($qn)){
									$tnon=$tnon+$rn['total'];
									?>
									<tr>
									<td><?echo $rn['uraian'];?></td>
									<td><?echo $rn['satuan'];?></td>
									<td><input type="text" size="4" id="newvol<?echo $rn['id'];?>"><input type="button" value="OK" onclick="editnonasb(<?echo $rn['id'];?>);"></td>
									<td align="right"><?echo uang($rn['total']);?></td>
									<td><input type="button" value="X" title="HAPUS" onclick="hapusnonasb(<?echo $rn['id'];?>);">
									
									</td>
									</tr>
									<?}?>
									<tr>
									<td></td>
									<td><b>Total</b></td>
									<td></td>
									<td align="right"><b><?echo uang($tnon);?></b></td>
									<td></td>
									</tr>
	</tbody>
	</table>
	
	<script>
	$("#t").html('Rp.<?echo uang($tall+$tnon);?>');
	</script>
	<script>
function hapusaktv(val) {
        $.ajax({url: 'App/api/skpd.aktivitas.php?mode=del&idaktv='+val, success: function(result){
            refreshtabel();
        }});
    }
</script>
<script>
function savenonasb() {
		var ur=$("#ur").val();
		var jl=$("#jl").val();
		var issh=$("#idssh").val();
		var rp=$("#rpssh").val();
		var sat=$("#txtsat").val();
        $.ajax({url: 'App/api/nonasb.php?mode=save&idkeg=<?echo $_GET['id'];?>&ur='+ur+'&jl='+jl+'&issh='+issh+'&rp='+rp+'&sat='+sat, success: function(result){
            refreshtabel();
        }});
    }
</script>
<script>
function carissh() {
		var val=$("#ur").val();
        $.ajax({url: 'App/api/sshnonasb.cari.tabel.php?k='+val, success: function(result){
			$("#ssh").show();
            $("#ssh").html(result);
        }});
    }
</script>
<script>
function hapusnonasb(k) {
        $.ajax({url: 'App/api/nonasb.php?mode=hapus&k='+k, success: function(result){
			refreshtabel();
        }});
    }
</script>
<script>
function editnonasb(k) {
        var x=$("#newvol"+k+"").val();
		$.ajax({url: 'App/api/nonasb.php?mode=edit&k='+k+'&vol='+x, success: function(result){
			refreshtabel();
        }});
    }
</script>
<script>
function showbebas() {
    $("#bebas").show();
	$("#bu").focus();
    }
</script>
<script>
function hidebebas() {
    $("#bebas").hide();
    }
</script>
<script>
function savebebas() {
		var ur=$("#bu").val();
		var jl=$("#bv").val();
		var rp=$("#bh").val();
		var sat=$("#bs").val();
        $.ajax({url: 'App/api/nonasb.php?mode=save&idkeg=<?echo $_GET['id'];?>&ur='+ur+'&jl='+jl+'&rp='+rp+'&sat='+sat, success: function(result){
            refreshtabel();
        }});
    }
</script>
<script>$("#bebas").hide();</script>

<?
mysql_query("update skpd_kegiatan set totalanggaran='".$tall."',totalnonasb='".$tnon."' where id='".$_GET['id']."'");
?>