<?
include("../header.php");
if($_GET['mode']=='save'){
mysql_query("insert into non_asb (idkegiatan,idssh,uraian,vol,satuan,hrgsat,sat,total) value ('".$_GET['idkeg']."','".$_GET['issh']."','".$_GET['ur']."','".$_GET['jl']."','".uang($_GET['rp'])."X ".$_GET['jl']." ".$_GET['sat']."','".$_GET['rp']."','".$_GET['sat']."','".$_GET['jl']*$_GET['rp']."')");
}
if($_GET['mode']=='hapus'){
mysql_query("delete from non_asb where id='".$_GET['k']."'");
}
if($_GET['mode']=='cari'){
$q=mysql_query("select * from non_asb where id='".$_GET['k']."'");
$r=mysql_fetch_array($q);
echo $r['uraian'];
}
if($_GET['mode']=='edit'){
$q=mysql_query("select * from non_asb where id='".$_GET['k']."'");
$r=mysql_fetch_array($q);
mysql_query("update non_asb set vol='".$_GET['vol']."',total='".$_GET['vol']*$r['hrgsat']."',satuan='".uang($r['hrgsat'])."X ".$_GET['vol']." ".$r['sat']."' where id='".$_GET['k']."'");
}

?>