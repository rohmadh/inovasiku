<?
session_start();
include("../header.php");

############ simpan
if($_POST['mode']=='SAVE'){
$qc=mysql_query("select max(id) as jid from satuanharga".$_SESSION['thn']."");
$rc=mysql_fetch_array($qc);
$q=mysql_query("insert into satuanharga".$_SESSION['thn']." (id,nama,satuan,harga,tahun) value ('".($rc['jid']+1)."','".$_POST['nama']."','".$_POST['satuan']."','".$_POST['harga']."','".$_SESSION['thn']."')");
$rdata=array("status"=>"sukses","data"=>"".$_POST['nama']."");
}
###################
if($_GET['mode']=='update'){
mysql_query("update satuanharga".$_SESSION['thn']." set nama='".$_GET['n']."',satuan='".$_GET['s']."',harga='".$_GET['h']."',tahun='".$_SESSION['thn']."' where id='".$_GET['k']."'	");
}
##############

if($_POST['mode']=='del') {
$qt=mysql_query("delete from book_mast where book_id='".$_POST['kode']."'");
$rdata=array("status"=>"DATA BERHASIL [".$_POST['kode']."]DIHAPUS");
}

########### hasil
header('Content-type: application/json');
echo json_encode($rdata);
?>