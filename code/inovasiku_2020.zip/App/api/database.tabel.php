<?
session_start();
include("../header.php");
$q=mysql_query("
select table_name,update_time from information_schema.TABLES where table_name like 'asb%'
and table_name !='asb_variabel'
order by table_name ASC
");
$q2=mysql_query("
select table_name,update_time from information_schema.TABLES where table_name like 'satuan%'
and table_name !='asb_variabel'
order by table_name ASC
");
echo mysql_error();
?>
<table width="90%">
<tr>
<td>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            
											<th>DATABASE ASB</th>
                                            <th>status update</th>
											
                                        </tr>
                                    </thead>
                                    <tbody>
									<?while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            
											<td><? echo $r['table_name'];?></td>
                                            <td><? echo $r['update_time'];?>
											</td>
                                        </tr>
									<?}?>
									</tbody>
								</table></td>
<td>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            
											<th>DATABASE SATUAN HARGA</th>
                                            <th>status update</th>
											
                                        </tr>
                                    </thead>
                                    <tbody>
									<?while($r=mysql_fetch_array($q2)){?>
                                        <tr>
                                            
											<td><? echo $r['table_name'];?></td>
                                            <td><? echo $r['update_time'];?>
											</td>
                                        </tr>
									<?}?>
									</tbody>
								</table>
</td>
</tr>
</table>