<?
session_start();
ob_start();
include("../header.php");
?>
<?
if($_GET['mode']=='logout'){session_destroy();}
if($_POST['tbl']=='Login'){
#echo $cek1;
$nip=cleanerpost($_POST['username'],'string');
$psw=mysql_escape_string($_POST['password']);
$cek1=md5($psw);
$a=0;$b=0;$d=0;$k=0;
$q1="select *,keu_pengguna.id as idd,skpd.namaskpd as skpd,keu_pengguna.skpd as idskpd from keu_pengguna 
left join skpd on keu_pengguna.skpd=skpd.id
where nip=:nip and passwd=:psw";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q1);
$stmt->bindValue(':nip', $nip, PDO::PARAM_STR);
$stmt->bindValue(':psw', $cek1, PDO::PARAM_STR);
$stmt->execute();
$r1 = $stmt->fetch();
#echo $stmt->rowCount();
 if(($stmt->rowCount()==1) and (strlen($r1['nip'])>0)) {
 $_SESSION['login']='1';$_SESSION['namauser']=$rprofil['nama'];$_SESSION['nipuser']=$r1['nip'];$_SESSION['iduser']=$r1['idd'];
 $_SESSION['skpduser']=$r1['skpd'];$_SESSION['leveluser']=$r1['level'];$_SESSION['idskpduser']=$r1['idskpd'];$_SESSION['thn']=date('Y');
 $_SESSION['txtpmbtingkat']=$r1['skpd'];$_SESSION['pmbtingkat']=$r1['idskpd'];
 header("Location: ../");
 }else{ echo "<center>----LOGIN GAGAL</center>";}
}

?>
<!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Login Form</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="fileloader/css/modal-loading.css" />
  <link rel="stylesheet" type="text/css" href="fileloader/css/modal-loading-animate.css" />
  <script src="../js/jquery-1.7.0.min.js"></script>
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<body>
  <section class="container">
    <div class="login">
      <h1>LOGIN SISTEM SINOVDA V.01 </h1>
	  <br />
	  <center><img src="logokp.png" width="30%">
	  <br /><b></b>
	  </center>
      <form method="post" action="index.php">
        <p align="center"><input type="text" id="username" name="username" value="" placeholder="Username"></p>
        <p align="center"><input type="password" id="password" name="password" value="" placeholder="Password"></p>
		
        <p class="remember_me">
          <label>
            
          </label>
        </p>
        <p class="submit"><input type="button" name="tbl" value="Login" onclick="cekuser();"></p>
      </form>
    </div>

    <div class="login-help">
      <p>Untuk Informasi dan Bantuan Silahkan Menghubungi Bagian IT</p>
    </div>
	<div id="result">
	</div>
  </section>
<script type="text/javascript" src="fileloader/js/modal-loading.js"></script>
		<script type="text/javascript">

			function loadingOut(loading) {
				setTimeout(() => loading.out(), 3000);
			}

			function normal() {
				var loading = new Loading();

				loadingOut(loading);
			}

			function verticalTextColor() {
				var loading = new Loading({
					title: 					'JQueryScript',
					titleColor: 			'rgb(217, 83, 79)',
					discription: 			'Loading...',
					discriptionColor: 		'rgb(77, 150, 223)',
					animationOriginColor: 	'rgb(33, 179, 132)',
					mask: 					true,
					loadingPadding: 		'20px 50px',
			    	defaultApply: 	true,
				});

				loadingOut(loading);
			}

			function verticalNoTitle() {
				var loading = new Loading({
					discription: 			'Loading...',
			    	defaultApply: 	true,
				});

				loadingOut(loading);
			}

			function verticalNoTitleAnddiscription() {

				var loading = new Loading({
					animationOriginColor: 	'rgb(217, 83, 79)',
			    	defaultApply: 	true,
				});

				loadingOut(loading);
			}

			function verticalBgColor() {

				var loading = new Loading({
					loadingBgColor: 	'rgb(77, 150, 223)',
			    	defaultApply: 	true,
				});

				loadingOut(loading);
			}

			function verticalImageLoadingAnimation() {

				var loading = new Loading({
					loadingAnimation: 		'image',
					animationSrc: 			'http://img.lanrentuku.com/img/allimg/1212/5-121204194028.gif',
			    	defaultApply: 	true,
				});

				loadingOut(loading);
			}

			function horizontalNormal() {

				var loading = new Loading({
					direction: 'hor',
			    	defaultApply: 	true,
				});

				loadingOut(loading);
			}


			function horizontalCustomStyle() {

				var loading = new Loading({
					title: ' Title',
					direction: 'hor',
					discription: 'Loading...',
			    	defaultApply: 	true,
				});

				loadingOut(loading);
			}

			function horizontalNoTitle() {

				var loading = new Loading({
					direction: 'hor',
					discription: 'Loading...',
			    	defaultApply: 	true,
				});

				loadingOut(loading);
			}

			function noTransitionAnimation() {
				var loading = new Loading({
					direction: 'hor',
					discription: '..PROCESSING...',
					animationIn: false,
					animationOut: false,
			    	defaultApply: 	true,
				});

				loadingOut(loading);
			}

		</script>
  
</body>
<script>
function cekuser() {
var username = $("#username").val();
var password = $("#password").val();
$("#result").html('<center><b>....PROSES....</b></center>');
noTransitionAnimation();
  $.post("proses.php", {username: username,password: password,tbl:'Login'}, function(result){
    if(result=='ok'){$("#result").html('<center>..LOGIN SUKSES..</center>');window.location='../';} else {$("#result").html(result);alert("LOGIN GAGAL")}
  });
	}
</script>
</html>
