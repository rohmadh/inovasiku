<?

#if($_SESSION['auth']=='') {
#header('Location:login.php');
#}
##################
#if(isset($_SESSION['kunci'])){
#$kunci=$_SESSION['kunci'];}else{
#$_SESSION['kunci']=time();
#$kunci=$_SESSION['kunci'];
#}

###
$key="raihan";

function encrypt1($string, $key) {
  $result = '';
  for($i=0; $i<strlen($string); $i++) {
    $char = substr($string, $i, 1);
    $keychar = substr($key, ($i % strlen($key))-1, 1);
    $char = chr(ord($char)+ord($keychar));
    $result.=$char;
  }

  return base64_encode($result);
}

function decrypt1($string, $key) {
  $result = '';
  $string = base64_decode($string);

  for($i=0; $i<strlen($string); $i++) {
    $char = substr($string, $i, 1);
    $keychar = substr($key, ($i % strlen($key))-1, 1);
    $char = chr(ord($char)-ord($keychar));
    $result.=$char;
  }

  return $result;
}
######################
####################### ncrtyp2
$salt ='rohmad2';

    function encrypt($text,$key)
    {
        return trim(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $salt, $text, MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND))));
    }

    function decrypt($text,$key)
    {
        return trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $salt, base64_decode($text), MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)));
    }

#echo encrypt(urlencode("id=123312121212&dinas=rosesss"));echo "<br>";
#echo decrypt("NqaA11o6bUoxZsEhoNKztgk74hd3JoUOdelV7otxvtN/Jq9tULFmxTXleD/eD5etXHfx7g2KUBlVqRD69BOAxg==");
$dtes=decrypt("r8C9P6juLscd3F//NOYYiVIouytQn94AC6we+k9WKnogu9oni/DXok9ZXCh4ivp3DaXAzH3705Ha/q5t+McS17t+AhdXOcTbhEfCRQE8bEYswnV2JM5ZWpoS7bFMu7XK",$key2);
######################
include("config/db.php.inc");

function ubahurl($url){
$urlnew=encrypt(urlencode($url),$key2);
return $urlnew;
}
$key2='mysecretkey';
$link="index.php?rohmad=1&t=2";
$str1= encrypt($link,$key2);
#echo decrypt($str1,$key2);
###print_r($_REQUEST['pid']);
###echo $_GET['pid'];
$str3=rawurldecode(decrypt(rawurldecode($_REQUEST['pid']),$key2));
$str31=parse_url($str3);
##########print_r($str31['query']);
#echo var_dump(explode('&',$str3));
$parameters = $arr["query"];
parse_str($str31['query'], $data);
###print_r($data['page']);
$strtes=urldecode($dtes);
###echo urldecode(decrypt($_GET['pid'],$key2));echo "<br>";
###echo urldecode($dtes);
parse_str($dtes, $datates);
#echo "<br>";
###echo $datates['modul'];
$strtes2=parse_url(urldecode($dtes));
###echo $strtes2['query'];
parse_str($strtes2['query'], $datates2);
###echo $datates2['modul'];
##################
#echo "<br>";
#echo urlencode("?modul=user&page=profile");
function uang($var){
return number_format($var,2,",",".");
}
include("sanitasi.php");
include("fungsi.umum.php");
$base='template/espj';
include(''.$base.'/dbcnf/db.php');
?>
