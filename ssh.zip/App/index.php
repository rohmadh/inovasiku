<?
header("Location: ../");
?>
