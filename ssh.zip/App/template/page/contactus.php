<?
$q=mysql_query("select * from setting");
$r=mysql_fetch_array($q);

?>
<span class="titl">Contact Us</span> 
	<span class="txt" style="width:400px;"> 
	<?
	echo $r['namausaha'];
	?>
	<br/>
	<br />
	<?
	echo $r['alamat'];
	?>
	</span> <img src="App/template/images/grl.jpg" alt="" width="167" height="109" style="margin:10px 0 0 10px;" /> 
	<span class="txt">  <br />
      
      </span> 