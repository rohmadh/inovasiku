<!--##################-->

<script type="text/javascript">
$(document).ready(function () {
    $("a[rel^='prettyPhoto']").prettyPhoto({
        theme: 'dark_rounded',
        overlay_gallery: false
    });
});
</script>
<link rel="stylesheet" href="App/prettyPhoto/prettyPhoto.css" type="text/css" />
<script type="text/javascript" src="App/prettyPhoto/jquery-prettyPhoto.js"></script>
<!--##################-->

    
      <!-- ####################################################################################################### -->
      <div id="gal">
        <h2>Album Foto <?if($data['dd']){?>-->[ALBUM <?echo $data['dd']?>]<?}?></h2>
        <ul class="commentlist">


			
<?
if(strlen($data['dd'])>0){
$directory2 = "App/gallery/".$data['dd']."/";
if ($handle = opendir($directory2)) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {?>
			<li class="comment_even">
            <a href="App/gallery/<? echo $data['dd'];echo"/";echo $entry;?>" rel="prettyPhoto[gallery1]" title="<?echo $entry;?>"><img src="App/gallery/<? echo $data['dd'];echo"/";echo $entry;?>" alt="" width="160px" height="160px"/></a>
			
			</li>
			<?
        }
    }

    closedir($handle);
}
}
if (glob($directory2 . "*.jpg") != false)
{
 $filecount = count(glob($directory2 . "*.jpg"));
 #echo $filecount;
}
else
{
 $filecount= 0;
}
#echo $filecount;
$i=1;
while($i<($filecount+1)) {
?>
          
<? $i++; };?> 
        </ul>
      </div>
 

 
<br class="clear" />
<br class="clear" />
					
<div id="gal">
        
        <ul class="commentlist">
         
		  <?
if($data['dd']==''){
 $directory = "App/gallery/";
 $ldir=glob($directory. "*",GLOB_ONLYDIR);
 foreach($ldir as $odir){
				$rdir=explode("/",$odir);
				
				$dir = "App/gallery/".$rdir[2]."/";

// Open a directory, and read its contents
if (is_dir($dir)){
  if ($dh = opendir($dir)){
		
		
    while (($file = readdir($dh)) !== false){
	    if(strlen($file)>4) {
               //echo "filename:" . $file . "<br>";
			   break;
			   } 
			   
    }
    closedir($dh);
  }
}
				
				
				?>
				<li class="comment_even"> 
				<img src="App/gallery/<?echo $rdir[2];?>/<?echo $file;?>" alt="" width="150px" height="150px"/><br>
				<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=gallery&dd=".$rdir[2]."",$key2));?>"><?echo $rdir[2];?></a>
				
				 </li>

				<?
				
			
			}}?>

			
</ul>
		  
		  
		  
            
			
			
         
		  
		  
		  
</div>
 <br class="clear" />
 <br class="clear" />