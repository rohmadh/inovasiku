<!-- slider -->

							<div class="slider-holder">
								<div class="flexslider">
									<ul class="slides">
<?
if ($handle = opendir(''.$base.'/images/slider/')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
			?>
										<li><img src="<?echo "$base";?>/images/slider/<?echo "$entry";?>" width="636" height="334" border="0" usemap="#Map" /></li>
										
									<?
        }
    }

    closedir($handle);
}
?>
										
									</ul>
								</div>
							</div>
							
							<!-- end of slider -->	
							<br class="clear" />
<br class="clear" />
<br class="clear" />
					
<div id="comments">
        <h2>Informasi Terbaru</h2>
        <ul class="commentlist">
          
		  <?
		  $q=mysql_query("select *,kategori.kat as kate from news left join kategori on news.kat=kategori.id order by date DESC limit 0,3");
		  while($r=mysql_fetch_array($q)){
		  $doc = new DOMDocument();
				@$doc->loadHTML($r['depan']);

				$tags = $doc->getElementsByTagName('img');

				foreach ($tags as $tag) {
					$sgbr=$tag->getAttribute('src');
					
				}
		  ?>
		  <li class="comment_even">
            <div class="author"><span class="name"><a href="#"><?echo $r[judul];?></a></span> </div>
            <div class="submitdate"><a href="#">Kategori:<?echo $r['kate'];?>,Update:<?echo $r['date'];?></a></div>
			<?if(strlen($sgbrs)>1){?>
			<img class="avatar" src="<? echo $sgbr;?>" width="80" height="80" alt="" />
			<?}?>
            <p><?echo $r[depan];?></p>
          </li>
		  
		  <?}?>
		  </ul>
</div>

