<?
$_SESSION['status']='publicadd';
if($_POST['nama']){
$_SESSION['status_u']=$_POST['nama'];
$_SESSION['status_e']=$_POST['email'];

$qc=mysql_query("insert into daftar(nama,email) values ('".$_POST['nama']."','".$_POST['email']."')");
header('Location:App/publicadd.php?pid='.rawurlencode(encrypt("?modul=admin&page=alumni.add",$key2)).'');
// multiple recipients
//$to  = 'aidan@example.com' . ', '; // note the comma
$to = $_POST['email'];

// subject
$subject = 'Pendaftaran Alumni ';

// message
$message = '
Untuk Mengisi Form Alumni silahkan klik Link berikut ini <a href="">PENGISIAN FORM ALUMNI</a>
';

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers

$headers .= 'From: admin <tsipil.ft@gmail.com>' . "\r\n";


// Mail it
mail($to, $subject, $message, $headers);
}

echo mysql_error();
?>

<!-- Small Nav -->
		
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Pendaftar Data Alumni</h2>
					</div>
					<!-- End Box Head -->
	<table cellspacing='0'>				
					    <!-- Table Header -->
	<thead>
		<tr>
			<th colspan="2">Biodata Alumni</th>
			
			
		</tr>
	</thead>
	<!-- Table Header -->

	<!-- Table Body -->
	<tbody>
	<tr>
	<td>Nama</td><td><?echo $_POST['nama'];?></td>
	</tr>
	
	<tr>
	<td>Email</td><td><?echo $_POST['email'];?></td>
	</tr>
	
	</tbody>
	</table>
    <p>SILAHKAN CEK EMAIL UNTUK PROSES PENGISIAN FORM ALUMNI atau <b>KLIK LINK</b> berikut
    
    <a href="App/publicadd.php?pid=<? echo rawurlencode(encrypt("?modul=admin&page=alumni.add",$key2));?>"><span>Pendataan Alumni</span></a>
    TERIMA KASIH</p>	
						
					
				</div>
				<!-- End Box -->