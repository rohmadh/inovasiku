<style type="text/css">

.page
{
float: right;
margin: 0;
padding: 0;
}
.page li
{
	list-style: none;
	display:inline-block;
}
.page li a, .current
{
display: block;
padding: 5px;
text-decoration: none;
color: #8A8A8A;
}
.current
{
	font-weight:bold;
	font-size:14px;
	color: #000;
}
.button
{
padding: 3px 15px;
text-decoration: none;
background: wwgrey;
color: #F3F3F3;
font-size: 12PX;
border-radius: 2PX;
margin: 0 4PX;
display: block;
float: left;
}
</style>

<form method="POST" action="?pid=<? echo rawurlencode(encrypt("?modul=page&page=alumnisearch",$key2));?>">
	<table>
	<thead>
	<tr>
	<th colspan=2><label>Pencarian Berdasarkan:</label></th>
	</tr>
	</thead>
	<tr>
	
	<td>
	<select name="data">
	<option value="nama">Nama</option>
	<option value="alamat">Alamat</option>
	<option value="alamatktr">Alamat Instansi</option>
	<option value="s1">S1</option>
	<option value="s2">S2</option>
	<option value="s3">S3</option>
	</select> 
	<input type="text" name="t" id="name" value="" size="50" />
	<label>Tahun Masuk:</label> 
	<select name="qtmasuk">
	<option value="">--SEMUA--</option>
	<?$q=mysql_query("select tmasuk from akademik where tmasuk >1000 group by tmasuk  order by tmasuk ASC");
	while($roptt=mysql_fetch_array($q)) {
	?>
	<option value="<?echo $roptt['tmasuk'];?>"><?echo $roptt['tmasuk'];?></option>
	<?}?>
	</select>
	<label>Propinsi<span></span></label>
									<select name="prop" id="tes">
									<option value="" >--SEMUA--</option>
									<? 
									
									$q=mysql_query("select * from regions where city is null");
									
									while($r=mysql_fetch_array($q)){
									?>
									<option value="<?echo $r['province'];?>" ><?echo $r['name'];?></option>
									<?}?>
									</select>
	</td>
	
	<td>
	<input type="submit" value="Cari">
	</td>
	</tr>
	
	</table>
	
	</form>
	
      <table cellspacing='0' width="90%"> <!-- cellspacing='0' is important, must stay -->

	<!-- Table Header -->
	<thead>
		<tr>
			<th>No</th>
			<th>Nama Lengkap dan Gelar</th>
			<th>Studi</th>
			<th>Akun FB/Twitter</th>
			<th>Instansi</th>
			<th>Jabatan</th>
			<th>Alamat Kantor</th>
			<th>Lihat</th>
		</tr>
	</thead>
	<!-- Table Header -->

	<!-- Table Body -->
	<tbody>
	<?
	$start=0;
	$limit=25;

	if(isset($data['id']))
		{
			$id=$data['id'];
			$start=($id-1)*$limit;
	}

	
	   
	$q=mysql_query("select * from data_alumni order by nama ASC LIMIT ".$start.", ".$limit."");
	echo mysql_error();
	$i=1;	
    while($r=mysql_fetch_array($q)){
    
    ?>

		<tr>
		    <td><?echo $i+$start;?></td>
			<td align="left"><?echo $r['nama'];?></td>
			<td align="left">
			
			<?
			$qs=mysql_query("select * from akademik where idorg='".$r['id']."'");
			while($rs=mysql_fetch_array($qs)) {
			echo $rs['jenjang'];
			echo "&nbsp;-&nbsp;";
			echo $rs['universitas'];
			echo "<br />";
			}
			?>
			
			</td>
			<td align="left"><?echo $r['fb'];?></td>
			<td align="left"><?echo $r['instansi'];?></td>
			<td align="left"><?echo $r['jabatan'];?></td>
			<td align="left"><?echo $r['alamatktr'];?></td>
			<td align="left"><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=alumni.view&mode=view&id=".$r['id']."",$key2));?>">lihat</a></td>
		</tr><!-- Table Row -->
	<?$i=$i+1;}?>
	<tr><td colspan="8">
	<?
	$rows=mysql_num_rows(mysql_query("select * from data_alumni"));
$total=ceil($rows/$limit);

if($id>1)
{ ?>
	
	<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=home&id=".($id-1)."",$key2));?>" class='button'><< SEBELUMNYA</a>
	<?
}
if($id!=$total)
{?>
	<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=home&id=".($id+1)."",$key2));?>" class='button' >LANJUT >></a>
	<?
}

echo "<ul class='page'> Total: ".$rows." data, &nbsp;&nbsp;&nbsp;Halaman Ke- ";
if($data['id']>1){$i=$data['id'];}else{$i=1;}$lawal=$i+5;
		for($i=$i;$i<=$lawal;$i++)
		{
			if($i==$id) { echo "<li class='current'>".$i."</li>"; }
			
			else { ?><li><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=home&id=".$i."",$key2));?>">
			<? echo $i;?></a></li><? }
		}
echo".........";
		for($i=$total-4;$i<=$total;$i++)
		{
			if($i==$id) { echo "<li class='current'>".$i."</li>"; }
			
			else { ?><li><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=home&id=".$i."",$key2));?>">
			<? echo $i;?></a></li><? }
		}
echo "</ul>";
	?>
	</td>
	</tr>

	</tbody>
	<!-- Table Body -->

</table>