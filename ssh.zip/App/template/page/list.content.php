<?
if($data['id']>0){
$q=mysql_query("select *,news.id as idd,kategori.kat as kate from news 
left join kategori
on news.kat=kategori.id
where news.kat='".$data['id']."' order by date DESC");}else{
if($data['id']=='cari'){
$q=mysql_query("select *,news.id as idd, kategori.kat as kate from news 
left join kategori
on news.kat=kategori.id
where judul like '%".$_POST['q']."%' OR depan like '%".$_POST['q']."%' OR depan like '%".$_POST['q']."%'
order by date DESC");
}else{
$q=mysql_query("select *,news.id as idd,kategori.kat as kate from news 
left join kategori
on news.kat=kategori.id
order by date DESC");}

}
while($r=mysql_fetch_array($q)){
?>
<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=news.read&id=".$r['idd']."",$key2));?>"><h3>&raquo;<?echo stripslashes($r['judul']);?></h3></a>
<font size="1"><i>Kategori: <?echo $r['kate'];?>Update: <?echo $r['date'];?></i></font>
<?}?>

<br class="clear">
<br class="clear">
<?echo stripslashes($r['depan']);?>
<br class="clear">
<?echo stripslashes($r['isi']);?>
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
