<form method="POST">
	<table>
	<thead>
	<tr>
	<th colspan=2><label>Pencarian Berdasarkan:</label></th>
	</tr>
	</thead>
	<tr>
	
	<td>
	<select name="data">
	<option value="nama">Nama</option>
	<option value="alamat">Alamat</option>
	<option value="alamatktr">Alamat Instansi</option>
	<option value="s1">S1</option>
	<option value="s2">S2</option>
	<option value="s3">S3</option>
	</select> 
	<input type="text" name="t" id="name" value="" size="50" />
	<label>Tahun Masuk:</label> 
	<select name="qtmasuk">
	<option value="">--SEMUA--</option>
	<?$q=mysql_query("select tmasuk from akademik where tmasuk >1000 group by tmasuk  order by tmasuk ASC");
	while($roptt=mysql_fetch_array($q)) {
	?>
	<option value="<?echo $roptt['tmasuk'];?>"><?echo $roptt['tmasuk'];?></option>
	<?}?>
	</select>
	<label>Propinsi<span></span></label>
									<select name="prop" id="tes">
									<option value="" >--SEMUA--</option>
									<? 
									
									$q=mysql_query("select * from regions where city is null");
									
									while($r=mysql_fetch_array($q)){
									?>
									<option value="<?echo $r['province'];?>" ><?echo $r['name'];?></option>
									<?}?>
									</select>
	</td>
	
	<td>
	<input type="submit" value="Cari">
	</td>
	</tr>
	
	</table>
	
	</form>
	
      <table cellspacing='0'> <!-- cellspacing='0' is important, must stay -->

	<!-- Table Header -->
	<thead>
		<tr>
			<th>Nama Alumni</th>
			<th>Studi</th>
			<th>FB/Twitter</th>
			<th>Instansi</th>
			<th>Jabatan</th>
			<th>Alamat Kantor</th>
			<th>Lihat</th>
		</tr>
	</thead>
	<!-- Table Header -->

	<!-- Table Body -->
	<tbody>
	<?
	if($_POST['data']){
	$i=1;
	   if($_POST['data']=='s1'){
	    $q=mysql_query("select * from akademik left join data_alumni 
		on akademik.idorg=data_alumni.id
		where universitas like'%".$_POST['t']."%' and jenjang='S1' and tmasuk like '%".$_POST['qtmasuk']."%'");
		
	     } 
		else if($_POST['data']=='s2'){
	    $q=mysql_query("select * from akademik left join data_alumni 
		on akademik.idorg=data_alumni.id
		where universitas like'%".$_POST['t']."%' and jenjang='S2' and tmasuk like '%".$_POST['qtmasuk']."%'");
		
	     } 
		 else if($_POST['data']=='s3'){
	    $q=mysql_query("select * from akademik left join data_alumni 
		on akademik.idorg=data_alumni.id
		where universitas like'%".$_POST['t']."%' and jenjang='S3' and tmasuk like '%".$_POST['qtmasuk']."%'");
		
	     } 
		 
		 
		 else {
    $q=mysql_query("select * from akademik left join data_alumni
			on akademik.idorg=data_alumni.id
			left join regions on data_alumni.region_id=regions.id
			where ".$_POST['data']." like'%".$_POST['t']."%' and tmasuk like '%".$_POST['qtmasuk']."%' 
			and province like '%".$_POST['prop']."%'
			group by data_alumni.id");
	      }
	echo mysql_error();
		
    while($r=mysql_fetch_array($q)){
    
    ?>

		<tr>
			<td><?echo $r['nama'];?></td>
			<td align="left">
			
			<?
			$qs=mysql_query("select * from akademik where idorg='".$r['id']."'");
			while($rs=mysql_fetch_array($qs)) {
			echo $rs['jenjang'];
			echo "&nbsp;-&nbsp;";
			echo $rs['universitas'];
			echo "<br />";
			}
			?>
			
			</td>
			<td><?echo $r['fb'];?></td>
			<td><?echo $r['instansi'];?></td>
			<td><?echo $r['jabatan'];?></td>
			<td><?echo $r['alamatktr'];?></td>
			<td><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=alumni.view&mode=view&id=".$r['id']."",$key2));?>">lihat</a></td>
		</tr><!-- Table Row -->
	<?$i=$i+1;}?>
	<?}?>
	
		

	</tbody>
	<!-- Table Body -->

</table>