<?
$q=mysql_query("select *,kategori.kat as kate from news 
left join kategori
on news.kat=kategori.id
where news.id='".$data['id']."'");
$r=mysql_fetch_array($q);
?>
<h2><?echo stripslashes($r['judul']);?></h2>
<font size="1"><i>Kategori: <?echo $r['kate'];?>, Update: <?echo $r['date'];?></i></font>
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
<?echo stripslashes($r['depan']);?>
<br class="clear">
<?echo stripslashes($r['isi']);?>
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
<br class="clear">
