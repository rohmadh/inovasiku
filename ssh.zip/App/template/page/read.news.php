<?
$q=mysql_query("select * from news where id='".$data['id']."'");
$r=mysql_fetch_array($q);

?>
<span class="titl">Berita Terbaru</span> 
	<span class="txt" style="width:400px;"> 
	<h2>
	<?
	echo $r['judul'];
	?></h2><br />
	<?
	echo $r['depan'];
	?>
	<br/>
	<br />
	
	</span> 
	<span class="txt">  <br />
      
      </span>
	  