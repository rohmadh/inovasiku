<?
$q=mysql_query("select * from news  where judul='About Us'");
$r=mysql_fetch_array($q);

?>
<span class="titl">Profil Perusahaan</span> 
	<span class="txt" style="width:90%;"> 
	<?
	echo $r['depan'];
	?>
	<br/>
	<br />
	
	</span> 
	<span class="txt">  <br />
      
      </span> 