<?
function txtpajak($k){
$q=mysql_query("select * from jenispajak where id='".$k."'");
$r=mysql_fetch_array($q);
return $r['txtpajak'];
}
?>
<table class="table" style="font-size:9pt;">
<tr>
<th>Tanggal</th><th>Kode Rekening</th><th>Uraian</th><th>Penerimaan</th><th>Pengeluaran</th>
</tr>
<?
$tb=mysql_escape_string($_GET['tb']);
$ta=mysql_escape_string($_GET['ta']);
$a=0;$b=0;$d=0;$k=0;
$qpanjar=mysql_query("
select '' as idpanjar,'' as idkeg,'' as idrek,jml,tgl,uraian as ket,'up' as tipe from tblup where user='".$_SESSION['iduser']."' 
and (str_to_date(tgl,'%d/%m/%Y')) between str_to_date('".$ta."','%d/%m/%Y') and str_to_date('".$tb."','%d/%m/%Y')
union 
select id,idkeg,'',npanjar,tgl,ket,'pjr' from tblpanjar where user='".$_SESSION['iduser']."' 
and tblpanjar.jenispanjar='0' and (str_to_date(tgl,'%d/%m/%Y')) between str_to_date('".$ta."','%d/%m/%Y') and str_to_date('".$tb."','%d/%m/%Y')
union 
select id,idkeg,'',npanjar,tgl,ket,'sisa' from tblpanjar where user='".$_SESSION['iduser']."' 
and tblpanjar.jenispanjar='1' and (str_to_date(tgl,'%d/%m/%Y')) between str_to_date('".$ta."','%d/%m/%Y') and str_to_date('".$tb."','%d/%m/%Y')
");	echo mysql_error();
while($rp=mysql_fetch_array($qpanjar)){
?>
<?
if($rp['tipe']=='up'){
?>
<tr>
<td><? echo $rp['tgl'];?></td><td></td><td><b>Diterima UP <? echo htmlspecialchars($rp['ket']);?></td><td style='text-align:right;'>
<? echo uang($rp['jml']);$d=$d+$rp['jml'];?></b></td><td style='text-align:right;'><? echo uang(0);?></td>
</tr>
<?}?>
<?
if($rp['tipe']=='pjr'){
?>
<tr>
<td><? echo $rp['tgl'];?></td><td></td><td><b>Dipanjarkan <? echo htmlspecialchars($rp['ket']);?></td><td style='text-align:right;'><? echo uang(0);?></b></td><td style='text-align:right;'><? echo uang($rp['jml']);$k=$k+$rp['jml'];?></td>
</tr>
<tr>
<td>-</td><td></td><td><b>Diterima SPJ <? echo htmlspecialchars($rp['ket']);?></b></td><td style='text-align:right;'><? echo uang($rp['jml']);$d=$d+$rp['jml'];?></td><td style='text-align:right;'><? echo uang(0);?></td>
</tr>
<?}?>

<?
if($rp['idpanjar']>0){
$q=mysql_query("select tgl,idrek,uraian,jbayar,jml,pajak,txtpajak,'tipe',pajak2,jpajak2,pajak3,jpajak3 from tblspj2 
left join jenispajak on tblspj2.jpajak=jenispajak.id
where idpanjar='".$rp['idpanjar']."' and user='".$_SESSION['iduser']."' and (str_to_date(tgl,'%d/%m/%Y')) between str_to_date('".$ta."','%d/%m/%Y') and str_to_date('".$tb."','%d/%m/%Y')
order by tgl ASC");
echo mysql_error();
while($rd=mysql_fetch_array($q)){?>
<?if ($rd['tipe']=='tipe'){?>
<tr>
<td><? echo $rd['tgl'];?></td><td><? echo htmlspecialchars($rd['idrek']);?></td>
<td><? echo htmlspecialchars($rd['uraian']);?>,<? echo strtoupper(htmlspecialchars($rd['jbayar']));?></td><td></td><td style='text-align:right;'><? echo uang($rd['jml']);$k=$k+$rd['jml'];?></td>
</tr>
<?}?>
<?if($rd['pajak']>0){?>
<tr>
<td>-</td><td></td><td>Diterima <? echo htmlspecialchars($rd['txtpajak']);?></td><td style='text-align:right;'><? echo uang($rd['pajak']);$d=$d+$rd['pajak'];?></td><td style='text-align:right;'><? echo uang(0);?></td>
</tr>
<tr>
<td>-</td><td></td><td>Dikeluarkan <? echo htmlspecialchars($rd['txtpajak']);?></td><td style='text-align:right;'><? echo uang(0);?></td><td style='text-align:right;'><? echo uang($rd['pajak']);$k=$k+$rd['pajak'];?></td>
</tr>
<?}?>
<?if($rd['pajak2']>0){?>
<tr>
<td>-</td><td></td><td>Diterima <? echo htmlspecialchars(txtpajak($rd['jpajak2']));?></td><td style='text-align:right;'><? echo uang($rd['pajak2']);$d=$d+$rd['pajak2'];?></td><td style='text-align:right;'><? echo uang(0);?></td>
</tr>
<tr>
<td>-</td><td></td><td>Dikeluarkan <? echo htmlspecialchars(txtpajak($rd['jpajak2']));?></td><td style='text-align:right;'><? echo uang(0);?></td><td style='text-align:right;'><? echo uang($rd['pajak2']);$k=$k+$rd['pajak2'];?></td>
</tr>
<?}?>
<?if($rd['pajak3']>0){?>
<tr>
<td>-</td><td></td><td>Diterima <? echo htmlspecialchars(txtpajak($rd['jpajak3']));?></td><td style='text-align:right;'><? echo uang($rd['pajak3']);$d=$d+$rd['pajak3'];?></td><td style='text-align:right;'><? echo uang(0);?></td>
</tr>
<tr>
<td>-</td><td></td><td>Dikeluarkan <? echo htmlspecialchars(txtpajak($rd['jpajak3']));?></td><td style='text-align:right;'><? echo uang(0);?></td><td style='text-align:right;'><? echo uang($rd['pajak3']);$k=$k+$rd['pajak3'];?></td>
</tr>
<?}?>
<?}?>

<?}?>
<?
if($rp['tipe']=='sisa'){
?>

<tr>
<td><? echo htmlspecialchars($rp['tgl']);?></td><td></td><td><b>Diterima Pengembalian Panjar <? echo htmlspecialchars($rp['ket']);?></b></td><td style='text-align:right;'><? echo uang($rp['jml']);$d=$d+$rp['jml'];?></td><td style='text-align:right;'><? echo uang(0);?></td>
</tr>
<?}?>
<?}?>





<?
$a=$a+$rd['pajak'];
$b=$b+$rd['jml']+$rd['pajak'];
?>
<tr>
<td></td><td></td><td>Total</td><td style='text-align:right;'><? echo uang($d);?></td><td style='text-align:right;'><? echo uang($k);?></td>
</tr>
<tr>
<td></td><td></td><td>Saldo</td><td style='text-align:right;'><? if(($k-$d)>0){echo uang($k-$d);}?></td><td style='text-align:right;'><? if(($d-$k)>0){echo uang($d-$k);}?></td>
</tr>
</table>
<?
$q=mysql_query("select sum");
?>
<table align="left">
<tr>
<td>Uang di Bank</td><td>:</td><td>Rp.<? echo uang($d-$k);?></td>
</tr>
<tr>
<td>Uang Tunai</td><td>:</td><td>Rp.</td>
</tr>
<tr>
<td>Surat Berharga</td><td>:</td><td>Rp.</td>
</tr>
</table>