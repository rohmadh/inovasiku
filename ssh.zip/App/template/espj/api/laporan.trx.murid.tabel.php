<?
$trx=array();
$trx2=array();
$nama="";
#echo $_GET['q'];
$q="
SELECT vanumber,vaname,month(pdate) as bln,sum(kredit) as jml FROM keu_trxbank
where vanumber like'88%' and vanumber like '%".$_GET['q']."'
group by vanumber,month(pdate)
";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
#$row = $stmt->fetch();
while ($row = $stmt->fetch()) {
$trx=$trx+array($row['bln']=>$row['jml']);
$nama=$row['vaname'];
}
#print_r($trx);
#####data trx 2
$q2="
SELECT vanumber,vaname,month(pdate) as bln,sum(kredit) as jml FROM keu_trxbank
where vanumber like'7955%' and vanumber like'%".$_GET['q']."'
group by vanumber,month(pdate)
";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q2);
$stmt->execute();
#$row = $stmt->fetch();
while ($row = $stmt->fetch()) {
$trx2=$trx2+array($row['bln']=>$row['jml']);
#$nama=$row['vaname'];
}
?>
<div align="left">
Nama : <?echo txthtml($nama);?><br/>
VA Number : XXX<?echo txthtml($_GET['q']);?><br/>
</div>
<table class="table" width="80%" class="table table-striped table-bordered table-hover" id="dataTables">
<tr>
<th>Bulan</th><th>SPP&<br />Uang Pangkal VA 88xxx</th><th>Pembayaran</th><th>Lain2 <br />VA 7955xx</th><th>Pembayaran</th><th>Status</th>
</tr>
<?
$a=1;
while($a<=12){?>
<tr>
<td><?echo bulan($a);?></td><td>Tagihan</td><td><?echo uang(intval($trx[$a]));?></td>
<td>Tagihan</td><td><?echo uang(intval($trx2[$a]));?></td>
<td><?if((intval($trx[$a])+intval($trx2[$a]))>0){echo "OK";}else{echo "Belum";}?></td>
</tr>
<?$a=$a+1;}?>
</table>