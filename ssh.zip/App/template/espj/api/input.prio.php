<?
$q="update keu_prioritas_tagihan set no='".$_GET['n']."' where kode='".$_GET['k']."'
";
$stmt = $conn->prepare($q);
$stmt->execute();
$conn = null;
?>