
<table class="table">
<tr>
<th>Bagian</th><th>Jumlah Anggaran</th><th>GU</th><th>TU</th><th>LS</th><th>JML PANJAR</th><th>S/D BLN LALU</th><th>BLN INI</th><th>S/D BLN INI</th><th>SISA ANGGARAN</th><th>(%) serapan</th>
</tr>
<?
$q=mysql_query("select * from tbl_keg_bagian
left join pengguna on tbl_keg_bagian.kodeuser=pengguna.id
where tbl_keg_bagian.tahun='".$_SESSION['thn']."' group by tbl_keg_bagian.kodeuser");
while($r=mysql_fetch_array($q)){
$a=0;$b=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;$i=0;

?>
<?
$qa=mysql_query("select * from tbl_keg_bagian
left join pengguna on tbl_keg_bagian.kodeuser=pengguna.id
where tbl_keg_bagian.kodeuser='".$r['kodeuser']."' and tbl_keg_bagian.tahun='".$_SESSION['thn']."'");
while($ra=mysql_fetch_array($qa)){
?>


<?
$qm=mysql_query("select * from master where kode='".$ra['koderek']."' and tahun='".$_SESSION['thn']."'");
$rm=mysql_fetch_array($qm);
$qr=mysql_query("select 
sum(case when tipespj='1' then jml end) as gu,
sum(case when tipespj='2' then jml end) as tu,
sum(case when tipespj='3' then jml end) as ls,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj2.tgl,'%d/%m/%Y'))<month(now())) then jml else 0 end) as lalu,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj2.tgl,'%d/%m/%Y'))=month(now())) then jml else 0 end) as ini,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj2.tgl,'%d/%m/%Y'))<=month(now())) then jml else 0 end) as sdini 
from tblspj2 where idkeg='".$ra['koderek']."' and tahun='".$_SESSION['thn']."'
");
$rr=mysql_fetch_array($qr);
$qjar=mysql_query("select sum(npanjar) as jar from tblpanjar where idkeg='".$ra['koderek']."' and tahun='".$_SESSION['thn']."'");
$rjar=mysql_fetch_array($qjar);
?>

<?

$a=$a+$rm['angg'];
$b=$b+$rr['gu'];
$c=$c+$rr['tu'];
$d=$d+$rr['ls'];
$e=$e+$rjar['jar'];
$f=$f+$rr['lalu'];
$g=$g+$rr['ini'];
$h=$h+$rr['sdini'];
$i=$i+($rm['angg']-$rr['sdini']);
echo mysql_error();?>
<?if(1==2){?>
<tr>
<td style='text-align:left;'>--<?echo $ra['nama'];?></td>
<td><?echo uang($a);?></td><td><?echo uang($b);?></td><td><?echo uang($c);?></td><td><?echo uang($d);?></td>
<td><?echo uang($e);?></td><td><?echo uang($f);?></td><td><?echo uang($g);?></td>
<td><?echo uang($h);?></td><td><?echo uang($i);?></td>
<td><?echo number_format((($h)/$a)*100,3);?></td>
</tr>
<?}}?>
<tr>
<td style='text-align:left;'><?echo $r['nama'];?></td>
<td><?echo uang($a);?></td><td><?echo uang($b);?></td><td><?echo uang($c);?></td><td><?echo uang($d);?></td>
<td><?echo uang($e);?></td><td><?echo uang($f);?></td><td><?echo uang($g);?></td>
<td><?echo uang($h);?></td><td><?echo uang($i);?></td>
<td><?echo number_format((($h)/$a)*100,3);?></td>
</tr>

<?}?>
</table>