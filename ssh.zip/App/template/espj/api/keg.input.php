<?
if($_GET['mode']=='save'){
mysql_query("insert into tblkegiatan (kprogram,txtkegiatan,tahun) value ('".$_GET['idprog']."','".$_GET['namakeg']."','".$_SESSION['thn']."')");
}
if($_GET['mode']=='edit'){
mysql_query("update master set kkeg='".$_GET['namakeg']."' where kode='".$_GET['idkeg']."'");
}
?>