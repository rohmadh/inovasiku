
<?
$q="SELECT * FROM keu_transaksi where notransaksi like'01%'";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
?>
<table class="table table-striped table-bordered table-hover" id="dataTables">
<tr>
<th>KODE AKUN</th><th>KETERANGAN</th><th>JUMLAH</th><th>PROSES</th>
</tr>
<?
while ($row = $stmt->fetch()) {
?>							
<tr>
<td><? echo(txthtml($row['kodeakun']));?></td><td><? echo txthtml($row['ket']);?></td><td><? echo txthtml(uang($row['jml']));?></td>
<td><input type="button" value="x" style="ui-button" onclick="hapus(<? echo txthtml($row['notransaksi']);?>);">
<input type="button" value="e" onclick="edit('<? echo txthtml($row['notransaksi']);?>');"></td>
<tr/>
<?$conn = null;}?>
</table>
<script>
function hapus(n) {
		$("#targettbl").html("<h2>..Menghapus data....</h2>");
        $.ajax({url: 'App/api.php?m=keu.input.penerimaan&mode=hapus&id='+n, success: function(result){
            refreshtabel();
			alert("Data Sukses Dihapus");
        }});
    }
</script>
<script>
function edit(n) {
		$("#targettbl").html("<h2>..Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=keu.load.transaksi&id='+n, success: function(result){
			$("#targetresp").html(result);
            refreshtabel();
        }});
    }
</script>