<?
#$a="88000000123";
#$f=str_split($a,8);
#echo $f[0];
$q="SELECT * from keu_mastertagihan
where nama like'%".$_GET['nis']."%'
group by keu_mastertagihan.nama";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
?>


<table class="table" style="font-size:9pt;" width="100%" class="table table-striped table-bordered table-hover" id="dataTables">
<tr>
                    <th>nama</th>
                    <th>kelas</th>
                    <th>va1</th>
                    <th>va2</th>
					<th>action</th>
                </tr>

<?
$a=0;$b=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;$i=0;
while ($row = $stmt->fetch()) {
?>
<tr>
                    <td><?php  echo $row['nama']; ?></td>
                    <td><?php  echo $row['kelas']; ?></td>
                    <td><?php  echo $row['va1']; ?></td>
					<td><?php  echo $row['va2']; ?></td>
<td><input type="button" value="RINCIAN" onclick="loadhistory('<?echo txthtml($row['va1']);?>')"></td>
</tr>
<?
$a=$a+$row['spp'];$b=$b+$row['extra'];$c=$c+$row['infaq'];$d=$d+$row['kbm'];$e=$e+$row['anjem'];$f=$f+$row['katering'];$g=$g+$row['atk'];
$h=$h+$row['jamiyyah'];$i=$i+($row['spp']+$row['extra']+$row['infaq']+$row['kbm']+$row['anjem']+$row['katering']+$row['atk']+$row['jamiyyah']);
}?>


<?$conn = null;?>
</table>
<script>
function loadhistory(k) {
		$("#tampil").html('<h1>...LOADING LAPORAN...</h1>');
        $.ajax({url: 'App/api.php?m=laporan.keu.bulanan.murid.tabel&q='+k, success: function(result){
            $("#tampil").html(result);
        }});
    }
</script>