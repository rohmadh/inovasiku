<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
  font-size: 9pt;
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
  font-size: 9pt;
}
</style>
<table class="table">
<tr>
							<th>KEGIATAN</th><th>TANGGAL PANJAR</th><th>NILAI PANJAR</th><th>KETERANGAN</th><th>SPJ</th><th>PROSES</th>
							</tr>
<? 
$q=mysql_query("select *, tblpanjar.id as idd from tblpanjar 
left join master on tblpanjar.idkeg=master.kode
where user='".$_SESSION['iduser']."' and tblpanjar.tahun='".$_SESSION['thn']."' and master.tahun='".$_SESSION['thn']."' order by tgl ASC");
echo mysql_error();
							while($r=mysql_fetch_array($q)){	
							$qs=mysql_query("select sum(jml) as jspj from tblspj2 where idpanjar='".$r['idd']."'");
							$rs=mysql_fetch_array($qs);
							?>
							
							
							<tr>
							<td><div><?echo htmlspecialchars($r['kkeg']);?></div></td>
							<td><div id="txt1<?echo $r['idd'];?>"><?echo htmlspecialchars($r['tgl']);?></div></td>
							<td style='text-align:right;'><div id="txt2<?echo $r['id'];?>"><?echo htmlspecialchars(uang($r['npanjar']));?></div></td>
							<td><div id="txt3<?echo $r['idd'];?>"><?echo htmlspecialchars($r['ket']);?></div></td>
							<td style="align:right;"><?echo htmlspecialchars(uang($rs['jspj']));?>
							
							</td>
							<td>
							<input type="button" value="SPJ" onclick="frmspj(<?echo $r['idd'];?>);">
							<input type="button" value="EDIT" onclick="pilih(<?echo $r['idd'];?>);">
							<input type="button" value="HAPUS" onclick="hapus(<?echo $r['idd'];?>);">
							</td>
							</tr>
							
							<?}?>
</table>
<script>
function pilih(k) {
$("#namaprog").val('...LOADING...');
$("#namakeg").val('...LOADING...');
$.ajax({url: 'App/api.php?m=load.panjar&id='+k, success: function(result){
			$("#loader").html(result);
        }});
}
</script>
<script>
function hapus(k) {
        $.ajax({url: 'App/api.php?m=panjar.input&mode=del&id='+k, success: function(result){
            alert('DATA TERHAPUS...');
			refreshtabel();
        }});
    }
</script>
<script>
function frmspj(k) {
$.ajax({url: 'App/api.php?m=load.progkeg&id='+k, success: function(result){
			$("#loader").html(result);
        }});
		$("#frmtarget").html('<h2>...LOADING FORM...</h2>');
        $.ajax({url: 'App/api.php?m=frmspj.input&id='+k, success: function(result){
            $("#frmtarget").html(result);
        }});
    }
</script>