<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
  font-size: 9pt;
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
  font-size: 9pt;
}
</style>
<table class="table">
<tr>
							<th>NAMA AKTIVITAS</th><th>PROSES</th><th>DOKUMEN SPJ</th><th>Nilai Rupiah</th><th>PROSES</th>
							</tr>
<? 
$q="SELECT aktivitas.id as idd, aktivitas.uraian,sum(nota.rupiah) as jmlrp 
FROM aktivitas  
left join nota on aktivitas.id=nota.idaktivitas
where kprog='".$_GET['kprog']."' and kkeg='".$_GET['kkeg']."' and nokeg='".$_GET['n']."'
group by aktivitas.id
ORDER BY aktivitas.wkt ASC";
$stmt = $conn->prepare($q);
$exec = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
foreach ($rows as $r) {
							
							?>
							
							
							<tr>
							
							<td><?echo strtoupper(htmlspecialchars($r['uraian']));?></td>
							<td>
							
							<input type="button" value="UNDANGAN & PRESENSI" onclick="getfrmundangan('<?echo $r['idd']?>','<?echo $r['uraian']?>');">
							</td>
							<td>
							<input type="button" value="NOTA" onclick="getfrmnota('<?echo $r['idd']?>','<?echo $r['uraian']?>');">
							</td>
							<td><?echo strtoupper(htmlspecialchars(uang($r['jmlrp'])));?></td>
							<td>
							<select id="optaction">
							<option value="cetak">...</option>
							<option value="edit" onclick="editaktivitas('<?echo $r['idd']?>');">EDIT</option>
							<option value="hapus">HAPUS</option>
							</select>
							</td>
							</tr>
							
							<?}?>
</table>
<script>
function pilih(k) {
$("#namaprog").val('...LOADING...');
$("#namakeg").val('...LOADING...');
$.ajax({url: 'App/api.php?m=load.panjar&id='+k, success: function(result){
			$("#loader").html(result);
        }});
}
</script>
<script>
function hapus(k) {
        $.ajax({url: 'App/api.php?m=panjar.input&mode=del&id='+k, success: function(result){
            alert('DATA TERHAPUS...');
			refreshtabel();
        }});
    }
</script>
<script>
function frmspj(k) {
$.ajax({url: 'App/api.php?m=load.progkeg&id='+k, success: function(result){
			$("#loader").html(result);
        }});
		$("#frmtarget").html('<h2>...LOADING FORM...</h2>');
        $.ajax({url: 'App/api.php?m=frmspj.input&id='+k, success: function(result){
            $("#frmtarget").html(result);
        }});
    }
function getfrmnota(k,t) {

		$("#frmkas").html('<h2>...LOADING FORM...</h2>');
		$("#frmdata").html('');
        $.ajax({url: 'App/api.php?m=frmspj.input.nota&id='+k, success: function(result){
			$("#idaktivitas").val(k);
			$("#txtaktivitas").val(t);
            $("#frmkas").html(result);
			
        }});
    }
</script>
<script>
function editaktivitas(k) {
var id=k;
$.ajax({url: 'App/api.php?m=espj.load.aktivitas',type:'post',data:{id:id}, success: function(result){
			$("#targetresp").html(result);
			refreshaktivitas();
        }});
}
function loadundangan(k) {
$("#frmdata").html('...LOADING DATA...');
$.ajax({url: 'App/api.php?m=espj.load.undangan&id='+k, success: function(result){
			$("#targetresp").html(result);
			$("#act").val('save');
			$("#ida").val(k);
			refreshdaftarundangan();
        }});
}
</script>
<script>
function loadp() {
		var ta=$("#bln").val();
		window.open("./?action=print&page=espj.undangan.print&a="+ta, "_blank");
    }
</script>