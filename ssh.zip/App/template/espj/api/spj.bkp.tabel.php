<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
  font-size: 9pt;
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
  font-size: 9pt;
}
</style>
<table class="table">
<tr>
							<th>HARI</th><th>Kegiatan</th><th>Untuk Pembayaran</th><th>Rupiah</th><th>Lampiran</th><th>PROSES</th>
							</tr>
<? 
$stmt = $conn->prepare("SELECT *,kegiatan.uraian as txtkeg,bend26.id as idd FROM bend26 
inner join kegiatan on bend26.kkeg=kegiatan.kodekeg
where bend26.kkeg='".$_GET['kkeg']."' ORDER BY bend26.id,tgl ASC");
$exec = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
$tot=0;
foreach ($rows as $r) {
							
							?>
							
							
							<tr>
							<td><?echo htmlspecialchars($r['tgl']);?></td>
							<td><?echo htmlspecialchars($r['txtkeg']);?></td>
							<td><?echo htmlspecialchars($r['untukpemb']);?></td>
							<td><?echo htmlspecialchars($r['rupiah']);?></td>
							<td>
							
							<img src="App/<?echo $base;?>/api/<?echo strtoupper(htmlspecialchars($r['namafile']));?>" width="40">
							
							</td>
							<td>
							<select id="optaction">
							<option value="cetak">...</option>
							<option value="edit" onclick="editundangan('<?echo $r['idd']?>');">EDIT</option>
							<option value="cetak" onclick="loadp('<?echo $r['idd']?>');">CETAK</option>
							<option value="hapus">HAPUS</option>
							<option value="batas">-----</option>
							<option value="srttransfer" onclick="frmsrttransfer('<?echo $r['idd']?>');">SURAT TRANSFER</option>
							<option value="srttransfer2" onclick="frmsrttransfer2('<?echo $r['idd']?>');">SURAT KESANGGUPAN</option>
							</select>
							
							</td>
							</tr>
							
							<?$tot=$tot+$r['rupiah'];}?>
							<tr>
							<td colspan="6"><center><text style="font-size:13pt;">Total Rp. <?echo uang($tot);?></text></center></td>
							</tr>
</table>
<script>
function pilih(k) {
$("#namaprog").val('...LOADING...');
$("#namakeg").val('...LOADING...');
$.ajax({url: 'App/api.php?m=load.panjar&id='+k, success: function(result){
			$("#loader").html(result);
        }});
}
</script>
<script>
function hapus(k) {
        $.ajax({url: 'App/api.php?m=panjar.input&mode=del&id='+k, success: function(result){
            alert('DATA TERHAPUS...');
			refreshtabel();
        }});
    }
</script>
<script>
function frmspj(k) {
$.ajax({url: 'App/api.php?m=load.progkeg&id='+k, success: function(result){
			$("#loader").html(result);
        }});
		$("#frmtarget").html('<h2>...LOADING FORM...</h2>');
        $.ajax({url: 'App/api.php?m=frmspj.input&id='+k, success: function(result){
            $("#frmtarget").html(result);
        }});
    }
function frmsrttransfer(k) {
		$("#blokform").show();
		$("#judulbox").html('INFORMASI SURAT...');
		$("#frmkas").html('<h2>...LOADING FORM...</h2>');
        $.ajax({url: 'App/api.php?m=frmsrttransfer.input&id='+k, success: function(result){
            $("#frmkas").html(result);
        }});
    }
function frmsrttransfer2(k) {
		$("#blokform").show();
		$("#judulbox").html('INFORMASI SURAT...');
		$("#frmkas").html('<h2>...LOADING FORM...</h2>');
        $.ajax({url: 'App/api.php?m=frmsrttransfer2.input&id='+k, success: function(result){
            $("#frmkas").html(result);
        }});
    }
</script>
<script>
function editundangan(k) {
$("#frmdata").html('...LOADING DATA...');
$.ajax({url: 'App/api.php?m=espj.load.undangan&id='+k, success: function(result){
			$("#targetresp").html(result);
			refreshundangan();
        }});
}
function loadundangan(k) {
$("#frmdata").html('...LOADING DATA...');
$.ajax({url: 'App/api.php?m=espj.load.undangan&id='+k, success: function(result){
			$("#targetresp").html(result);
			$("#act").val('save');
			$("#ida").val(k);
			refreshdaftarundangan();
        }});
}
</script>
<script>
function loadp(k) {
		
		window.open("./?action=print&page=espj.bkp.print&a="+k, "_blank");
    }
</script>