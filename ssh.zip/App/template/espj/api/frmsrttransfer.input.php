<?
$stmt = $conn->prepare("SELECT * FROM srttransfer where idbend26='".$_GET['id']."' ");
$exec = $stmt->execute();
$r = $stmt->fetch();
####
$stmt = $conn->prepare("SELECT * FROM bend26 where id='".$_GET['id']."' ");
$exec = $stmt->execute();
$r2 = $stmt->fetch();

?>
<table border="0">
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>NO.SURAT</label></td><td><label>:</label></td>
<td>
<input type="text" id="dnos" value="<?echo $r['nosrt'];?>">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Nama/Usaha</label></td><td><label>:</label></td>
<td>
<input type="text" id="dnama" value="<?echo $r['nama'];?>">
<input type="hidden" id="act" value="save">
<input type="hidden" id="idsrt" value="<?echo $_GET['id'];?>">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Alamat</label></td><td><label>:</label></td>
<td>
<textarea id="alamat" cols="35" rows="5"><?echo $r['alamat'];?></textarea>
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>NPWP</label></td><td><label>:</label></td>
<td>
<input type="text" id="dnpwp" value="<?echo $r['npwp'];?>">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Bank</label></td><td><label>:</label></td>
<td>
<input type="text" id="dbank" size="50" value="<?echo $r['bank'];?>">
</td>
</tr>

<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>No. Rekening Bank</label></td><td><label>:</label></td>
<td>
<input type="text" id="drekbank" size="50" value="<?echo $r['rekbank'];?>">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td valign='top'><label>Pajak-Pajak</label></td><td valign='top'><label>:</label></td>
<td valign='top'>
PPN: Rp. <?echo uang($r2['pph22']);?><br />
PPh Ps. 22: Rp. <?echo uang($r2['pph22']);?><br />
PPh Ps. 23: Rp. <?echo uang($r2['pph23']);?><br />
Pajak daerah: Rp. <?echo uang($r2['pajakdaerah']);?><br />
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Denda</label></td><td><label>:</label></td>
<td>
<input type="text" id="ddenda" size="50" value="<?echo $r['denda'];?>">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Penyusutan</label></td><td><label>:</label></td>
<td>
<input type="text" id="dpenyusutan" size="50" value="<?echo $r['penyusutan'];?>">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Biaya Transfer</label></td><td><label>:</label></td>
<td>
<input type="text" id="dbiayatransfer" size="50" value="<?echo $r['biayatransfer'];?>">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Catatan</label></td><td><label>:</label></td>
<td>
<textarea id="dcat" cols="35" rows="3"><?echo $r['catatan'];?></textarea>
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;</td>
<td></td><td></td><td><input type="submit" value="SIMPAN"  id="btnsave" onclick="simpan2();"><input type="submit" value="CLEAR"  id="btnnew" onclick="$('#dnama').val('');">
<input type="submit" value="CETAK SURAT TRANSFER"  id="btnnew" onclick="loadp2();">
</td>
</tr>
</table>
<script>
function simpan2() {		
		var idsrt = $("#idsrt").val();
		var nos = $("#dnos").val();
		var nama = $("#dnama").val();
		var alamat = $("#alamat").val();
		var npwp = $("#dnpwp").val();
		var bank = $("#dbank").val();
		var rekbank = $("#drekbank").val();
		var cat = $("#dcat").val();
		var denda = $("#ddenda").val();
		var penyusutan = $("#dpenyusutan").val();
		var biayat = $("#dbiayatransfer").val();
		var mode = $("#act").val();
		$("#frmdata").html('...PROSES DATA...');
        $.ajax({url: 'App/api.php?m=espj.input.srt.transfer',type:'post',
		data:{mode:mode,idsrt:idsrt,nos:nos,nama:nama,alamat:alamat,npwp:npwp,bank:bank,rekbank:rekbank,cat:cat,denda:denda,penyusutan:penyusutan,biayat:biayat},
		success: function(result){
            $("#frmdata").html(result);
			
			
        }});
    }
</script>

<script>

function loadp2() {
		var ta=$("#idsrt").val();
		window.open("./?action=print&page=espj.srt.transfer.print&a="+ta, "_blank");
    }
function loadp3() {
		var ta=$("#ida").val();
		window.open("./?action=print&page=espj.daftar.undangan.print&a="+ta, "_blank");
    }
</script>
