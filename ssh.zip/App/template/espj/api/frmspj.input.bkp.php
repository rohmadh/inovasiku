<?
####ambil nilai setting pajakdaerah
$stmt = $conn->prepare("SELECT nilai FROM setting where kode='ppn'");
$exec = $stmt->execute();
$rppn = $stmt->fetch();
###pph23
$stmt = $conn->prepare("SELECT nilai FROM setting where kode='pph23'");
$exec = $stmt->execute();
$rpph23 = $stmt->fetch();
?>
<style>

/* Preview */
.preview{
   width: 100px;
   height: 100px;
   border: 1px solid black;
   margin: 0 auto;
   background: white;
}

.preview img{
   display: none;
}
/* Button */
.button{
   border: 0px;
   background-color: deepskyblue;
   color: white;
   padding: 5px 15px;
   
}
</style>
<table border="0">
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Tanggal</label></td><td><label>:</label></td>
<td>
<input class="form-control" type="text" id="tgln">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Terima Dari</label></td><td><label>:</label></td>
<td>
<input class="form-control" type="text" id="txtdari" size="20">

</td>
</tr>

<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td valign="top"><label>Untuk Pembayaran</label></td><td valign="top"><label>:</label></td>
<td>
<textarea id="uraian" class="form-control" cols="50" rows="10"></textarea>
<input type="hidden" id="act" value='save'>
<input type="hidden" id="namafile">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Kegiatan</label></td><td><label>:</label></td>
<td>
<input class="form-control" type="text" id="txtbkpkeg" size="100" disabled>

</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td valign="top"><label>Kode Rekening BKP</label></td><td valign="top"><label>:</label></td>
<td valign="top">
<input class="form-control2" type="text" id="krek" size="20" >
<input class="form-control2" type="text" id="krekbelanja" onkeyup="caribelaja();"><br />
<div id="targetkodebelanja"></div>

</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Uang Sebesar</label></td><td><label>:</label></td>
<td>
<input class="form-control" type="text" id="txtuang" size="20">

</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Terbilang (Rp)</label></td><td><label>:</label></td>
<td>
<input class="form-control" type="text" id="rupiah" size="20" value="0">

</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>PPN (Rp)</label></td><td><label>:</label></td>
<td>
<input class="form-control2" type="text" id="txtppn" size="20" value='0'>&nbsp;(<?echo $rppn['nilai']*100;?>%)&nbsp;<input id="cekppn" type="checkbox" onclick="if(this.checked){$('#txtppn').val($('#rupiah').val()*<?echo $rppn['nilai'];?>);}else{$('#txtppn').val('0');};">

</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>PPh. 23 (Rp)</label></td><td><label>:</label></td>
<td>
<input class="form-control2" type="text" id="txtpph23" size="20" value='0'>&nbsp;(<?echo $rpph23['nilai']*100;?>%)&nbsp;<input id="cekpph23" type="checkbox" onclick="if(this.checked){$('#txtpph23').val($('#rupiah').val()*<?echo $rpph23['nilai'];?>);}else{$('#txtpph23').val('0');};">

</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Pajak Daerah (Rp)</label></td><td><label>:</label></td>
<td>
<input class="form-control2" type="text" id="txtpajakdaerah" size="20" value='0'>&nbsp;<input id="cekppd" type="checkbox" onclick="if(this.checked){$('#txtpajakdaerah').val($('#rupiah').val()*0.1);}else{$('#txtpajakdaerah').val('0');};">

</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>File Lampiran</label></td><td><label>:</label></td>
<td>
<div class="container">
    <form method="post" action="" enctype="multipart/form-data" id="myform">
        
        <div >
            <input type="file" id="file" name="file" />
            <input type="button" class="button" value="Upload" id="but_upload">
        </div>
    </form>
</div>
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Preview</label></td><td><label>:</label></td>
<td>
<div class='preview'>
            <img src="" id="img" width="100" height="100">
</div>

</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;</td>
<td></td><td></td><td><input type="submit" value="SIMPAN"  id="btnsave" onclick="simpanbkp();"><input type="submit" value="CLEAR"  id="btnnew" onclick="$('#daktv').val('');">

</td>
</tr>
</table>

<script>
$(document).ready(function(){

    $("#but_upload").click(function(){

        var fd = new FormData();
        var files = $('#file')[0].files[0];
        fd.append('file',files);

        $.ajax({
            url: 'App/<? echo $base?>/api/upload.bkp.php',
            type: 'post',
            data: fd,
            contentType: false,
            processData: false,
            success: function(response){
                if(response != 0){
                    $("#img").attr("src","App/<?echo $base;?>/api/"+response); 
                    $(".preview img").show(); // Display image element
					$("#namafile").val(response);
                }else{
                    alert('file not uploaded');
                }
            },
        });
    });
});
</script>
<script>
function simpanbkp() {
		
		var mode = $("#act").val();
		var namafile = $("#namafile").val();
		var uraian = $("#uraian").val();
		var rupiah = $("#rupiah").val();
		var txtdari = $("#txtdari").val();
		var idkeg = $("#idkeg").val();
		var no = $("#nourut").val();
		var txtuang = $("#txtuang").val();
		var tgl = $("#tgln").val();
		var krek = $("#krek").val();
		var krekb = $("#krekbelanja").val();
		var ppn = $("#txtppn").val();
		var pph23 = $("#txtpph23").val();
		var pajakdaerah = $("#txtpajakdaerah").val();
	
		$("#frmdata").html('...PROSES DATA...');
        $.ajax({url: 'App/api.php?m=espj.input.bkp',type:'post',
		data:{mode:mode,txtuang:txtuang,txtdari:txtdari,namafile:namafile,uraian:uraian,tgl:tgl,rupiah:rupiah,idkeg:idkeg,no:no,krek:krek,krekb:krekb,ppn:ppn,
		pph23:pph23,pajakdaerah:pajakdaerah},
		success: function(result){
            alert('..data tersimpan..');
			refreshbkp();
			
			
        }});
    }
function refreshbkp(){
		var kkeg = $("#idkeg").val();
		var nokeg = $("#nourut").val();
	$("#frmdata").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=spj.bkp.tabel&n='+nokeg+'&kkeg='+kkeg, success: function(result){
            $("#frmdata").html(result);
        }});
}
function caribelaja(){
		var q = $("#krekbelanja").val();
		if(q.length>'5'){
	$("#targetkodebelanja").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=espj.list.kodebelanja&q='+q, success: function(result){
            $("#targetkodebelanja").html(result);
        }})};
}
function ppn(){
    if($("#cekppn").checked) {
        alert('cek');
    }
}
</script>
<script>
  $( function() {
    $( "#tgln" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
  } );
  $("#txtbkpkeg").val($("#namakeg").val());
  $("#krek").val($("#idkeg").val());
  refreshbkp();
  </script>