<?
$q="select *,sum(case when rupiah>0 then rupiah else 0 end) as spj from kegiatan 
left join bend26 on kegiatan.kodekeg=bend26.kkeg
group by kodekeg
order by kodekeg ASC";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
?>


<table class="table" width="100%" class="table table-striped table-bordered table-hover" id="dataTables">
<tr>
<th>Kode</th><th>Program/Kegiatan</th><th>Anggaran</th><th>SPJ</th><th>Sisa</th>
</tr>

<?
$a=0;$b=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;$i=0;
while ($row = $stmt->fetch()) {
	if($row['spj']>0){
	$q2="select sum(total) as plafon from anggarankas where kode like'".$row['kodekeg']."%' and length(kode)='30'";
	#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
	$stmt = $conn->prepare($q2);
	$stmt->execute();
	$plafon=$stmt->fetch();}
?>
<tr>
<td style='text-align:left;'><?echo txthtml($row['kodekeg']);?></td>
<td style='text-align:left;'><?echo txthtml($row['uraian']);?></td>
<td style='text-align:right;'><?echo txthtml(uang($plafon['plafon']));?></td>
<td style='text-align:right;'><?echo txthtml(uang($row['spj']));?></td>
<td style='text-align:right;'><?echo txthtml(uang($plafon['plafon']-$row['spj']));?></td>


</tr>
<?
$a=$a+$plafon['plafon'];$b=$b+$row['spj'];$c=$c+($plafon['plafon']-$row['spj']);$d=$d+$row['kbm'];$e=$e+$row['anjem'];$f=$f+$row['katering'];$g=$g+$row['atk'];
$h=$h+$row['jamiyyah'];$i=$i+($row['spp']+$row['extra']+$row['infaq']+$row['kbm']+$row['anjem']+$row['katering']+$row['atk']+$row['jamiyyah']);
}?>
<tr>
<td style='text-align:left;font-weight:bold;' ><?echo txthtml("TOTAL");?></td><td></td>
<td style='text-align:right;font-weight:bold;'><?echo txthtml(uang($a));?></td><td style='text-align:left;font-weight:bold;'><?echo txthtml(uang($b));?></td>
<td style='text-align:right;font-weight:bold;'><?echo txthtml(uang($c));?></td>


</tr>

<?$conn = null;?>
</table>