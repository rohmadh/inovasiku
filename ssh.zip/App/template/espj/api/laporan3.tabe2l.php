<table class="table" style="font-size:9pt;">
<tr>
<th>Tanggal</th><th>Kode Rekening</th><th>Uraian</th><th>Penerimaan</th><th>Pengeluaran</th>
</tr>
<?
$tb=mysql_escape_string($_GET['tb']);
$ta=mysql_escape_string($_GET['ta']);
$a=0;$b=0;$d=0;$k=0;	
$q=mysql_query("select tgl,idrek,uraian,jbayar,jml,pajak,txtpajak,'tipe' from tblspj2 
left join jenispajak on tblspj2.jpajak=jenispajak.id
where user='".$_SESSION['iduser']."' and (str_to_date(tgl,'%d/%m/%Y')) between str_to_date('".$ta."','%d/%m/%Y') and str_to_date('".$tb."','%d/%m/%Y')
union 
select tgl,idkeg,ket,0,npanjar,0,'','panjar' from tblpanjar 
where user='".$_SESSION['iduser']."' and (str_to_date(tgl,'%d/%m/%Y')) between str_to_date('".$ta."','%d/%m/%Y') and str_to_date('".$tb."','%d/%m/%Y')
order by idrek,tgl ASC");
echo mysql_error();
while($r=mysql_fetch_array($q)){?>
<?if($r['tipe']=='panjar'){?>
<tr>
<td><? echo $r['tgl'];?></td><td><? echo htmlspecialchars($r['idrek']);?></td><td><b>Diterima UP Pengelola Kegiatan <? echo htmlspecialchars($r['uraian']);?></b></td><td style='text-align:right;'><? echo uang($r['jml']);$d=$d+$r['jml'];?></td><td style='text-align:right;'><? echo uang(0);?></td>
</tr>
<tr>
<td><? echo $r['tgl'];?></td><td></td><td><b>Dipanjarkan <? echo htmlspecialchars($r['uraian']);?></td><td style='text-align:right;'><? echo uang(0);?></b></td><td style='text-align:right;'><? echo uang($r['jml']);$k=$k+$r['jml'];?></td>
</tr>
<tr>
<td><? echo $r['tgl'];?></td><td></td><td><b>Diterima SPJ <? echo htmlspecialchars($r['uraian']);?></b></td><td style='text-align:right;'><? echo uang($r['jml']);$d=$d+$r['jml'];?></td><td style='text-align:right;'><? echo uang(0);?></td>
</tr>
<?}else{?>
<tr>
<td><? echo $r['tgl'];?></td><td><? echo htmlspecialchars($r['idrek']);?></td>
<td><? echo htmlspecialchars($r['uraian']);?>,<? echo strtoupper(htmlspecialchars($r['jbayar']));?></td><td></td><td style='text-align:right;'><? echo uang($r['jml']);$k=$k+$r['jml'];?></td>
</tr>

<?if($r['pajak']>0){?>
<tr>
<td><? echo $r['tgl'];?></td><td></td><td>Diterima <? echo htmlspecialchars($r['txtpajak']);?></td><td style='text-align:right;'><? echo uang($r['pajak']);$d=$d+$r['pajak'];?></td><td style='text-align:right;'><? echo uang(0);?></td>
</tr>
<tr>
<td><? echo $r['tgl'];?></td><td></td><td>Dikeluarkan <? echo htmlspecialchars($r['txtpajak']);?></td><td style='text-align:right;'><? echo uang(0);?></td><td style='text-align:right;'><? echo uang($r['pajak']);$k=$k+$r['pajak'];?></td>
</tr>
<?}}?>

<?
$a=$a+$r['pajak'];
$b=$b+$r['jml']+$r['pajak'];
}?>
<tr>
<td></td><td></td><td>Total</td><td style='text-align:right;'><? echo uang($d);?></td><td style='text-align:right;'><? echo uang($k);?></td>
</tr>
<tr>
<td></td><td></td><td>Saldo</td><td style='text-align:right;'><? if(($k-$d)>0){echo uang($k-$d);}?></td><td style='text-align:right;'><? if(($d-$k)>0){echo uang($d-$k);}?></td>
</tr>
</table>
<?
$q=mysql_query("select sum");
?>
<table align="left">
<tr>
<td>Uang di Bank</td><td>:</td><td>Rp.<? echo uang($d-$k);?></td>
</tr>
<tr>
<td>Uang Tunai</td><td>:</td><td>Rp.</td>
</tr>
<tr>
<td>Surat Berharga</td><td>:</td><td>Rp.</td>
</tr>
</table>