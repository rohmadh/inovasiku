<?
$a=htmlentities($_POST['a']);
if($_POST['mode']=='save'){
$q="insert into nota (idaktivitas,tgl,uraian,rupiah,namafile) value ('".$_POST['idaktivitas']."','".$_POST['tgl']."','".$_POST['uraian']."','".$_POST['rupiah']."','".$_POST['namafile']."')";
$stmt = $conn->prepare($q);
$stmt->execute();
$stmt->errorInfo();
$conn = null;
}
?>