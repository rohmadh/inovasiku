<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>TANGGAL PANJAR</th><th>NILAI PANJAR</th><th>SPJ</th><th>KETERANGAN</th><th>PROSES</th>
							</tr>
<?$q=mysql_query("select * from tblpanjar where idkeg='".$_GET['id']."' order by tgl ASC");
							while($r=mysql_fetch_array($q)){
							$qspj=mysql_query("select sum(jml) as jspj from tblspj2 where idpanjar='".$r['id']."'");
							$rspj=mysql_fetch_array($qspj);
							?>
							
							
							<tr>
							<td><div id="txt1<?echo $r['id'];?>"><?echo htmlspecialchars($r['tgl']);?></div></td>
							<td style='text-align:right;'><div id="txt2<?echo $r['id'];?>"><?echo htmlspecialchars(uang($r['npanjar']));?></div></td>
							<td style='text-align:right;'><div id="txt2<?echo $r['id'];?>"><?echo htmlspecialchars(uang($rspj['jspj']));?></div></td>
							<td><div id="txt3<?echo $r['id'];?>"><?echo htmlspecialchars($r['ket']);?></div></td>
							<td><input type="button" value="ISI SPJ" onclick="pilih('<?echo $r['id'];?>','<?echo uang($r['npanjar']);?>');"></td>
							</tr>
							
							<?}?>
</table>
<script>
function pilih(k,j) {
var txt = $("#txt3"+k+"").text();
var tgl = $("#txt1"+k+"").text();
$("#tabelpanjar").html('&nbsp<b>'+tgl+'-'+txt+'-'+j+'</b>');
$("#idpanjar").val(k);
$("#npanjar").val(j);
$("#formspj").show();
}
</script>