<style>

/* Preview */
.preview{
   width: 100px;
   height: 100px;
   border: 1px solid black;
   margin: 0 auto;
   background: white;
}

.preview img{
   display: none;
}
/* Button */
.button{
   border: 0px;
   background-color: deepskyblue;
   color: white;
   padding: 5px 15px;
   
}
</style>
<table border="0">
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Tanggal</label></td><td><label>:</label></td>
<td>
<input class="form-control" type="text" id="tgln">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Uraian</label></td><td><label>:</label></td>
<td>
<input class="form-control" type="text" id="uraian" size="80">
<input type="hidden" id="act" value='save'>
<input type="hidden" id="namafile">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Jumlah(Rp)</label></td><td><label>:</label></td>
<td>
<input class="form-control" type="text" id="rupiah" size="20">

</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>File</label></td><td><label>:</label></td>
<td>
<div class="container">
    <form method="post" action="" enctype="multipart/form-data" id="myform">
        
        <div >
            <input type="file" id="file" name="file" />
            <input type="button" class="button" value="Upload" id="but_upload">
        </div>
    </form>
</div>
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Preview</label></td><td><label>:</label></td>
<td>
<div class='preview'>
            <img src="" id="img" width="100" height="100">
</div>

</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;</td>
<td></td><td></td><td><input type="submit" value="SIMPAN"  id="btnsave" onclick="simpannota();"><input type="submit" value="CLEAR"  id="btnnew" onclick="$('#daktv').val('');">

</td>
</tr>
</table>

<script>
$(document).ready(function(){

    $("#but_upload").click(function(){

        var fd = new FormData();
        var files = $('#file')[0].files[0];
        fd.append('file',files);

        $.ajax({
            url: 'App/<? echo $base?>/api/upload.php',
            type: 'post',
            data: fd,
            contentType: false,
            processData: false,
            success: function(response){
                if(response != 0){
                    $("#img").attr("src","App/<?echo $base;?>/api/"+response); 
                    $(".preview img").show(); // Display image element
					$("#namafile").val(response);
                }else{
                    alert('file not uploaded');
                }
            },
        });
    });
});
</script>
<script>
function simpannota() {
		
		var idaktivitas = $("#idaktivitas").val();
		var mode = $("#act").val();
		var namafile = $("#namafile").val();
		var uraian = $("#uraian").val();
		var rupiah = $("#rupiah").val();
		var tgl = $("#tgln").val();
	
		$("#frmdata").html('...PROSES DATA...');
        $.ajax({url: 'App/api.php?m=espj.input.nota',type:'post',
		data:{mode:mode,idaktivitas:idaktivitas,namafile:namafile,uraian:uraian,tgl:tgl,rupiah:rupiah},
		success: function(result){
            alert('..data tersimpan..');
			refreshnota();
			
			
        }});
    }
function refreshnota(){
		var ida = $("#idaktivitas").val();
	$("#frmdata").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=spj.nota.tabel&ida='+ida, success: function(result){
            $("#frmdata").html(result);
        }});
}
</script>
<script>
  $( function() {
    $( "#tgln" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
  } );
  refreshnota();
  </script>