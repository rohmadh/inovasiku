<?
$q="update keu_mastertagihan set spp='".$_GET['a']."',pendukung='".$_GET['b']."',extra='".$_GET['c']."',kbm='".$_GET['d']."',infaq='".$_GET['e']."',jamiyah='".$_GET['f']."',
atk='".$_GET['g']."',bukupaket='".$_GET['h']."', seragam='".$_GET['i']."',anjem='".$_GET['j']."', catering='".$_GET['k']."', osis='".$_GET['l']."', lain='".$_GET['m1']."'
where id='".$_GET['id']."'
";
$stmt = $conn->prepare($q);
$stmt->execute();
$conn = null;
?>