<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>REKENING BELANJA</th><th>PILIH</th>
							</tr>
<?$q=mysql_query("select * from tblkoderekbelanja where tipe='r' and txtkoderekbelanja like'%".$_GET['q']."%' order by koderek ASC");
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><?echo $r['koderek'];?>.<div id="txt<?echo $r['id'];?>"><?echo htmlspecialchars($r['txtkoderekbelanja']);?></div></td><td><input type="button" value="PILIH" onclick="pilihrekbelanja(<?echo $r['id'];?>);"></td>
							</tr>
							
							<?}?>
</table>
<script>
function pilihrekbelanja(k) {
var txt = $("#txt"+k+"").text();
$("#rekbelanja").val(txt);
$("#idrek").val(k);
$("#targetlistrekbelanja").html('');
<?
if($_GET['mode']=='getspd'){
?>
getnilaispd();
<?
}
?>
}
</script>