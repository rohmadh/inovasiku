<?
$a=htmlentities($_POST['a']);
if($_POST['mode']=='save'){
$q="insert into pejabat (jabatan,nama,nip) value 
('".$_POST['jab']."','".$_POST['nama']."','".$_POST['nip']."'
)";
}
########update
if($_POST['mode']=='edit'){
$q="update pejabat set jabatan='".$_POST['jab']."',nama='".$_POST['nama']."',nip='".$_POST['nip']."' 
where id='".$_POST['idd']."'
";
}
########hapus
if($_POST['mode']=='hapus'){
$q="delete from pejabat where id='".$_POST['idd']."'
";
}
########
$stmt = $conn->prepare($q);
$stmt->execute();
$stmt->errorInfo();
$conn = null;
?>