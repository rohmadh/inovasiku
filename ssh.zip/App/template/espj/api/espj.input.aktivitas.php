<?
$a=htmlentities($_POST['a']);
if($_POST['mode']=='save'){
$q="insert into aktivitas (nokeg,kprog,kkeg,uraian) value ('".$_POST['no']."','".$_POST['idprog']."','".$_POST['idkeg']."','".$_POST['nama']."')";
}
if($_POST['mode']=='edit'){
$q="update aktivitas set uraian='".$_POST['nama']."' where id='".$_POST['idd']."'";
}
$stmt = $conn->prepare($q);
$stmt->execute();
$stmt->errorInfo();
$conn = null;
?>