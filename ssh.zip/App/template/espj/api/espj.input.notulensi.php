<?
$a=htmlentities($_POST['a']);
#$q="update notulensi  set txtnotulensi='".$_POST['b']."' where idaktivitas='".stripslashes($a)."' ";
$q="insert into notulensi  (idaktivitas,txtnotulensi) value ('".stripslashes($a)."','".$_POST['b']."')";
$stmt = $conn->prepare($q);
$stmt->execute();
$stmt->errorInfo();
$conn = null;
?>