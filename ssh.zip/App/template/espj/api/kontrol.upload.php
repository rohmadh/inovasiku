

<?
#$a="88000000123";
#$f=str_split($a,8);
#echo $f[0];
$q="
SELECT pdate, wkt, count( id ) as data
FROM keu_rincian_potong_trxbank
GROUP BY pdate, wkt
order by pdate,wkt ASC
";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
?>

<div id='histtrx'>
<table class="table" style="font-size:9pt;" width="30%" id="dataTables">
<tr>
					<th>Tanggal Bank</th>
					<th>Tanggal Upload</th>
					<th>Jumlah trx</th>
                </tr>

<?
$stmt = $conn->prepare($q);
$stmt->execute();
$n=1;
$a=0;$b=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;$i=0;$j=0;$k=0;$l=0;$m=0;$tagih=0;
while ($row = $stmt->fetch()) {
?>
<tr>
                    <td><?php  echo $row['pdate']; ?></td>
					<td><?php  echo $row['wkt']; ?></td>
					<td><?echo $row['data'];?>
					</td>
</tr>
<?
$n=$n+1;
$a=$a+$row['debet'];$b=$b+$row['kredit'];$c=$c+$row['c'];$d=$d+$row['d'];$e=$e+$row['e'];$f=$f+$row['f'];$g=$g+$row['g'];
$h=$h+$row['h'];$i=$i+$row['i'];$j=$j+$row['j'];$k=$k+$row['k'];$l=$l+$row['l'];$m=$m+$row['m'];$tagih=$tagih+$row['tagih'];
$n=$i+($row['i']+$row['j']+$row['k']+$row['l']+$row['m']+$row['katering']+$row['atk']+$row['jamiyyah']);
}?>


<?$conn = null;?>
</table>
</div>