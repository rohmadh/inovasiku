<?
if($_POST['mode']=='save'){
$q="insert into srttransfer  (idbend26,nama,alamat,npwp,bank,rekbank,catatan,nosrt,denda,penyusutan,biayatransfer) 
value ('".$_POST['idsrt']."','".$_POST['nama']."','".$_POST['alamat']."','".$_POST['npwp']."','".$_POST['bank']."','".$_POST['rekbank']."','".$_POST['cat']."','".$_POST['nos']."',
'".$_POST['denda']."','".$_POST['penyusutan']."','".$_POST['biayat']."')";
$stmt = $conn->prepare($q);
$stmt->execute();}
#$stmt->errorInfo();
$conn = null;
?>