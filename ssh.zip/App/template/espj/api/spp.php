
<style>
#customers {
  font-family: Cambria;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 2px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 2px;
  padding-bottom: 2px;
  text-align: center;
  background-color: #4CAF50;
  color: white;
}

</style>

<table align="center" id="customers">
  <tr>
    <th rowspan=2>No</th>
    <th rowspan=2>Nama</th>
    <th rowspan=2>Kelas</th>
    <th colspan=2>Jan</th>
    <th colspan=2>Feb</th>
    <th colspan=2>Mar</th>
    <th colspan=2>Apr</th>
    <th colspan=2>Mei</th>
    <th colspan=2>Jun</th>
    <th colspan=2>Jul</th>
    <th colspan=2>Ags</th>
    <th colspan=2>Sep</th>
    <th colspan=2>Okt</th>
    <th colspan=2>Nov</th>
    <th colspan=2>Des</th>
	<th rowspan=2>Total</th>
  </tr>
  <tr>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  <th>Tag</th>
  <th>Bayar</th>
  </tr>
  <?php
  #include("konek.php");
  if(isset($_GET['q'])){
  $query ="SELECT nama,kelas,
  sum(case when month(thn)=1 then spp else 0 end) as t1,
  sum(case when month(thn)=1 then bspp else 0 end) as b1,
  sum(case when month(thn)=2 then spp else 0 end) as t2,
  sum(case when month(thn)=2 then bspp else 0 end) as b2,
  sum(case when month(thn)=3 then spp else 0 end) as t3,
  sum(case when month(thn)=3 then bspp else 0 end) as b3,
  sum(case when month(thn)=4 then spp else 0 end) as t4,
  sum(case when month(thn)=4 then bspp else 0 end) as b4,
  sum(case when month(thn)=5 then spp else 0 end) as t5,
  sum(case when month(thn)=5 then bspp else 0 end) as b5,
  sum(case when month(thn)=6 then spp else 0 end) as t6,
  sum(case when month(thn)=6 then bspp else 0 end) as b6,
  sum(case when month(thn)=7 then spp else 0 end) as t7,
  sum(case when month(thn)=7 then bspp else 0 end) as b7,
  sum(case when month(thn)=8 then spp else 0 end) as t8,
  sum(case when month(thn)=8 then bspp else 0 end) as b8,
  sum(case when month(thn)=9 then spp else 0 end) as t9,
  sum(case when month(thn)=9 then bspp else 0 end) as b9,
  sum(case when month(thn)=10 then spp else 0 end) as t10,
  sum(case when month(thn)=10 then bspp else 0 end) as b10,
  sum(case when month(thn)=11 then spp else 0 end) as t11,
  sum(case when month(thn)=11 then bspp else 0 end) as b11,
  sum(case when month(thn)=12 then spp else 0 end) as t12,
  sum(case when month(thn)=12 then bspp else 0 end) as b12
  FROM keu_mastertagihan where kelas like'%".$_GET['q']."%' and year(thn)='".$_SESSION['thn']."'
  group by va1
  order by b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12 ASC
  ";
  $ambil = mysql_query ($query);
  $no=1;
  while($data=mysql_fetch_array($ambil)){
	if($data['t9']=$data['b9']){$blm="bgcolor='green'";}
	$tot=$data[b1]+$data[b2]+$data[b3]+$data[b4]+$data[b5]+$data[b6]+$data[b7]+$data[b8]+$data[b9]+$data[b10]+$data[b11]+$data[b12];
  echo "
  <tr>
    <td>$no</td>
    <td>$data[nama]</td>
    <td>$data[kelas]</td>
    <td align=right>$data[t1]</td>
    <td align=right>$data[b1]</td>
    <td align=right>$data[t2]</td>
    <td align=right>$data[b2]</td>
    <td align=right>$data[t3]</td>
    <td align=right>$data[b3]</td>
    <td align=right>$data[t4]</td>
    <td align=right>$data[b4]</td>
    <td align=right>$data[t5]</td>
    <td align=right>$data[b5]</td>
    <td align=right>$data[t6]</td>
    <td align=right>$data[b6]</td>
    <td align=right>$data[t7]</td>
    <td align=right>$data[b7]</td>
    <td align=right>$data[t8]</td>
    <td align=right>$data[b8]</td>
    <td align=right>$data[t9]</td>
    <td ".$blm." align=right>$data[b9]</td>
    <td align=right>$data[t10]</td>
    <td align=right>$data[b10]</td>
    <td align=right>$data[t11]</td>
    <td align=right>$data[b11]</td>
    <td align=right>$data[t12]</td>
    <td align=right>$data[b12]</td>
	<td align=right>$tot</td>
  </tr>";
  $no++;

}}
?>
</table>

