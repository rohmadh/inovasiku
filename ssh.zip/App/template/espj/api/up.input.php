<?

if($_GET['mode']=='save'){
mysql_query("insert into tblup (tgl,jml,uraian,user,tahun) value ('".$_GET['tgl']."','".$_GET['jml']."','".$_GET['uraian']."','".$_SESSION['iduser']."','".$_SESSION['thn']."')");
}
if($_GET['mode']=='edit'){
mysql_query("update tblup set tgl='".$_GET['tgl']."',jml='".$_GET['jml']."',uraian='".$_GET['uraian']."' where id='".$_GET['id']."'");
}
if($_GET['mode']=='del'){
mysql_query("delete from tblup where id='".$_GET['id']."'");
}
?>