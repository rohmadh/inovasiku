<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>TANGGAL</th><th>JUMLAH</th><th>URAIAN</th><th>PROSES</th>
							</tr>
<?$no=0;$q=mysql_query("select * from tblup where user='".$_SESSION['iduser']."' and tahun='".$_SESSION['thn']."'");
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><?echo htmlspecialchars($r['tgl']);?></td>
							<td><?echo htmlspecialchars(uang($r['jml']));?></td>
							<td><?echo htmlspecialchars($r['uraian']);?></td>
							<td><input type='button' onclick="pilih(<? echo $r['id'];?>);" value='EDIT'>
							<input type='button' onclick="del(<? echo $r['id'];?>);" value='HAPUS'>
							</td>
							</tr>
							
							<?$no=$no+1;}?>
</table>
<div id='loader'>
</div>
<script>
function pilih(k) {
        $.ajax({url: 'App/api.php?m=load.up&k='+k, success: function(result){
            $("#loader").html(result);
        }});
    }
</script>
<script>
function del(k) {
        $.ajax({url: 'App/api.php?m=up.input&mode=del&id='+k, success: function(result){
            alert('..DATA TERHAPUS..');
			refreshtabel();
        }});
    }
</script>