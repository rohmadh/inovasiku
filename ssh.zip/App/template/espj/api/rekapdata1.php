<?
mysql_query("truncate table laporankendali1");
mysql_query("
insert into laporankendali1 (idkeg,idrek,korek,jml,tipe)
select idkeg,idrek,tblkoderekbelanja.koderek,sum(jml) as j,'2' from tblspj 
left join tblkoderekbelanja on tblspj.idrek=tblkoderekbelanja.id
left join tblkegiatan on tblkegiatan.id=tblspj.idkeg
where tblkegiatan.tahun='".$_SESSION[thn]."'
group by idkeg,tblspj.idrek
");
mysql_query("
insert into laporankendali1 (idkeg,idrek,korek,jml,tipe)
select idkeg,koderekbelanja,tblkoderekbelanja.koderek,sum(tw1+tw2+tw3+tw4) as j,'1' from tblpenyediaandana
left join tblkoderekbelanja on tblpenyediaandana.koderekbelanja=tblkoderekbelanja.id
left join tblkegiatan on tblkegiatan.id=tblpenyediaandana.idkeg
where tipe='r' and tblkegiatan.tahun='".$_SESSION['thn']."'
group by
idkeg,koderek
");
?>