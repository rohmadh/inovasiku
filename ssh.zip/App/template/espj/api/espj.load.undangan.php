<?
#$q="select * from undangan where id='"$_GET['id']"'";
#echo $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM undangan where id='".$_GET['id']."'");
$exec = $stmt->execute();
$r = $stmt->fetch();
$conn = null;
?>
<script>

$("#dhari").val('<? echo $r['hari'];?>');
$("#tglu").val('<? echo $r['tgl'];?>');
$("#djam").val('<? echo $r['jam'];?>');
$("#dtempat").val('<? echo $r['tempat'];?>');
$("#dacara").val('<? echo $r['acara'];?>');
$("#act").val('edit');
$("#idd").val('<? echo $r['id'];?>');
$("#dacara").val("<? echo htmlspecialchars($r['acara']);?>");
</script>