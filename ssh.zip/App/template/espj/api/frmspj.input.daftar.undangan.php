
<table border="0">
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Hari</label></td><td><label>:</label></td>
<td>
<input type="text" id="dhari" disabled>
<input type="hidden" id="act" value="save">
<input type="hidden" id="ida" value="">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Tanggal</label></td><td><label>:</label></td>
<td>
<input type="text" id="tglu" disabled>
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Jam</label></td><td><label>:</label></td>
<td>
<input type="text" id="djam" disabled>
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Tempat</label></td><td><label>:</label></td>
<td>
<input type="text" id="dtempat" size="50" disabled>
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Acara</label></td><td><label>:</label></td>
<td>
<input type="text" id="dacara" size="50" disabled>
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Nama Lengkap</label></td><td><label>:</label></td>
<td>
<input type="text" id="dnama" size="50">
</td>
</tr>

<tr>
<td>&nbsp;&nbsp;&nbsp;</td>
<td></td><td></td><td><input type="submit" value="SIMPAN"  id="btnsave" onclick="simpan2();"><input type="submit" value="CLEAR"  id="btnnew" onclick="$('#dnama').val('');">
<input type="submit" value="CETAK PRESENSI"  id="btnnew" onclick="loadp2();">
<input type="submit" value="CETAK DAFTAR UNDANGAN"  id="btnp" onclick="loadp3();">
<input type="button" value="NOTULEN" onclick="getfrmnotulensi();">
</td>
</tr>
</table>
<script>
function simpan2() {		
		var idprog = $("#idprog").val();
		var idkeg = $("#idkeg").val();
		var nama = $("#dnama").val();
		var ida = $("#ida").val();
		var mode = $("#act").val();
		$("#frmdata").html('...PROSES DATA...');
        $.ajax({url: 'App/api.php?m=espj.input.daftar.undangan',type:'post',
		data:{mode:mode,idprog:idprog,idkeg:idkeg,nama:nama,ida:ida},
		success: function(result){
            $("#frmdata").html(result);
			refreshdaftarundangan();
			
        }});
    }

refreshdaftarundangan();
</script>

<script>
function getfrmnotulensi() {
		var kkeg = $("#idkeg").val();
		var n = $("#nourut").val();
		$("#judulbox").html("FORM NOTULENSI");
		$("#frmdata").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=frmspj.input.notulensi&q='+kkeg+'&n='+n, success: function(result){
            $("#frmdata").html(result);
        }});
		
    }
function loadp2() {
		var ta=$("#ida").val();
		window.open("./?action=print&page=espj.presensi.undangan.print&a="+ta, "_blank");
    }
function loadp3() {
		var ta=$("#ida").val();
		window.open("./?action=print&page=espj.daftar.undangan.print&a="+ta, "_blank");
    }
</script>
