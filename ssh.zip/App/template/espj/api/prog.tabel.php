<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>NAMA PROGRAM/KEGIATAN</th><?if($_SESSION['iduser']==0){?><th>PROSES</th><?}?>
							</tr>
<?

$q=mysql_query("select * from master where kprog !='' and tahun='".$_SESSION['thn']."' order by kode ASC");echo mysql_error();
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><div id="txt<?echo $r['id'];?>" <?if($r['status']=='0'){?>style='color:red;'<?}?>><?echo htmlspecialchars($r['kprog']);?></div></td>
							<?if($_SESSION['iduser']==0){?>
							<td>
							
							<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=kendali.input.keg&id=".$r['kode']."",$key2));?>">KEGIATAN</a>,
							
							<a href="#" onclick='pilihprog(<?echo $r['id'];?>);'>Edit</a>
							
							</td><?}?>
							</tr>
							
							<?}?>
</table>
<script>
function pilihprog(k) {
var txt = $("#txt"+k+"").text();
$("#namaprog").val(txt);
$("#idprog").val(k);
$("#mode").val('edit');
$("#targetlistkeg").html('');
}
</script>