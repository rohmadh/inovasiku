<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>NAMA KEGIATAN</th><th>PROSES</th>
							</tr>
<?$no=0;$q=mysql_query("select * from master where kkeg !=''  and kode like'".$_GET['id']."%' order by kode ASC");
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><div id="txt<?echo $no;?>"><?echo htmlspecialchars($r['kkeg']);?></div></td>
							
							<td><input type='button' onclick="pilihkeg('<? echo $no;?>','<? echo $r['kode'];?>');" value='EDIT'></td>
							</tr>
							
							<?$no=$no+1;}?>
</table>
<script>
function pilihkeg(k,k2) {
var txt = $("#txt"+k+"").text();
$("#mode").val('edit');
$("#namakeg").val(txt);
$("#idkeg").val(k2);
$("#targetlistkeg").html('');
}
</script>