<?
mysql_query("truncate table laporankendali2");
mysql_query("
insert into laporankendali2 (idprog,idkeg,uraian,gv,tu,ls,panjar,lalu,ini,sdini)
SELECT program.id as idprog,tblspj.idkeg,txtkegiatan,
sum(case when tipespj='1' then jml else 0 end) as j1,
sum(case when tipespj='2' then jml else 0 end) as j2,
sum(case when tipespj='3' then jml else 0 end) as j3,
sum(tblpanjar.npanjar) as panjar,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj.tgl,'%d/%m/%Y'))<month(now())) then jml else 0 end) as lalu,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj.tgl,'%d/%m/%Y'))=month(now())) then jml else 0 end) as ini,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj.tgl,'%d/%m/%Y'))<=month(now())) then jml else 0 end) as sdini 
from tblspj 
left join tblkegiatan on tblkegiatan.id=tblspj.idkeg
left join tblpanjar on tblspj.idpanjar=tblpanjar.id
left join program on tblkegiatan.kprogram=program.id
group by tblspj.idkeg
");

?>