<script>
  $( function() {
    $( "#tglu" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
  } );
  </script>
<table border="0">
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Hari</label></td><td><label>:</label></td>
<td>
<input type="text" id="dhari">
<input type="hidden" id="act" value="save">
<input type="text" id="idd" value="">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Tanggal</label></td><td><label>:</label></td>
<td>
<input type="text" id="tglu">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Jam</label></td><td><label>:</label></td>
<td>
<input type="text" id="djam">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Tempat</label></td><td><label>:</label></td>
<td>
<input type="text" id="dtempat">
</td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Acara</label></td><td><label>:</label></td><td>
<textarea rows="5" cols="70" id="dacara"></textarea>
</td>
</tr>


<tr>
<td>&nbsp;&nbsp;&nbsp;</td>
<td></td><td></td><td><input type="submit" value="SIMPAN"  id="btnsave" onclick="simpan();"><input type="submit" value="CLEAR"  id="btnnew" onclick="frmtransaksireset();">
</td>
</tr>
</table>
<script>
function simpan() {
		var hari = $("#dhari").val();
		var tgl = $("#tglu").val();
		var tempat = $("#dtempat").val();
		var acara = $("#dacara").val();
		var jam = $("#djam").val();
		var idprog = $("#idprog").val();
		var idkeg = $("#idkeg").val();
		var nourut = $("#nourut").val();
		var idaktivitas = $("#idaktivitas").val();
		var mode = $("#act").val();
		var idd = $("#idd").val();
		$("#frmdata").html('...PROSES DATA...');
        $.ajax({url: 'App/api.php?m=espj.input.undangan',type:'post',
		data:{mode:mode,idd:idd,hari:hari,tgl:tgl,tempat:tempat,acara:acara,jam:jam,idprog:idprog,idkeg:idkeg,nourut:nourut,idaktivitas:idaktivitas},
		success: function(result){
            $("#frmdata").html(result);
			refreshundangan();
			
        }});
    }
</script>
