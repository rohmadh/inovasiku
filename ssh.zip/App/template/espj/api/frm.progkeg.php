<table>
<tr>
<td>&nbsp;&nbsp;&nbsp;
<input type="hidden" id="modep" value="save">
<input type="hidden" id="idprog" value="0000">
<input type="hidden" id="idkeg" value="">
<input type="hidden" id="nourut" value="">
<input type="hidden" id="idaktivitas" value="">

</td>
<td><label>NAMA PROGRAM </label></td><td><label>:</label></td><td><input name="nama" id="namaprog" class="form-controls" type="text" size="100" disabled>
<br />
<div id="targetlistprog"></div>
</td>
<td><label>KATA KUNCI :</label><input type="text" id="qp" onfocus='setawal();'><input type="button" value="CARI" onclick='getlprog();'></td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>NAMA KEGIATAN</label></td><td><label>:</label></td><td valign="top"><input name="nama" id="namakeg" class="form-controls" type="text" size="100" disabled>
<br />
<div id="targetlistkeg"></div>
</td>
<td><label>KATA KUNCI :</label><input type="text" id="qk" onfocus='setawal();'><input type="button" value="CARI" onclick='getlkeg();'></td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>NAMA AKTIVITAS</label></td><td><label>:</label></td><td valign="top"><input name="nama" id="txtaktivitas" class="form-controls" type="text" size="100" disabled>
<br />
</td>
<td></td>
</tr>
</table>
<script>
function getlprog() {
		$("#targetlistprog").html('<h1>...LOADING...</h1>');
		var k=$("#qp").val();
        $.ajax({url: 'App/api.php?m=listprogall&q='+k, success: function(result){
            $("#targetlistprog").html(result);
			$("#targetlistkeg").html('');
        }});
    }
</script>
<script>
function getlkeg() {
		$("#targetlistkeg").html('<h1>...LOADING...</h1>');
		var k=$("#qk").val();
		var kp=$("#idprog").val();
        $.ajax({url: 'App/api.php?m=listkeg&idprog='+kp+'&q='+k, success: function(result){
            $("#targetlistkeg").html(result);
        }});
    }
</script>