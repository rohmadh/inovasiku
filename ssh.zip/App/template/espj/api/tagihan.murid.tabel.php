<script>
function loadbayar(t,k,v) {
		$("#tbayar"+t+"").html('<i>..load..</i>');
        $.ajax({url: 'App/api.php?m=get.bayar.bulan&v='+v+'&k='+k, success: function(result){
            $("#tbayar"+t+"").html(result);
        }});
    }
</script>
<script>
function savehistrx(id) {
		a=$("#"+id+"a").val();
		b=$("#"+id+"b").val();
		c=$("#"+id+"c").val();
		d=$("#"+id+"d").val();
		e=$("#"+id+"e").val();
		f=$("#"+id+"f").val();
		g=$("#"+id+"g").val();
		h=$("#"+id+"h").val();
		i=$("#"+id+"i").val();
		j=$("#"+id+"j").val();
		k=$("#"+id+"k").val();
		l=$("#"+id+"l").val();
		m1=$("#"+id+"m").val();
        $.ajax({url: 'App/api.php?m=input.data.tagih&id='+id+'&a='+a+'&b='+b+'&c='+c+'&d='+d+'&e='+e+'&f='+f+'&g='+g+'&h='+h+'&i='+i+'&j='+j+'&k='+k+'&l='+l+'&m1='+m1, success: function(result){
			load1();
            alert('data tersimpan..');
        }});
    }
</script>
<?
#$a="88000000123";
#$f=str_split($a,8);
#echo $f[0];
$q="SELECT * from keu_mastertagihan
where va1='".$_GET['q']."'
group by va1
";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
$row1 = $stmt->fetch();
###### query data
#####
$q2="
SELECT id,nama,va1,va2,spp as a,pendukung as b, extra as c,kbm as d,infaq as e,jamiyah as f,
atk as g,bukupaket as h, seragam as i,anjem j, catering as k, osis as l, lain as m,
spp+pendukung+extra+kbm+infaq+jamiyah+atk+bukupaket+seragam+anjem+catering+osis+lain as tagih,month(thn) as bulan,year(thn) as tahun 
FROM keu_mastertagihan
where nama like'%".$_GET['nis']."%'
order by nama,bulan,tahun ASC
";

?>

<div id='histtrx'>
<table class="table" style="font-size:9pt;" width="100%" class="table table-striped table-bordered table-hover" id="dataTables">
<tr>
					<th>nama</th>
					<th>bln/thn</th>
					<th>spp</th>
					<th>pendukung</th>
					<th>extra</th>
					<th>kbm</th>
					<th>infaq</th>
					<th>jamiyah</th>
					<th>atk</th>
					<th>b.paket</th>
					<th>seragam</th>
					<th>anjem</th>
					<th>catering</th>
					<th>osis</th>
					<th>lain</th>
					<th>Tagihan</th>
					
					<th>action</th>
                </tr>

<?
$stmt = $conn->prepare($q2);
$stmt->execute();
$n=1;
$a=0;$b=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;$i=0;$j=0;$k=0;$l=0;$m=0;$tagih=0;
while ($row = $stmt->fetch()) {
?>
<tr>
					<td><?php  echo $row['nama']; ?></td>
                    <td><?php  echo $row['bulan']."-".$row['tahun']; ?></td>
					<td><input type="text" id="<?echo $row['id']?>a" value="<?php  echo $row['a']; ?>" size=6></td>
					<td><input type="text" id="<?echo $row['id']?>b" size=6 value="<?php  echo $row['b']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>c" size=6 value="<?php  echo $row['c']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>d" size=6 value="<?php  echo $row['d']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>e" size=6 value="<?php  echo $row['e']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>f" size=6 value="<?php  echo $row['f']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>g" size=6 value="<?php  echo $row['g']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>h" size=6 value="<?php  echo $row['h']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>i" size=6 value="<?php  echo $row['i']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>j" size=6 value="<?php  echo $row['j']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>k" size=6 value="<?php  echo $row['k']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>l" size=6 value="<?php  echo $row['l']; ?>" ></td>
					<td><input type="text" id="<?echo $row['id']?>m" size=6 value="<?php  echo $row['m']; ?>" ></td>
					<td><?php  echo uang($row['tagih']); ?></td>
					

<td><input type="button" value="V" onclick="savehistrx('<?echo txthtml($row['id']);?>')"></td>
</tr>
<?
$n=$n+1;
$a=$a+$row['a'];$b=$b+$row['b'];$c=$c+$row['c'];$d=$d+$row['d'];$e=$e+$row['e'];$f=$f+$row['f'];$g=$g+$row['g'];
$h=$h+$row['h'];$i=$i+$row['i'];$j=$j+$row['j'];$k=$k+$row['k'];$l=$l+$row['l'];$m=$m+$row['m'];$tagih=$tagih+$row['tagih'];
$n=$i+($row['i']+$row['j']+$row['k']+$row['l']+$row['m']+$row['katering']+$row['atk']+$row['jamiyyah']);
}?>
<tr>
<td style='text-align:left;'><?echo txthtml("TOTAL");?></td><td></td>
<td><?echo txthtml(uang($a));?></td><td><?echo txthtml(uang($b));?></td><td><?echo txthtml(uang($c));?></td>
<td><?echo txthtml(uang($d));?></td><td><?echo txthtml(uang($e));?></td><td><?echo txthtml(uang($f));?></td>
<td><?echo txthtml(uang($g));?></td><td><?echo txthtml(uang($h));?></td>
<td><?echo txthtml(uang($i));?></td><td><?echo txthtml(uang($j));?></td><td><?echo txthtml(uang($k));?></td>
<td><?echo txthtml(uang($l));?></td><td><?echo txthtml(uang($m));?></td>
<td><?echo txthtml(uang($tagih));?></td><td></td>
</tr>

<?$conn = null;?>
</table>
</div>