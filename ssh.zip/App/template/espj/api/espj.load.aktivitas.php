<?
#$q="select * from undangan where id='"$_GET['id']"'";
#echo $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM aktivitas where id='".$_POST['id']."'");
$exec = $stmt->execute();
$r = $stmt->fetch();
$conn = null;
?>
<script>
$("#daktv").val('<? echo $r['uraian'];?>');
$("#idd").val('<? echo $r['id'];?>');
$("#act").val('edit');

</script>