<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td { 
  font-family:verdana;
  font-size: 11px; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>NAMA PROGRAM</th><th>PILIH</th>
							</tr>
<?$no=1;$q=mysql_query("select * from master_import where kprog !='' and tahun='".$_SESSION['thn']."' and kprog like'%".$_GET['q']."%' order by kode ASC");
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><div id="t<?echo $no;?>"><?echo htmlspecialchars($r['kprog']);?></div></td><td><input type="button" value="PILIH" onclick="pilihprog('<?echo $no;?>','<?echo $r['kode'];?>');"></td>
							</tr>
							
							<?$no=$no+1;}?>
</table>
<script>
function pilihprog(n,k) {
var txt = $("#t"+n+"").text();
$("#namaprog").val(txt);
$("#idprog").val(k);
$("#targetlistprog").html('');

}
</script>
