<table class="table">
<tr>
<th>Program/Kegiatan</th><th>Penyediaan Dana</th><th>Pengesahan SPJ</th><th>Sisa SPD</th>
</tr>
<?
$q=mysql_query("select * from program");
while($r=mysql_fetch_array($q)){
?>
<tr>
<td><b><?echo strtoupper($r['txtprogram']);?></b></td><td></td><td></td><td></td>
</tr>
<?
$q2=mysql_query("select * from tblkegiatan where kprogram='".$r['id']."'");
while($r2=mysql_fetch_array($q2)){
?>
<tr>
<td><i><?echo $r2['txtkegiatan'];?></i></td><td></td><td></td><td></td>
</tr>
<?
$q4=mysql_query("select * from tblkoderekbelanja order by id ASC");
while($r4=mysql_fetch_array($q4)){
?>
<tr>
<td><?echo $r4['koderek'];?>. <?echo $r4['txtkoderekbelanja'];?></td>

<?
if($r4['tipe']=='r'){
$q3=mysql_query("select *, 
sum(case when laporankendali1.tipe='1' then jml else 0 end) as spd,
sum(case when laporankendali1.tipe='2' then jml else 0 end) as spj
from laporankendali1 
left join tblkoderekbelanja on laporankendali1.idrek=tblkoderekbelanja.id
where idkeg='".$r2['id']."' and tblkoderekbelanja.koderek like'".$r4[koderek]."%'
group by laporankendali1.idrek
order by laporankendali1.idrek ASC
");
echo mysql_error();
while($r3=mysql_fetch_array($q3)){
?>

<td><?echo uang($r3['spd']);?></td><td><?echo uang($r3['spj']);?></td><td><?echo uang($r3['spd']-$r3['spj']);?></td>
</tr>
<?}}else{
?>
<td></td><td></td><td></td>
<?}?>
<?}?>


<?}?>
<?}?>
</table>