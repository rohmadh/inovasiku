<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>NAMA KEGIATAN</th><th>PILIH</th>
							</tr>
<?$q=mysql_query("select * from tblkegiatan where txtkegiatan like'%".$_GET['q']."%' order by txtkegiatan ASC");
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><div id="txt<?echo $r['id'];?>"><?echo htmlspecialchars($r['txtkegiatan']);?></div></td><td><input type="button" value="PILIH" onclick="pilihkeg(<?echo $r['id'];?>);"></td>
							</tr>
							
							<?}?>
</table>
<script>
function pilihkeg(k) {
var txt = $("#txt"+k+"").text();
$("#namakeg").val(txt);
$("#idkeg").val(k);
$("#targetlistkeg").html('');
<?
if($_GET['mode']=='panjar'){
?>
getnilaipanjar();
<?
}
?>
}
</script>