<?
$a=htmlentities($_POST['a']);
if($_POST['mode']=='save'){
$q="insert into bend26 (tgl,trmdari,untukpemb,idkeg,kkeg,txtrupiah,rupiah,namafile,krek,krekbelanja,ppn,pph23,pajakdaerah) value 
('".$_POST['tgl']."','".$_POST['txtdari']."','".$_POST['uraian']."','".$_POST['no']."','".$_POST['idkeg']."','".$_POST['txtuang']."','".$_POST['rupiah']."','".$_POST['namafile']."','".$_POST['krek']."','".$_POST['krekb']."',
'".$_POST['ppn']."','".$_POST['pph23']."','".$_POST['pajakdaerah']."'
)";
$stmt = $conn->prepare($q);
$stmt->execute();
$stmt->errorInfo();
$conn = null;
}
?>