
<table border="0">
<tr>
<td>&nbsp;&nbsp;&nbsp;

</td>
<td><label>Uraian Aktivitas</label></td><td><label>:</label></td>
<td>
<input class="form-control" type="text" id="daktv" size="80">
<input type="hidden" id="act" value='save'>
<input type="hidden" id="idd">
</td>
</tr>

<tr>
<td>&nbsp;&nbsp;&nbsp;</td>
<td></td><td></td><td>
<input type="submit" value="SIMPAN"  id="btnsave" onclick="simpanaktv();"><input type="submit" value="CLEAR"  id="btnnew" onclick="$('#daktv').val('');">

</td>
</tr>
</table>
<div id='targetresp'></div>
<script>
function simpanaktv() {		
		var idprog = $("#idprog").val();
		var idkeg = $("#idkeg").val();
		var nama = $("#daktv").val();
		var no = $("#nourut").val();
		var idd = $("#idd").val();
		var mode = $("#act").val();
		$("#frmdata").html('...PROSES DATA...');
        $.ajax({url: 'App/api.php?m=espj.input.aktivitas',type:'post',
		data:{mode:mode,idprog:idprog,idkeg:idkeg,nama:nama,no:no,idd:idd},
		success: function(result){
            $("#targetresp").html(result);
			clearform();
			refreshaktivitas();
			
        }});
    }
function clearform() {
$("#daktv").val('');
$("#act").val('save');
}

</script>


