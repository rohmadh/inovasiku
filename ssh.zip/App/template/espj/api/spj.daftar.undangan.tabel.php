<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
  font-size: 9pt;
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
  font-size: 9pt;
}
</style>
<table class="table">
<tr>
							<th>Undangan</th><th>PROSES</th>
							</tr>
<? 
echo $_GET['n'];
$stmt = $conn->prepare("SELECT * FROM daftar_undangan where idaktivitas ='".$_GET['ida']."' ORDER BY id ASC");
$exec = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
foreach ($rows as $r) {
							
							?>
							
							
							<tr>
							<td><?echo htmlspecialchars($r['nama']);?></td>
							
							<td>
							<select id="optaction">
							<option value="cetak">...</option>
							
							<option value="hapus" onclick="hapus('<?echo $r['id']?>');">HAPUS</option>
							</select>
							
							</td>
							</tr>
							
							<?}?>
</table>
<script>
function hapus(k) {
$.ajax({url: 'App/api.php?m=espj.input.daftar.undangan',type:'post',data:{mode:'hapus',idd:k}, success: function(result){
			$("#loader").html(result);
			alert('...DATA TERHAPUS...');
			refreshdaftarundangan();
        }});
}
</script>

<script>
function frmspj(k) {
$.ajax({url: 'App/api.php?m=load.progkeg&id='+k, success: function(result){
			$("#loader").html(result);
        }});
		$("#frmtarget").html('<h2>...LOADING FORM...</h2>');
        $.ajax({url: 'App/api.php?m=frmspj.input&id='+k, success: function(result){
            $("#frmtarget").html(result);
        }});
    }
</script>
<script>
function editundangan(k) {
$("#frmdata").html('...LOADING DATA...');
$.ajax({url: 'App/api.php?m=espj.load.undangan&id='+k, success: function(result){
			$("#targetresp").html(result);
			refreshundangan();
        }});
}
function loadundangan(k) {
$("#frmdata").html('...LOADING DATA...');
$.ajax({url: 'App/api.php?m=espj.load.undangan&id='+k, success: function(result){
			$("#targetresp").html(result);
			$("#act").val('save');
			$("#ida").val(k);
        }});
}
</script>
<script>
function loadp() {
		var ta=$("#bln").val();
		window.open("./?action=print&page=espj.undangan.print&a="+ta, "_blank");
    }
</script>