<?
$s=$_GET['q'];
$cari="%$s%";
$q="select * from murid where status='1' and (nim=:s or nama like :cari)";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->bindValue(':cari', $cari, PDO::PARAM_STR);
$stmt->bindValue(':s', $s, PDO::PARAM_STR);
$stmt->execute();
?>
<table>

<?
while ($row = $stmt->fetch()) {
?>							
<tr>
<td>
<?echo txthtml($row['nama']).'-['.txthtml($row['nim']).']';?>
</td><td><?if(strlen($row['nim'])>1){?><input type="button" onclick="pilih('<?echo txthtml($row['nama']);?>','<?echo txthtml($row['nim']);?>');" value="ok"><?}else{echo "<em>NIM KOSONG</em>";}?></td>
</tr>
<?}?>
</table>
<?$conn = null;?>
<script>
function pilih(n,i){
$("#dari").val(n);
$("#klien").html('');
$("#idklien").val(i);
}
</script>