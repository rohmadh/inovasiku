<?
$q="
SELECT vanumber, month( pdate ) AS bulanb, year( pdate ) AS tahunb, sum( kredit ) AS bayar
FROM keu_trxbank
where vanumber='".$_GET['v']."' and month(pdate)='".$_GET['k']."'
and year( pdate )='".$_GET['thn']."'
GROUP BY vanumber, bulanb, tahunb
";
#$stmt = $conn->prepare("SELECT * FROM keu_pengguna");
$stmt = $conn->prepare($q);
$stmt->execute();
$row = $stmt->fetch();
if($row['bayar']==''){echo "0";}else{echo uang($row['bayar']);}

?>

