<?
#$q="select * from undangan where id='"$_GET['id']"'";
#echo $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM notulensi where idaktivitas='".$_GET['a']."'");
$exec = $stmt->execute();
$r = $stmt->fetch();
$conn = null;
?>
<? echo htmlspecialchars($r['txtnotulensi']);?>