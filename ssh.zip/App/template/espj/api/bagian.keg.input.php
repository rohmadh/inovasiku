<?
if($_GET['mode']=='save'){
mysql_query("insert into tbl_keg_bagian (koderek,kodeuser,tahun) value ('".$_GET['kodekeg']."','".$_GET['kodebag']."','".$_SESSION['thn']."')");
}
if($_GET['mode']=='edit'){
mysql_query("update tbl_keg_bagian set koderek='".$_GET['kodekeg']."',kodeuser='".$_GET['kodebag']."',tahun='".$_SESSION['thn']."' where id='".$_GET['iddata']."'");
}
if($_GET['mode']=='del'){
mysql_query("delete from tbl_keg_bagian where id='".$_GET['iddata']."'");
}
?>