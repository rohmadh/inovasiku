<?
if($_GET['mode']=='copy'){
#mysql_query("delete from master where tahun='".$_SESSION['thn']."' ");
mysql_query("insert into keu_mastertagihan 
(nama,kelas,va1,va2,spp,bspp,pendukung,bpendukung,extra,bextra,kbm,bkbm,infaq,binfaq,jamiyah,bjamiyah,atk,batk,bukupaket,bbukupaket,seragam,bseragam,anjem,banjem,catering,bcatering,osis,bosis,lain,blain,thn,iduplod)
select
nama,kelas,va1,va2,spp,bspp,pendukung,bpendukung,extra,bextra,kbm,bkbm,infaq,binfaq,jamiyah,bjamiyah,atk,batk,bukupaket,bbukupaket,seragam,bseragam,anjem,banjem,catering,bcatering,osis,bosis,lain,blain,thn,iduplod  
from keu_mastertagihan_temp where iduplod='".$_GET['iduplod']."'");
########hapus space


mysql_query("UPDATE keu_mastertagihan set va1=REPLACE(va1,' ','') WHERE va1 NOT LIKE '%BNI%'");
mysql_query("UPDATE keu_mastertagihan set va2=REPLACE(va2,' ','') WHERE va2 NOT LIKE '%BNI%'");
		
}
echo mysql_error();
?>