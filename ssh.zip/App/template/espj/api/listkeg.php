<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>NAMA KEGIATAN</th><th>PILIH</th>
							</tr>
<?$no=1;
#$q=mysql_query("select kodekeg as kode, uraian as kkeg from kegiatan where uraian like'%".$_GET['q']."%'");
$q="select kodekeg as kode, uraian as kkeg from kegiatan where uraian like'%".$_GET['q']."%'
";
$stmt = $conn->prepare($q);
$exec = $stmt->execute();
$rows = $stmt->fetchAll();
foreach ($rows as $r) {

							#while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><div id="txt<?echo $no;?>"><?echo htmlspecialchars($r['kkeg']);?></div></td><td><input type="button" value="PILIH" onclick="pilihkeg('<?echo $no;?>','<?echo $r['kode'];?>','<?echo $r['id'];?>');">
							
							</td>
							</tr>
							
							<?$no=$no+1;}echo mysql_error();?>
</table>

<script>
function pilihkeg(k,p,i) {
var txt = $("#txt"+k+"").text();
$("#namakeg").val(txt);
$("#nourut").val(i);
$("#idkeg").val(p);
$("#targetlistkeg").html(''); 
}
</script>
