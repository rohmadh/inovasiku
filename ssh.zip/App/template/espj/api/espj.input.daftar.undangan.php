<?
if($_POST['mode']=='save'){
$q="insert into daftar_undangan (kprog,kkeg,idaktivitas,nama) value ('".$_POST['idprog']."','".$_POST['idkeg']."','".$_POST['ida']."','".$_POST['nama']."')";
#echo $_POST['tgl'];
}
if($_POST['mode']=='hapus'){
$q="delete from daftar_undangan where id='".$_POST['idd']."'";
#echo $_POST['tgl'];
}
$stmt = $conn->prepare($q);
$stmt->execute();
$conn = null;
?>