<?
#$q="select * from undangan where id='"$_GET['id']"'";
#echo $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM pejabat where id='".$_GET['id']."'");
$exec = $stmt->execute();
$r = $stmt->fetch();
$conn = null;
?>
<script>
$("#nama").val('<? echo $r['nama'];?>');
$("#jab").val('<? echo $r['jabatan'];?>');
$("#nip").val('<? echo $r['nip'];?>');
$("#idd").val('<? echo $r['id'];?>');
$("#mode").val('edit');

</script>