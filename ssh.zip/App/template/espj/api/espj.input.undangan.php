<?
if($_POST['mode']=='save'){
$q="insert into undangan (hari,tgl,jam,tempat,acara,idprog,idkeg,nourut,idaktivitas) value ('".$_POST['hari']."','".$_POST['tgl']."','".$_POST['jam']."','".$_POST['tempat']."','".$_POST['acara']."'
,'".$_POST['idprog']."','".$_POST['idkeg']."','".$_POST['nourut']."','".$_POST['idaktivitas']."')";
}
if($_POST['mode']=='edit'){
$q="
update undangan set hari='".$_POST['hari']."',tgl='".$_POST['tgl']."',jam='".$_POST['jam']."',
tempat='".$_POST['tempat']."',acara='".$_POST['acara']."'
where id='".$_POST['idd']."'
";

}
if($_POST['mode']=='hapus'){
$q="
delete from undangan
where id='".$_POST['idd']."'
";

}
echo $_POST['tgl'];
$stmt = $conn->prepare($q);
$stmt->execute();
$conn = null;
?>