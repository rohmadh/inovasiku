<h2>Kegiatan <?echo $_SESSION['namauser'];?></h2>
<table class="table" style="font-size:9pt;">
<tr>
<th>Program/Kegiatan</th><th>Penyediaan Dana</th><th>Pengesahan SPJ</th><th>Sisa SPD</th>
</tr>
<?
$tw=mysql_escape_string($_GET['tw']);
$q=mysql_query("select * from master where kode !='' and kprog !='' and tahun='".$_SESSION['thn']."'");
while($r=mysql_fetch_array($q)){
$qp=mysql_query("select sum(jml) as jspj from tblspj2 where idrek like'".$r['kode']."%' and tahun='".$_SESSION['thn']."'");
$rp=mysql_fetch_array($qp);
?>

<?
$q2=mysql_query("select * from master 
left join tbl_keg_bagian on master.kode=tbl_keg_bagian.koderek
where kkeg !='' and kode like'".$r['kode']."%' and kodeuser='".$_SESSION['iduser']."' and tbl_keg_bagian.tahun='".$_SESSION['thn']."' and master.tahun='".$_SESSION['thn']."'");
while($r2=mysql_fetch_array($q2)){
$qk=mysql_query("select sum(jml) as jspj from tblspj2 where idrek like'".$r2['kode']."%' and tahun='".$_SESSION['thn']."'");
$rk=mysql_fetch_array($qp);
?>
<tr>
<td><b><?echo $r2['kkeg'];?></b></td><td></td><td></td><td></td>
</tr>

<?
if($tw=='1'){$q3=mysql_query("select *,tw1 as spd from master where kode !='' and kprog='' and kkeg='' and kode like'".$r2['kode']."%' and tahun='".$_SESSION['thn']."' order by kode ASC");}
if($tw=='2'){$q3=mysql_query("select *,tw1+tw2 as spd from master where kode !='' and kprog='' and kkeg='' and kode like'".$r2['kode']."%' and tahun='".$_SESSION['thn']."' order by kode ASC");}
if($tw=='3'){$q3=mysql_query("select *,tw1+tw2+tw3 as spd from master where kode !='' and kprog='' and kkeg='' and kode like'".$r2['kode']."%' and tahun='".$_SESSION['thn']."' order by kode ASC");}
if($tw=='4'){$q3=mysql_query("select *,tw1+tw2+tw3+tw4 as spd from master where kode !='' and kprog='' and kkeg='' and kode like'".$r2['kode']."%' and tahun='".$_SESSION['thn']."' order by kode ASC");}
while($r2=mysql_fetch_array($q3)){
if($tw=='1'){$q4=mysql_query("select sum(jml) as jspj from tblspj2 where idrek like'".$r2['kode']."%' and STR_TO_DATE(tblspj2.tgl,'%d/%m/%Y') between STR_TO_DATE('01/01/".$_SESSION['thn']."','%d/%m/%Y') and STR_TO_DATE('31/03/".$_SESSION['thn']."','%d/%m/%Y')");}
if($tw=='2'){$q4=mysql_query("select sum(jml) as jspj from tblspj2 where idrek like'".$r2['kode']."%' and STR_TO_DATE(tblspj2.tgl,'%d/%m/%Y') between STR_TO_DATE('01/01/".$_SESSION['thn']."','%d/%m/%Y') and STR_TO_DATE('30/06/".$_SESSION['thn']."','%d/%m/%Y')");}
if($tw=='3'){$q4=mysql_query("select sum(jml) as jspj from tblspj2 where idrek like'".$r2['kode']."%' and STR_TO_DATE(tblspj2.tgl,'%d/%m/%Y') between STR_TO_DATE('01/01/".$_SESSION['thn']."','%d/%m/%Y') and STR_TO_DATE('30/09/".$_SESSION['thn']."','%d/%m/%Y')");}
if($tw=='4'){$q4=mysql_query("select sum(jml) as jspj from tblspj2 where idrek like'".$r2['kode']."%' and STR_TO_DATE(tblspj2.tgl,'%d/%m/%Y') between STR_TO_DATE('01/01/".$_SESSION['thn']."','%d/%m/%Y') and STR_TO_DATE('31/12/".$_SESSION['thn']."','%d/%m/%Y')");}
$r4=mysql_fetch_array($q4);
?>
<tr>
<td><?echo $r2['kode'];?>.<?echo $r2['krek1'];?><?echo $r2['krek2'];?><?echo $r2['krek3'];?><?echo $r2['krek4'];?></td><td style='text-align:right;'><?echo uang($r2['spd']);?></td>
<td style='text-align:right;'><?echo uang($r4['jspj']);?></td>
<td style='text-align:right;'><?echo uang($r2['spd']-$r4['jspj']);?></td>
</tr>
<?}}

echo mysql_error();
}?>

</table>