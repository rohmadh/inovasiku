<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #b8f4ff; 
  color: black; 
  font-weight: bold; 
  font-size: 9pt;
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
  font-size: 9pt;
}
</style>
<table class="table" id="ssh">
<thead>
<tr>
							<th>Kelompok</th><th>Sub Kelompok</th><th>Uraian</th><th>Nilai</th>
							</tr>
							</thead>
							<tbody>
<? 
echo $_GET['n'];
$stmt = $conn->prepare("SELECT sshdata.uraian_kelompok_ssh as t1,sshview1.uraian_sub_kelompok_ssh as t2,sshview1.uraian_ssh as t3,sshview1.jml_rupiah as t4 FROM sshview1 
inner join sshdata on sshview1.no_urut=sshdata.no_urut
where sshview1.uraian_sub_kelompok_ssh ='".$_GET['k']."' ORDER BY sshview1.no_urut ASC");
$exec = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
foreach ($rows as $r) {
							
							?>
							
							
							<tr>
							<td><?echo htmlspecialchars($r['t1']);?></td>
							<td><?echo htmlspecialchars($r['t2']);?></td>
							<td><?echo htmlspecialchars($r['t3']);?></td>
							<td><?echo htmlspecialchars(uang($r['t4']));?></td>
							
							</tr>
							
							<?}?>
							</tbody>
</table>
<script type="text/javascript" class="init">
	

$(document).ready(function() {
	$('#ssh').DataTable();
} );


	</script>