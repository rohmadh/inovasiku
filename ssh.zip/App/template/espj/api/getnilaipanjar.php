<?
if($_GET['k']){
$q=mysql_query("select * from tblkegiatan where id='".$_GET['k']."'");
$r=mysql_fetch_array($q);
echo htmlspecialchars($r['npanjar']);
}
?>