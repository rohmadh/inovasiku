<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>NO.SPJ</th><th>TGL.SPJ</th><th>URAIAN</th><th>JUMLAH</th><th>PROSES</th>
							</tr>
<?$n=0;$q=mysql_query("select * from tblspj2 where idkeg='".$_GET['idkeg']."' order by tgl ASC");
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><div id="t<?echo $r['id'];?>"><?echo htmlspecialchars($r['nospj']);?></div></td>
							<td><div id="t<?echo $r['id'];?>"><?echo htmlspecialchars($r['tgl']);?></div></td>
							<td><div id="t<?echo $r['id'];?>"><?echo htmlspecialchars($r['uraian']);?></div></td>
							<td><div id="t<?echo $r['id'];?>"><?echo htmlspecialchars(uang($r['jml']));?></div></td>
							<td><input type="button" value="EDIT" onclick="editspj('<?echo $r['id'];?>')">
							<input type="button" value="HAPUS" onclick="hapus(<?echo $r['id'];?>)">
							</td>
							</tr>
							
							<?}?>
</table>
<script>
function editspj(k) {
		$("#mode").val('edit');
        $.ajax({url: 'App/api.php?m=load.spj&id='+k, success: function(result){
            $("#loader").html(result);
        }});
    }
</script>
<script>
function hapus(k) {
        $.ajax({url: 'App/api.php?m=spj.input&mode=del&id='+k, success: function(result){
            alert('DATA TERHAPUS...');
			refreshtabel();
        }});
    }
</script>