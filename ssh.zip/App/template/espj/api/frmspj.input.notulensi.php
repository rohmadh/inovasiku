<??>
<script src="https://cdn.ckeditor.com/ckeditor5/16.0.0/classic/ckeditor.js"></script>
<center>
<input type="button" value="SIMPAN NOTULENSI" onclick="savenotulensi();">
<input type="submit" value="CETAK NOTULENSI"  id="btnnew" onclick="cetaknotulensi();">
</center>
<br />
<textarea id="notulensieditor">...notulensi...</textarea>
<div id="loading"></div>
<script>
$("#loading").html('...LOADING DATA...');
var a = $("#ida").val();
$.ajax({url: 'App/api.php?m=espj.load.notulensi&a='+a, success: function(result){
			$("#notulensieditor").html(result);
			startedit();
			$("#loading").html('');
			
        }});

</script>

<script>
function startedit(){
    ClassicEditor
        .create( document.querySelector( '#notulensieditor' ) )
		.then(notulensieditor => {
			theEditor = notulensieditor;

		  })
        .catch( error => {
            console.error( error );
        } );
}
function savenotulensi(){
	var a = $("#ida").val();
	var b = theEditor.getData();
	$.ajax({url: 'App/api.php?m=espj.input.notulensi',type:'post',
		data:{a:a,b:b},
		success: function(result){
            alert('data tersimpan');
			
			
        }});
}
function cetaknotulensi(){
	var a = $("#ida").val();
	window.open("./?action=print&page=espj.notulensi.print&a="+a, "_blank");
}
</script>

