<?
if(strlen($_GET["q"])<5){exit();}
?>
<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td { 
  font-family:verdana;
  font-size: 11px; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>Kode</th><th>Uraian</th>
							</tr>
<?$no=1;
$jmlangg=0;
$q=mysql_query("select * from kodebelanja where (kodebelanja like'%".$_GET['q']."%' or uraian like'%".$_GET['q']."%' )  order by kodebelanja ASC");
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><txt onclick="pilihbelanja('<?echo htmlspecialchars($r['kodebelanja']);?>','<?echo htmlspecialchars($r['uraian']);?>');" style="cursor:pointer;">
							<?echo htmlspecialchars($r['kodebelanja']);?></txt></td>
							<td>
							
							<?echo htmlspecialchars($r['uraian']);?>
							</td>
							
							</tr>
							
							<?$no=$no+1;$jmlangg=$jmlangg+$r['total'];}?>
</table>
<?echo mysql_error();?>
<script>
function pilihbelanja(k,t) {

$("#krekbelanja").val(k);
$("#targetkodebelanja").html(t);

}
</script>
