<?
if($_GET['mode']=='save'){
mysql_query("insert into program (txtprogram,tahun) value ('".$_GET['namaprog']."','".$_SESSION['thn']."')");
}
if($_GET['mode']=='draft'){
mysql_query("update program set status='0' where id='".$_GET['idprog']."'");
}
if($_GET['mode']=='edit'){
mysql_query("update program set txtprogram='".$_GET['namaprog']."' where id='".$_GET['idprog']."'");
}
?>