<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td { 
  font-family:verdana;
  font-size: 11px; 
}
.table td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<table class="table">
<tr>
							<th>Kode</th><th>Uraian</th><th>Jumlah</th><th>PILIH</th>
							</tr>
<?$no=1;
$jmlangg=0;
$q=mysql_query("select * from anggarankas where tahun='".$_SESSION['thn']."' and kode like'".$_GET['q']."%' and length(kode)='30' order by kode ASC");
							while($r=mysql_fetch_array($q)){
							?>
							
							
							<tr>
							<td><?echo htmlspecialchars($r['kode']);?></td>
							<td>
							
							<?echo htmlspecialchars($r['uraian']);?>
							</td>
							<td><?echo htmlspecialchars(uang($r['total']));?></td><td><input type="button" value="SPJ" onclick="pilihprog('<?echo $no;?>','<?echo $r['kode'];?>');"></td>
							</tr>
							
							<?$no=$no+1;$jmlangg=$jmlangg+$r['total'];}?>
</table>
<center><label style="font-size:14pt;">TOTAL= Rp. <?echo uang($jmlangg);?></label></center>
<script>
function pilihprog(n,k) {
var txt = $("#t"+n+"").text();
$("#namaprog").val(txt);
$("#idprog").val(k);
$("#targetlistprog").html('');

}
</script>
