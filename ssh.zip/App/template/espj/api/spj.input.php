<?
if($_GET['mode']=='save'){
mysql_query("insert into tblspj2 (idkeg,idrek,idpanjar,nospj,tgl,tipespj,jml,jbayar,pajak,jpajak,pajak2,jpajak2,pajak3,jpajak3,uraian,user,tahun) value ('".$_GET['idkeg']."','".$_GET['idrek']."','".$_GET['idpanjar']."','".$_GET['nospj']."','".$_GET['tgl']."','".$_GET['jenis']."','".$_GET['jml']."','".$_GET['jbayar']."','".$_GET['pajak']."','".$_GET['jpajak']."','".$_GET['pajak2']."','".$_GET['jpajak2']."','".$_GET['pajak3']."','".$_GET['jpajak3']."',
'".$_GET['ket']."','".$_SESSION['iduser']."','".$_SESSION['thn']."')");
}
if($_GET['mode']=='del'){
mysql_query("delete from tblspj2 where id='".$_GET['id']."'");
}
?>