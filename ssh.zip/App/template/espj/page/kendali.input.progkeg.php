<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>PROGRAM</h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row" id="frmprog">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							<input type="hidden" id="idprog" value="">
							</td>
							<td><label>NAMA PROGRAM </label></td><td><label>:</label></td><td>
							<input name="nama" id="namaprog" class="form-control" type="text" size="100">
							
							<br />
							<div id="targetlistprog"></div>
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>PROSES</label></td><td><label>:</label></td><td>
							
							<select id='mode'>
							<option value='save'>SIMPAN</option>
							<option value='edit'>EDIT</option>
							<option value='del'>HAPUS</option>
							<option value='draft'>Draft</option>
							</select>
							
							</td>
							<td></td>
							</tr>
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN" id="btninputpanjar" onclick="inputprogkeg();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			
<?
$q=mysql_query("select * from kelompok order by nama");

?>
<div class="table-responsive" id="idtarget">                              
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
		$("#idtarget").html('<h1>...LOADING...</h1>');
        $.ajax({url: 'App/api.php?m=prog.tabel&mode=list', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function getlkeg() {
		$("#targetlistkeg").html('<h1>...LOADING...</h1>');
		var k=$("#qk").val();
        $.ajax({url: 'App/api.php?m=listkeg&q='+k, success: function(result){
            $("#targetlistkeg").html(result);
        }});
    }
</script>
<script>
function inputprogkeg() {
		var mode=$("#mode").val();
		var namaprog=$("#namaprog").val();
		var idprog=$("#idprog").val();
        $.ajax({url: 'App/api.php?m=prog.input&mode='+mode+'&idprog='+idprog+'&namaprog='+namaprog, success: function(result){
            alert('DATA TERSIMPAN...');
			refreshtabel();
        }});
    }
</script>
<script>$("#frmprog").hide();refreshtabel();<?if($_SESSION['iduser']==0){?>$("#frmprog").show();<?}?></script>
