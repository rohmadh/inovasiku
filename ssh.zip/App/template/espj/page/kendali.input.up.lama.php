 
<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>TRANSAKSI KEUANGAN</h2>



                    </div>
                </div>

                <hr />
				
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            PENERIMAAN
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>KODE AKUN</label></td><td><label>:</label></td><td><input name="nama" id="nama" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>KETERANGAN</label></td><td><label>:</label></td><td><input name="nama" id="nama" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>JUMLAH (Rp)</label></td><td><label>:</label></td><td><input name="nama" id="nama" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td><input type="submit" value="SIMPAN"  id="btnsave"></td>
							</tr>
							</table>
                            
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			
	<div id="targetresp"></div>			

<div class="table-responsive" id="targettbl">
                                
</div>


<script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
		$("#targettbl").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=keu.debet.tabel', success: function(result){
            $("#targettbl").html(result);
        }});
    }
</script>
<script>
refreshtabel();
</script>
