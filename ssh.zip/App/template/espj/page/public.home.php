<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>

<div class="row">
                    <div class="col-lg-12">



				<hr />
				
                    </div>
				
                </div>
<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="SAVE">
							</td>
							<td><label>NAMA KELOMPOK ASB</label></td><td><label>:</label></td><td>
							<select id='subssh' class="form-control2">
							<option value=''>--PILIH--</option>
							<?php
								$stmt = $conn->prepare("SELECT * FROM sshview4 ");
								$exec = $stmt->execute();
								$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
								foreach ($rows as $r) {
							?>
							<option value='<?php echo $r['uraian_sub_kelompok_ssh']?>'><?php echo $r['uraian_sub_kelompok_ssh']?></option>
								<?php }?>
							</select>
							<input type="submit" value="CARI" name="btnexec" id="btnexec" onclick='loaddata();'>
							</td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			

<div class="table-responsive" id="idtarget">
<h1>...LOADING DATA.....</h1>
                                
</div>

<script src="<?echo $base;?>/assets/plugins/dataTables/jquery.dataTables.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">

    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
     
<script>
function loadgbr() {
        $.ajax({url: 'App/api.php?m=homegbr', success: function(result){
            $("#idtarget").html(result);
        }});
    }
function loaddata() {
		var sub=$("#subssh").val();
		$("#idtarget").html('<center><h2>...LOADING DATA ...</h2></center>');
        $.ajax({url: 'App/api.php?m=essh.table&k='+sub, success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
loadgbr();

</script>
