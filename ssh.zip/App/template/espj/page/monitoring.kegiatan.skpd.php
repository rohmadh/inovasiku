<?
$qs=mysql_query("select * from skpd where id='".$data['id']."'");
$rs=mysql_fetch_array($qs);
?>
<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<div class="row">
                    <div class="col-lg-12">


                        <h2>DAFTAR KEGIATAN SKPD Tahun <?echo $_SESSION['thn'];?><br /><font color="green"><?echo $rs['namaskpd'];?>[<?echo $data['id'];?>]</font></h2>

				
                    </div>
				
                </div>

                <hr />

<div class="table-responsive" id="idtarget">
<h1>LOADING DATA.....</h1>
                                
</div>

<script src="<?echo $base;?>/assets/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
     <script>
         $(document).ready(function () {
             $('#dataTables-example').dataTable();
         });
    </script>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/skpd.kegiatan.tabel.php?mode=monitor&id=<?echo $data['id'];?>', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>

<script>refreshtabel();</script>