<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

<?
#echo $data['id'];
$q=mysql_query("select * from aktivitas where id='".$data['id']."'");
$r=mysql_fetch_array($q);

?>

<div class="row">
                    <div class="col-lg-12">


                        <h2>INPUT ASB BELANJA AKTIVITAS <br>
						<?echo $r['aktivitas'];?>
						</h2>



                    </div>
                </div>

                <hr />
				<?if($_SESSION['leveluser']=='0'){?>
				<label>CARI SSH:</label><input type="text" name="q" id="q"><input type="button" value="CARI" onclick="carissh();">
				<div id="targetssh">
				</div><br />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<form id="formasb" name="formasb" action="App/api/asb.belanja.php" method="post">
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td><label>SSH</label></td><td><label>:</label></td><td><label id="txtssh"></label></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="SAVE">
							<input type="hidden" id="idssh" name="idssh" value="<?echo $data['idssh'];?>">
							<input type="hidden" id="idaktivitas" name="idaktivitas" value="<?echo $data['id'];?>">
							</td>
							<td><label>Volume SSH </label></td><td><label>:</label></td><td><input name="vol" id="vol"  type="text" size="6">
							<label id="txtsat"></label>
							</td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td valign="top"><label>Variabel Pengali</label></td><td><label>:</label></td><td>
							<input type="text" name="ivarasb" id="ivarasb">
							PIlihan Variabel=><?$va=explode(",",$r['vdriver']);foreach($va as $a){?>
							<input type="button" id="" value="<?echo $a;?>">
							
							<?}?>
							<br />&nbsp; *)diisi pengali dengan dipisahkan koma (,)untuk pengali lebih dari satu.misal Orang,Hari
							</td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            </form>
							<table>
							<tr>
							<td></td><td></td><td>
							<input type="submit" value="SIMPAN" name="btnexec" id="btnexec">
							</td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?}?>
	<div id="message"></div>			

<div class="table-responsive" id="idtarget">
                                
</div>



    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/asb.belanja.tabel.php?k=<?echo $data['id'];?>', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function carissh() {
		var val=$("#q").val();
        $.ajax({url: 'App/api/ssh.cari.tabel.php?k='+val, success: function(result){
            $("#targetssh").html(result);
        }});
    }
</script>
<script>
function delssh(val) {
        $.ajax({url: 'App/api/asb.belanja.php?mode=delete&id='+val, success: function(result){
            alert('data sukses dihapus');
			refreshtabel();
        }});
    }
</script>
<script>
refreshtabel();
</script>
<script src="<?echo $base;?>/libs/asb.aktivitas.js"></script>
