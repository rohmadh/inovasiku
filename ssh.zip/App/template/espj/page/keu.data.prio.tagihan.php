<link rel="stylesheet" href="<?echo $base;?>/assets/css/jquery-ui.css">
  <script src="<?echo $base;?>/assets/js/jquery-ui.min.js"></script>
  <script>
  $( function() {
    $( "#ta" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
	$( "#tb" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
  } );
  </script>
<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 0px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<?
$q="
SELECT column_name FROM information_schema.columns WHERE table_schema = 'akademiksekolah' AND table_name = 'keu_mastertagihan' and 
(column_name not like'b%'and column_name not like'id'
and column_name not like'nama'
and column_name not like'kelas'
and column_name not like'va1'
and column_name not like'va2'
and column_name not like'thn'
)
";
$stmt = $conn->prepare($q);
$stmt->execute();

?>
<div class="row">
                    <div class="col-lg-12">

						<center>
                        <h2 align='center'>PRIORITAS TAGIHAN MURID Tahun <?echo date('Y');?></h2>
						<hr />
							
						</center>
                    </div>
                </div>
<div id='tampil' align='center'>
		
</div>

<script>
function load1() {
		var nis=$("#nis").val();
		$("#tampil").html('<h1>...LOADING DATA...</h1>');
        $.ajax({url: 'App/api.php?m=tagihan.prio.tabel&nis='+nis, success: function(result){
            $("#tampil").html(result);
        }});
    }
</script>
<script>
function loadp() {
		var ta=$("#ta").val();
		var tb=$("#tb").val();
		window.open("./?action=print&page=bku&ta="+ta+"&tb="+tb, "_blank");
    }
load1();
</script>
