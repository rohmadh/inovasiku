<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/jquery-ui.min.js">
</script>
<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<div class="row">
                    <div class="col-lg-12">


                        <h2><font color="green">SIKEU <?echo $_SESSION['thn'];?></font></h2>

				<hr />
				
                    </div>
				
                </div>


<div class="table-responsive" id="idtarget">
<h1>...LOADING DATA.....</h1>
                                
</div>

<script src="<?echo $base;?>/assets/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
     <script>
         $(document).ready(function () {
             $('#dataTables-example').dataTable();
         });
    </script>
<script>
function loadgbr() {
        $.ajax({url: 'App/api.php?m=homegbr', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>loadgbr();</script>
