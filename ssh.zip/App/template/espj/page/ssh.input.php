<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>INPUT KELOMPOK ASB</h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<form id="formasb" name="formasb" action="App/api/asb.kelompok.php" method="post">
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="SAVE">
							</td>
							<td><label>NAMA KELOMPOK ASB</label></td><td><label>:</label></td><td><input name="nama" id="nama" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            </form>
							<table>
							<tr>
							<td></td><td></td><td><input type="submit" value="SIMPAN" name="btnexec" id="btnexec"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			
<?
$q=mysql_query("select * from kelompok order by nama");

?>
<div class="table-responsive" id="idtarget">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Nama Kelompok</th>
											<th>Rincian Aktivitas</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<div id="idtarget">
									<?while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            <td><? echo $r['id'];?></td>
                                            <td><? echo $r['nama'];?></td>
                                            <td><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=asb.aktivitas&id=".$r['id']."",$key2));?>">[view]</a></td>
                                        </tr>
									<?}?>
									</div>
									</tbody>
								</table>
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/asb.kelompok.tabel.php', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script src="<?echo $base;?>/libs/asb.kelompok.js"></script>
