<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>SET KEGIATAN BAGIAN</h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row" id="frmprog">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							<input type="hidden" id="iddata" value="">
							</td>
							<td><label>NAMA KEGIATAN </label></td><td><label>:</label></td><td>
							<?
							$qp=mysql_query("select * from master where kkeg!='' and tahun='".$_SESSION['thn']."' order by kkeg ASC");
							?>
							
							<select id="kodekeg">
							<?while($rp=mysql_fetch_array($qp)){?>
							<option value="<?echo $rp['kode'];?>"><?echo $rp['kkeg'];?>-[<?echo $rp['kode'];?>]</option> 
							<?}?>
							</select>
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>NAMA BAGIAN </label></td><td><label>:</label></td><td>
							<?
							$qb=mysql_query("select * from pengguna ");
							?>
							
							<select id="kodebag" onchange="refreshtabel();"> 
							<?while($rb=mysql_fetch_array($qb)){?>
							<option value="<?echo $rb['id'];?>"><?echo $rb['nama'];?></option> 
							<?}?>
							</select>
							<i>(daftar menyesuaikan BAGIAN yg dipilih)</i>
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>PROSES</label></td><td><label>:</label></td><td>
							
							<select id='mode'>
							<option value='save'>SIMPAN</option>
							<option value='edit'>EDIT</option>
							<option value='del'>HAPUS</option>
							
							</select>
							
							</td>
							<td></td>
							</tr>
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN" id="btninputpanjar" onclick="inputbagiankeg();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			
<?
$q=mysql_query("select * from kelompok order by nama");

?>
<div class="table-responsive" id="idtarget">                              
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
		$("#idtarget").html('<h1>...LOADING...</h1>');
		var k=$("#kodebag").val();
        $.ajax({url: 'App/api.php?m=skpd.prog.tabel&mode=list&kuser='+k, success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>

<script>
function inputbagiankeg() {
		var mode=$("#mode").val();
		var kkeg=$("#kodekeg").val();
		var kbag=$("#kodebag").val();
		var iddata=$("#iddata").val();
        $.ajax({url: 'App/api.php?m=bagian.keg.input&mode='+mode+'&kodekeg='+kkeg+'&kodebag='+kbag+'&iddata='+iddata, success: function(result){
            alert('DATA TERSIMPAN...');
			refreshtabel();
        }});
    }
</script>
<script>$("#frmprog").hide();refreshtabel();<?if($_SESSION['iduser']==0){?>$("#frmprog").show();<?}?></script>
