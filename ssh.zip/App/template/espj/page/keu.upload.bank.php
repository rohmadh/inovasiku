<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>UPLOAD FILE BANKs</h2>



                    </div>
                </div>

                <hr />
				
							<?php
include("App/config/db.php.inc");
$conn = mysqli_connect($serv, $user, "", $db);
$prioritas=array("spp","kbm","bukupaket");
if (isset($_POST["import"])) {
	mysqli_query($conn,"truncate table master_import");
    
    $fileName = $_FILES["file"]["tmp_name"];
    
    if ($_FILES["file"]["size"] > 0) {
        
        $file = fopen($fileName, "r");
        ##### proses sequencing pembayaran bertingkat
        while (($column = fgetcsv($file, 10000, ";")) !== FALSE) {
            $sqlInsert = "INSERT into keu_trxbank (pdate,efdate,branch,reffno,trxcode,desc1,desc2,debet,kredit,vanumber,vaname,tahun)
                   values ('" . $column[1] . "','" . $column[2] . "','" . $column[3] . "','" . $column[4] . "','" . $column[5] . "',
				   '" . $column[6] . "','" . $column[7] . "','" . $column[8] . "','" . $column[9] . "','" . $column[10] . "','" . $column[11] . "',
				   '" . $_SESSION['thn'] . "'
				   )";
            $result = mysqli_query($conn, $sqlInsert);
			
            if (! empty($result)) {
				##### insert history
				$sqlhist="insert into keu_rincian_potong_trxbank (va,pdate,ket,jml) value ('".$column[10]."','".$column[1]."','TRF BANK--','".$column[9]."')";
				$resulthist = mysqli_query($conn, $sqlhist);
				##### proses sequencing pembayaran bertingkat
				$a=0;
				$jmlpemb=0;
				$sisauang=$column[9];
				$flag=0;
				while($a<count($prioritas)){
				echo "sisa-".$sisauang;
				#### ambil nilai tagihan
				$sqltagih="select ".$prioritas[$a]." from keu_mastertagihan where va1='".$column[10]."' and year(thn)='" . $_SESSION['thn'] . "'";
				echo $sqltagih;
				$resultt = mysqli_query($conn, $sqltagih);
				$tagih=mysqli_fetch_array($resultt);
				echo $tagih[0];
				### update bayar
				if(($sisauang>=$tagih['0'])and($flag==0)){
				$sqlbayar="update keu_mastertagihan set b".$prioritas[$a]."='".$tagih['0']."' where va1='".$column[10]."' and year(thn)='" . $_SESSION['thn'] . "'";
				echo $sqlbayar;
				$resultb = mysqli_query($conn, $sqlbayar);
				#####isi rincian potong
				$sqlrincian="insert into keu_rincian_potong_trxbank (va,pdate,ket,jml) value ('".$column[10]."','".$column[1]."','bayar-".$prioritas[$a]."','".$tagih['0']."')";
				$resultr = mysqli_query($conn, $sqlrincian);
				#$sisauang=$sisauang-$tagih['0'];
				}
				if(($sisauang<$tagih['0'])and($flag==0)){
				$flag=1;
				####isikan bayar sisanya semua
				$sql1="update keu_mastertagihan set b".$prioritas[$a]."='".$sisauang."' where va1='".$column[10]."' and year(thn)='" . $_SESSION['thn'] . "'";
				$resultr = mysqli_query($conn, $sql1);
				$sql2="insert into keu_rincian_potong_trxbank (va,pdate,ket,jml) value ('".$column[10]."','".$column[1]."','bayar-".$prioritas[$a]."','".$sisauang."')";
				$resultr = mysqli_query($conn, $sql2);
				$sqlrincian="insert into keu_rincian_potong_trxbank (va,pdate,ket,jml) value ('".$column[10]."','".$column[1]."','SALDO SISA KURANG-STOP','0')";
				$resultr = mysqli_query($conn, $sqlrincian);
				}
				$a=$a+1;$sisauang=$sisauang-$tagih['0'];
				}
                $type = "success";
                $message = "CSV Data Imported into the Database";
            } else {
                $type = "error";
                $message = "Problem in Importing CSV Data";
            }
        }
    }
}
?>

<script type="text/javascript">
$(document).ready(function() {
    $("#frmCSVImport").on("submit", function () {

	    $("#response").attr("class", "");
        $("#response").html("");
        var fileType = ".csv";
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + fileType + ")$");
        if (!regex.test($("#file").val().toLowerCase())) {
        	    $("#response").addClass("error");
        	    $("#response").addClass("display-block");
            $("#response").html("Invalid File. Upload : <b>" + fileType + "</b> Files.");
            return false;
        }
        return true;
    });
});
</script>

    <h3>Import CSV TRANSAKSI BANK DANAMON</h3>
    
    <div id="response" class="<?php if(!empty($type)) { echo $type . " display-block"; } ?>"><?php if(!empty($message)) { echo $message; } ?></div>
    <div class="outer-scontainer">
        <div class="row">

            <form class="form-horizontal" action="" method="post"
                name="frmCSVImport" id="frmCSVImport" enctype="multipart/form-data">
                <div class="input-row">
                    <label class="col-md-4 control-label">PIlih CSV
                        File(yang sudah disesuaikan)</label> <input type="file" name="file"
                        id="file" accept=".csv">
                    <button type="submit" id="submit" name="import"
                        class="btn-submit">Import</button> 
                    <br />
					
					<center>
					<i>Browse piih file,Klik Import, kemudian cek, setelah OK klik SIMPAN KE DATABASE. data lama akan diganti dg yg baru dg tahun yg sama</i><br />
					<input type="button" id="copydata" value="SIMPAN KE DATABASE" onclick="simpandata();">
					</center>
                </div>

            </form>

        </div>
		<div id="hasil">
		
		<hr>
		<b>Cek Data</b>
               <?php
            $sqlSelect = "SELECT * FROM keu_trxbank where tahun='".$_SESSION['thn']."'";
            $result = mysqli_query($conn, $sqlSelect);
            
            if (mysqli_num_rows($result) > 0) {
                ?>
            <table id='userTable' border='1' style="font-size:8pt;">
            <thead>
                <tr>
                    <th>postdate</th>
                    <th>effdate</th>
                    <th>branch</th>
                    <th>reffno</th>
					<th>trxcode</th>
					<th>desc1</th>
					<th>desc2</th>
					<th>debet</th>
					<th>kredit</th>
					<th>VAno</th>
					<th>VAname</th>
					<th>Tahun</th>
                </tr>
            </thead>
<?php
                
                while ($row = mysqli_fetch_array($result)) {
                    ?>
                    
                <tbody>
				
                <tr>
                    <td><?php  echo $row['pdate']; ?></td>
                    <td><?php  echo $row['efdate']; ?></td>
                    <td><?php  echo $row['branch']; ?></td>
                    <td><?php  echo $row['reffno']; ?></td>
					<td><?php  echo $row['trxcode']; ?></td>
					<td><?php  echo $row['desc1']; ?></td>
					<td><?php  echo $row['desc2']; ?></td>
					<td><?php  echo $row['debet']; ?></td>
					<td><?php  echo $row['kredit']; ?></td>
					<td><?php  echo $row['vanumber']; ?></td>
					<td><?php  echo $row['vaname']; ?></td>
					<td><?php  echo $row['tahun']; ?></td>
                </tr>
				
                    <?php
                }
                ?>
                </tbody>
        </table>
        <?php } ?>
		</div>
    </div>
	
	<script>
	alert("DATA DARI SIMDA TAHUN <?echo $_SESSION['thn'];?> , <?echo mysqli_num_rows($result)?> Kegiatan.");
	</script>
    <script>
	function simpandata() {
			$("#hasil").html('<h1>...MENGCOPY DATA KE DATABASE...</h1>');
			$.ajax({url: 'App/api.php?m=kendali.copy.simda&mode=copy', success: function(result){
				$("#hasil").html('<h1>...PROSES SELESAI...</h1>'); 
			}});
		}
	</script>            
<?
$sqltagih="select kode from keu_prioritas_tagihan order by no ASC";
$result = mysqli_query($conn, $sqltagih);
$row=mysqli_fetch_array($result);
echo $row[12];
#while($row=mysqli_fetch_array($result)){
#echo $row['kode'];}
?>	
                         
