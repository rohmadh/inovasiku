<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

<?
$q=mysql_query("select * from kelompok where id='".$data['id']."'");
$r=mysql_fetch_array($q);

?>

<div class="row">
                    <div class="col-lg-12">


                        <h2>INPUT ASB AKTIVITAS <br>
						<?echo $r['nama'];?>
						</h2>



                    </div>
                </div>

                <hr />
				<?if($_SESSION['leveluser']=='0'){?>
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<form id="formasb" name="formasb" action="App/api/asb.aktivitas.php" method="post">
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="SAVE">
							<input type="hidden" name="idkelompok" value="<?echo $data['id'];?>">
							</td>
							<td><label>NAMA AKTIVITAS </label></td><td><label>:</label></td><td><input name="nama" id="nama" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td></td>
							<td><label>Variabel Driver </label></td><td><label>:</label></td><td><input name="vardriver" id="vardriver" type="text" size="20"> *) Variabel Driver dipisahkan oleh koma(,) misal: Orang,Hari</td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            </form>
							<table>
							<tr>
							<td></td><td></td><td>
							<input type="submit" value="SIMPAN" name="btnexec" id="btnexec">
							</td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?}?>
	<div id="message"></div>			
<?
$q=mysql_query("select *,aktivitas.id as idd from aktivitas
left join kelompok on aktivitas.idkelompok=kelompok.id
where idkelompok='".$data['id']."'");

?>
<div class="table-responsive" id="idtarget">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Nama Aktivitas</th>
											<th>Spesifikasi</th>
											<th>Variabel</th>
											<th>NIlai HSPK</th>
											<?if($_SESSION['leveluser']=='0'){?>
											<th>Rincian ASB</th>
											<th>Hapus ASB</th>
											<?}?>
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            <td><? echo $r['idd'];?></td>
                                            <td><? echo $r['aktivitas'];?></td>
											<td><? echo $r['spesifikasi'];?></td>
											<td><? echo $r['vdriver'];?></td>
											<td align="right"><? echo uang($r['hspk']);?></td>
											<?if($_SESSION['leveluser']=='0'){?>
                                            <td><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=asb.aktivitas.belanja&id=".$r['idd']."",$key2));?>">[view]</a></td>
											<td><input type="button" value="X" onclick="hapusaktvasb(<? echo $r['idd'];?>);"></td>
											<?}?>
                                        </tr>
									<?}?>
									
									</tbody>
								</table>
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/asb.aktivitas.tabel.php?k=<?echo $data['id'];?>', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function hapusaktvasb(id) {
		var r = confirm("Anda ingin mengapus data?");
		if (r==true){
        $.ajax({url: 'App/api/asb.aktivitas.php?mode=del&k='+id, success: function(result){
            refreshtabel();
        }});}
    }
</script>
<script src="<?echo $base;?>/libs/asb.aktivitas.js"></script>
