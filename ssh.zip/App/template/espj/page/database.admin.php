<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<div class="row">
                    <div class="col-lg-12">


                        <h2>DATABASE ADMIN <?echo $_SESSION['thn'];?><br /><font color="green"><?echo $_SESSION['skpduser'];?>[<?echo $_SESSION['idskpduser'];?>]</font></h2>


				<table cellpadding='5' cellspacing='5'>
				<tr>
				<th>PERSIAPKAN DATABASE untuk tahun</th><th><input type="text" id="thndata" size='6'><input type="button" value="PROSES" onclick='createdatabase()'></th>
				</tr>
				</table>
                    </div>
				
                </div>

                <hr />

<div class="table-responsive" id="idtarget">
<h1>LOADING DATA.....</h1>
                                
</div>

<script src="<?echo $base;?>/assets/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
     <script>
         $(document).ready(function () {
             $('#dataTables-example').dataTable();
         });
    </script>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/database.tabel.php', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function createdatabase() {
		var thn=$("#thndata").val();
		var k=parseInt(thn)-1;
        $.ajax({url: 'App/api/database.admin.php?mode=create&thn='+k, success: function(result){
            refreshtabel();
			alert("DATA SUDAH SIAP..");
        }});
    }
</script>
<script>refreshtabel();</script>