<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<div class="row">
                    <div class="col-lg-12">


                        <h2>DAFTAR KEGIATAN SKPD Tahun <?echo $_SESSION['thn'];?></h2>


				<table cellpadding='5' cellspacing='5'>
				<tr>
				<th>Nama Kegiatan</th><th><input type="text" id="namakeg" size='50'><input type="button" value="SIMPAN" onclick='saveskpdkegiatan()'></th>
				</tr>
				</table>
                    </div>
				
                </div>

                <hr />

<div class="table-responsive" id="idtarget">
<h1>LOADING DATA.....</h1>
                                
</div>

<script src="<?echo $base;?>/assets/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
     <script>
         $(document).ready(function () {
             $('#dataTables-example').dataTable();
         });
    </script>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/skpdall.kegiatan.tabel.php', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function saveskpdkegiatan() {
		var keg=$("#namakeg").val();
        $.ajax({url: 'App/api/skpd.kegiatan.php?mode=save&keg='+keg, success: function(result){
            refreshtabel();
        }});
    }
</script>
<script>refreshtabel();</script>