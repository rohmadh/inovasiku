<?
$stmt = $conn->prepare("SELECT * FROM pejabat ");
$exec = $stmt->execute();
$r = $stmt->fetch();
$conn = null;
?>
<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>SETTING PEJABAT</h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>Nama Lengkap</label></td><td><label>:</label></td><td>
							<input name="nama" id="nama" class="form-control" type="text" size="100" value='<?echo htmlspecialchars($r['npenggunaangg']);?>'>
							
							<br />
						
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>NIP </label></td><td><label>:</label></td><td>
							<input name="nama" id="nip" class="form-control" type="text" size="100" value='<?echo htmlspecialchars($r['nippa']);?>'>
							
							<br />
						
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>Jabatan </label></td><td><label>:</label></td><td>
							<input name="nama" id="jab" class="form-control" type="text" size="100" value='<?echo htmlspecialchars($r['nbendahara']);?>'>
							
							<br />
						
							</td>
							<td></td>
							</tr>
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td>
							<input type="hidden" value="" id="mode">
							<input type="hidden" value="" id="idd">
							<input type="button" value="BARU" id="btnnew" onclick="baru();">
							<input type="button" value="SIMPAN" id="btninputdok" onclick="inputdok();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>
	<div id="targetresp"></div>

<div class="table-responsive" >
 <div class="panel panel-default">
                        <div class="panel-heading">
                            DATA
                        </div>
                        <div class="panel-body">
                            <div class="row" id="targettblpejabat">
</div></div>							
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>

<script>
function inputdok() {
		var mode=$("#mode").val();
		var nama=$("#nama").val();
		var nip=$("#nip").val();
		var jab=$("#jab").val();
		var idd=$("#idd").val();
        $.ajax({url: 'App/api.php?m=espj.input.pejabat',type:'post',data:{mode:mode,idd:idd,nama:nama,nip:nip,jab:jab},success: function(result){
            alert('DATA TERSIMPAN...');
			refreshdata();
        }});
    }
function hapus(k) {
		var mode='hapus';
		var idd=k;
        $.ajax({url: 'App/api.php?m=espj.input.pejabat',type:'post',data:{mode:mode,idd:idd},success: function(result){
            alert('DATA TERSIMPAN...');
			refreshdata();
        }});
    }
function refreshdata() {
		$("#targettblpejabat").html('...LOADING DATA...');
        $.ajax({url: 'App/api.php?m=espj.pejabat.tabel', success: function(result){
            $("#targettblpejabat").html(result);
        }});
    }
function baru() {
		$("#mode").val('save');
		$("#nama").val('');
		$("#nip").val('');
		$("#jab").val('');
		$("#nama").focus();
        alert('...OK...');
    }
refreshdata();
</script>
