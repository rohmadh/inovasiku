<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<div class="row">
                    <div class="col-lg-12">
<?
$q=mysql_query("select * from skpd_kegiatan where id='".$data['id']."'");
$r=mysql_fetch_array($q);
?>

                        <h2>KEGIATAN <?echo $r['kegiatan'];?></h2>
						<h3>Total Anggaran:<label id="t"> Rp. 0,00</label></h3>


                    </div>
                </div>

                <hr />
				<div id="forminputaktv">
				<table cellpadding='5' cellspacing='5'>
				<tr>
				<th>Nama Aktivitas</th><th><input type="text" id="namaaktv" size='50'></th>
				</tr>
				<tr>
				<th>ASB Aktivitas Dipilih</th><th><input type="hidden" id="asbaktv" size='50' disabled>
				<input type="text" id="nasb" size='100' disabled>
				</th>
				</tr>
				<tr>
				<th>Variabel Pelaksanaan</th><th><input type="text" id="varasb" size='30'>&nbsp;Isikan nilai dg format data <text id='txtvar'></text></th>
				</tr>
				<tr>
				<th></th><th>Kata Kunci ASB:<input type="text" id="s" size='30'><input type="button" value="CARI ASB" onclick='cariasb()'>
				<input type="button" value="CLEAR" onclick="awal();">
				<br /> Contoh: Pelatihan,Sosialisasi,Rapat dll,
				</th>
				</tr>
				<tr>
				<th></th><th><input type="button" value="SIMPAN" onclick='saveskpdaktivitas();'></th>
				</tr>
				</table>
				</div>
				<br />
				<div class="table-responsive" id="tabelasb">
				</div>
				
				<div id="formedit">
				<h3>EDIT DATA</h3>
				<table cellpadding='5' cellspacing='5'>
				<tr>
				<td><label>Nama Aktivitas</label></td><td>: <input type="text" id="namaaktvold" size="100"></td>
				</tr>
				<tr>
				<td><label>Variabel Pengali</label></td><td>: <input type="text" id="pengaliold">-->ISI Format Pengali [ <label id="txtpengali"></label> ]
				<input type="hidden" id="idaktvold">
				</td>
				</tr>
				<tr>
				<td></td><td><input type="button" id="btneditok" value="SIMPAN" onclick="updateskpdaktivitas();"></td>
				</tr>
				</table>
				</div>

<div class="table-responsive" id="idtarget">
  <h1>LOADING DATA.....</h1>                              
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
     <script>
         $(document).ready(function () {
             $('#dataTables-example').dataTable();
         });
    </script>
<script>
function saveskpdaktivitas() {
		var namaaktv=$("#namaaktv").val();
		var idasb=$("#asbaktv").val();
		var nvar=$("#varasb").val();
        $.ajax({url: 'App/api/skpd.aktivitas.php?mode=save&idkeg='+<?echo $data['id'];?>+'&nama='+namaaktv+'&idasb='+idasb+'&nvar='+nvar, success: function(result){
            refreshtabel();
        }});
    }
</script>
<?if($_SESSION['leveluser']=='0'){?>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/skpd.aktivitas.tabel.php?id=<?echo $data['id'];?>', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<?}else{?>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/skpd.aktivitashide.tabel.php?id=<?echo $data['id'];?>', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<?}?>
<script>
function cariasb() {
		var s=$("#s").val();
		$("#tabelasb").show();
        $.ajax({url: 'App/api/asb.tabel.php?s='+s, success: function(result){
            $("#tabelasb").html(result);
        }});
    }
</script>
<script>
function awal(val) {
        $("#asbaktv").val('');
		$("#nasb").val('');
		$("#txtvar").html('');
		$("#s").val('');
		$("#s").focus();
		$("#tabelasb").hide();
		}
</script>
<script>
function formeditshow(k){
var idktv=$("#i"+k+"").text();
var naktv=$("#n"+k+"").text();
var paktv=$("#p"+k+"").text();
var tpaktv=$("#txtp"+k+"").text();
$("#forminputaktv").hide();
$("#formedit").show();
$("#namaaktvold").focus();
$("#idaktvold").val(idktv);
$("#namaaktvold").val(naktv);
$("#pengaliold").val(paktv);
$("#txtpengali").text(tpaktv);
}
</script>
<script>
function updateskpdaktivitas() {
		var namaaktv=$("#namaaktvold").val();
		var idaktv=$("#idaktvold").val();
		var nvar=$("#pengaliold").val();
        $.ajax({url: 'App/api/skpd.aktivitas.php?mode=update&idaktv='+idaktv+'&nama='+namaaktv+'&nvar='+nvar, success: function(result){
            refreshtabel();
			$("#formedit").hide();
			$("#forminputaktv").show();
			alert("DATA SUKSES DIEDIT...");
        }});
    }
</script>
<script>
refreshtabel();
$("#formedit").hide();
$("#namaaktv").focus();
</script>