 
<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>TRANSAKSI KEUANGAN <?echo txthtml($_SESSION['thn']);?></h2>



                    </div>
                </div>

                <hr />
				
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            PENGELUARAN
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>DARI</label></td><td><label>:</label></td><td><input type="text" id="dari" size="40" disabled>&nbsp;<label>Kata Kunci:</label><input type="text" id="q"><input type="button" value="CARI" onclick="carimurid();"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>ID</label></td><td><label>:</label></td><td><input type="text" id="idklien" size="10" disabled></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td></td><td></td><td><div id='klien'></div></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" id="mode" value="save">
							<input type="hidden" id="idd" value="">
							</td>
							<td><label>KODE AKUN</label></td><td><label>:</label></td><td><div id='kodeakun'></div></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>URAIAN</label></td><td><label>:</label></td><td><input name="nama" id="ket" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>JUMLAH (Rp)</label></td><td><label>:</label></td><td><input name="nama" id="jml" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td><input type="submit" value="SIMPAN"  id="btnsave" onclick="simpan();"><input type="submit" value="CLEAR"  id="btnnew" onclick="frmtransaksireset();"></td>
							</tr>
							</table>
                            
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			
	<div id="targetresp"></div>			

<div class="table-responsive" id="targettbl">
                                
</div>


<script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
		$("#targettbl").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=keu.kredit.tabel', success: function(result){
            $("#targettbl").html(result);
        }});
    }
</script>
<script>
function getkodeakun() {
		$("#kodeakun").html("<b>Loading data....</b>");
        $.ajax({url: 'App/api.php?m=keu.option.kode.akun.k', success: function(result){
            $("#kodeakun").html(result);
        }});
    }
</script>
<script>
function carimurid() {
		var q = $("#q").val();
		$("#klien").html("<b>Loading data....</b>");
        $.ajax({url: 'App/api.php?m=keu.list.murid&q='+q, success: function(result){
            $("#klien").html(result);
        }});
    }
</script>
<script>
function simpan() {
		var kode = $("#akun").val();
		var ket = $("#ket").val();
		var jml = $("#jml").val();
		var klien = $("#idklien").val();
		var id = $("#idd").val();
		var mode = $("#mode").val();
        $.ajax({url: 'App/api.php?m=keu.input.kredit&mode='+mode+'&id='+id+'&klien='+klien+'&kode='+kode+'&ket='+ket+'&jml='+jml, success: function(result){
            $("#targetresp").html(result);
			frmtransaksireset();
			refreshtabel();
        }});
    }
</script>
<script>
function frmtransaksireset() {
		$("#mode").val('save');
		$("#akun").val('0000');
		$("#ket").val('');
		$("#jml").val('');
		$("#idklien").val('');
		$("#dari").val('');
		$("#idd").val('');
    }
</script>
<script>
getkodeakun();refreshtabel();
</script>
