<link rel="stylesheet" href="<?echo $base;?>/assets/css/jquery-ui.css">
  <script src="<?echo $base;?>/assets/js/jquery-ui.min.js"></script>
  <script>
  $( function() {
    $( "#ta" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
	$( "#tb" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
  } );
  </script>
<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 0px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<div class="row">
                    <div class="col-lg-12">

						<center>
                        <h2 align='center'>Rekap Penerimaan tiap murid</h2>

						<label>Pilih Periode:
						
						<input name="ta" id="ta" type="text" size="10">
						<input name="tb" id="tb" type="text" size="10">
						</label>
						<input type='button' value='REKAP' onclick='load1();'>
						<input type='button' value='PRINT' onclick='loadp();'>
						</center>
                    </div>
                </div>
<div id='tampil' align='center'>				
</div>

<script>
function load1() {
		var ta=$("#ta").val();
		var tb=$("#tb").val();
		$("#tampil").html('<h1>...LOADING LAPORAN...</h1>');
        $.ajax({url: 'App/api.php?m=laporan.debet.murid.tabel&ta='+ta+'&tb='+tb, success: function(result){
            $("#tampil").html(result);
        }});
    }
</script>
<script>
function loadp() {
		var ta=$("#ta").val();
		var tb=$("#tb").val();
		window.open("./?action=print&page=bku&ta="+ta+"&tb="+tb, "_blank");
    }
</script>
