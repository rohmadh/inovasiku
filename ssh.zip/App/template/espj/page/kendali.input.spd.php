<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>INPUT PENYEDIAAN DANA (SPD)</h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            PROGRAM KEGIATAN
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" id="mode" value="save">
							<input type="hidden" id="idprog" value="">
							<input type="hidden" id="idkeg" value="">
							<input type="hidden" id="idrek" value="">
							</td>
							<td><label>NAMA PROGRAM </label></td><td><label>:</label></td><td><input name="nama" id="namaprog" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistprog"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qp" ><input type="button" value="CARI" onclick='getlprog();'></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>NAMA KEGIATAN</label></td><td><label>:</label></td><td><input name="nama" id="namakeg" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistkeg"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qk" ><input type="button" value="CARI" onclick='getlkeg();'></td>
							</tr>
							
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
				
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            INPUT SPD
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>REKENING BELANJA</label></td><td><label>:</label></td><td><input name="nama" id="rekbelanja" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistrekbelanja"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qr" ><input type="button" value="CARI" onclick='getlrek();'></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>TRIWULAN I </label></td><td><label>:</label></td><td><input name="nama" id="tw1" type="text" size="20" onblur='copyspd();'>
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>TRIWULAN II  </label></td><td><label>:</label></td><td><input name="nama" id="tw2" type="text" size="20">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>TRIWULAN III </label></td><td><label>:</label></td><td><input name="nama" id="tw3" type="text" size="20">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>TRIWULAN IV </label></td><td><label>:</label></td><td><input name="nama" id="tw4" type="text" size="20">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN" id="btninputpanjar" onclick="inputspd();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			

<div class="table-responsive" id="idtarget">
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api.php?m=spd.tabel', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function getlprog() {
		$("#targetlistprog").html('<h1>...LOADING...</h1>');
		var k=$("#qp").val();
        $.ajax({url: 'App/api.php?m=listprogall&q='+k, success: function(result){
            $("#targetlistprog").html(result);
        }});
    }
</script>
<script>
function getlkeg() {
		$("#targetlistkeg").html('<h1>...LOADING...</h1>');
		var k=$("#qk").val();
		var kp=$("#idprog").val();
        $.ajax({url: 'App/api.php?m=listkeg&idprog='+kp+'&q='+k, success: function(result){
            $("#targetlistkeg").html(result);
        }});
    }
</script>
<script>
function getlrek() {
		$("#targetlistrekbelanja").html('<h1>...LOADING...</h1>');
		var k=$("#qr").val();
        $.ajax({url: 'App/api.php?m=list.rekbelanja&q='+k, success: function(result){
            $("#targetlistrekbelanja").html(result);
        }});
    }
</script>
<script>
function copyspd() {
		var k=$("#tw1").val();
		$("#tw2").val(k);
		$("#tw3").val(k);
		$("#tw4").val(k);
    }
</script>
<script>
function inputspd() {
		var mode=$("#mode").val();
		var idkeg=$("#idkeg").val();
		var idrek=$("#idrek").val();
		var tw1=$("#tw1").val();
		var tw2=$("#tw2").val();
		var tw3=$("#tw3").val();
		var tw4=$("#tw4").val();
		var npanjar=$("#jmlpanjar").val();
        $.ajax({url: 'App/api.php?m=spd.input&mode='+mode+'&idkeg='+idkeg+'&idrek='+idrek+'&tw1='+tw1+'&tw2='+tw2+'&tw3='+tw3+'&tw4='+tw4, success: function(result){
            alert('DATA TERSIMPAN...');
			refreshtabel();
        }});
    }
</script>
<script>refreshtabel();</script>

