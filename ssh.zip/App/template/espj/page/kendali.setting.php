<?
$q=mysql_query("select * from setting where user='".$_SESSION['iduser']."'");
$r=mysql_fetch_array($q);
?>
<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>SETTING NAMA</h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>Nama Pengguna Anggaran /<br />Kuasa Pengguna Anggaran</label></td><td><label>:</label></td><td>
							<input name="nama" id="namapa" class="form-control" type="text" size="100" value='<?echo htmlspecialchars($r['npenggunaangg']);?>'>
							
							<br />
						
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>NIP </label></td><td><label>:</label></td><td>
							<input name="nama" id="nippa" class="form-control" type="text" size="100" value='<?echo htmlspecialchars($r['nippa']);?>'>
							
							<br />
						
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>Nama Bendahara </label></td><td><label>:</label></td><td>
							<input name="nama" id="namabend" class="form-control" type="text" size="100" value='<?echo htmlspecialchars($r['nbendahara']);?>'>
							
							<br />
						
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>NIP </label></td><td><label>:</label></td><td>
							<input name="nama" id="nipbend" class="form-control" type="text" size="100" value='<?echo htmlspecialchars($r['nipbend']);?>'>
							
							<br />
						
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN" id="btninputdok" onclick="inputdok();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			

<div class="table-responsive" id="idtarget">                              
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>

<script>
function inputdok() {
		
		var namab=$("#namabend").val();
		var nipb=$("#nipbend").val();
		var namapa=$("#namapa").val();
		var nippa=$("#nippa").val();
        $.ajax({url: 'App/api.php?m=dok.input&mode=save&namab='+namab+'&nipb='+nipb+'&nippa='+nippa+'&namapa='+namapa, success: function(result){
            alert('DATA TERSIMPAN...');
			refreshtabel();
        }});
    }
</script>
