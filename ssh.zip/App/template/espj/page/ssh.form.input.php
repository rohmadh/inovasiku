<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>INPUT STANDAR SATUAN HARGA</h2>



                    </div>
                </div>

                <hr />
				<div class="row" id=forminput>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<form id="formasb" name="formasb" action="App/api/ssh.input.php" method="post">
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="SAVE">
							</td>
							<td><label>NAMA BARANG</label></td><td><label>:</label></td><td><input name="nama" id="nama" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="SAVE">
							</td>
							<td><label>SATUAN</label></td><td><label>:</label></td><td><input name="satuan" id="satuan"  type="text" size="10"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="SAVE">
							</td>
							<td><label>HARGA</label></td><td><label>:</label></td><td><input name="harga" id="harga"  type="text" size="10"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            </form>
							<table>
							<tr>
							<td></td><td></td><td><input type="submit" value="SIMPAN" name="btnexec" id="btnexec"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			
			<div class="row" id="formedit">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form EDIT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="SAVE">
							</td>
							<td><label>NAMA BARANG</label></td><td><label>:</label></td><td><input name="nama" id="enama" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="SAVE">
							</td>
							<td><label>SATUAN</label></td><td><label>:</label></td><td><input name="satuan" id="esatuan"  type="text" size="10"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="update">
							<input type="hidden" name="essh" id="essh" value="">
							</td>
							<td><label>HARGA</label></td><td><label>:</label></td><td><input name="harga" id="eharga"  type="text" size="10"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN DATA" onclick="saveedit();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			
			<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            PENCARIAN SSH
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table>
							<tr>
							<td><label>KATA KUNCI</label></td><td>:<input type="text" id="txtcari"></td><td><input type="button" value="CARI" id="btncari" onclick="carissh();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			
<?
$q=mysql_query("select * from satuanharga".$_SESSION['thn']." order by id DESC limit 0,10 ");

?>
<div class="table-responsive" id="idtarget">
                                
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
		$("#idtarget").html('<h2>..LOADING DATA...</h2>');
        $.ajax({url: 'App/api/ssh.tabel.php', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function carissh() {
		var k=$("#txtcari").val();
        $.ajax({url: 'App/api/ssh.cari.edit.tabel.php?k='+k, success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function showedit(k) {
		var enama=$("#n"+k+"").text();
		var eharga=$("#h"+k+"").text();
		var esatuan=$("#s"+k+"").text();
	
        $("#forminput").hide();
		$("#formedit").show();
		$("#essh").val(k);
		$("#enama").val(enama);
		$("#eharga").val(eharga);
		$("#esatuan").val(esatuan);	
			
    }
</script>

<script>
function saveedit() {
		var k=$("#essh").val();
		var n=$("#enama").val();
		var h=$("#eharga").val();
		var s=$("#esatuan").val();
		
        $.ajax({url: 'App/api/ssh.input.php?mode=update&k='+k+'&n='+n+'&s='+s+'&h='+h, success: function(result){
            refreshtabel();
			$("#formedit").hide();
			$("#forminput").show();
			alert('DATA SUKSES DISIMPAN');
			
        }});
    }
</script>
<script>
$("#formedit").hide();
 refreshtabel();
</script>
<script src="<?echo $base;?>/libs/ssh.input.js"></script>
