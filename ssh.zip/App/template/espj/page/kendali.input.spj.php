<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
  <link rel="stylesheet" href="<?echo $base;?>/assets/css/jquery-ui.css">
  <script src="<?echo $base;?>/assets/js/jquery-ui.min.js"></script>
  <script>
  $( function() {
    $( "#tgl" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
  } );
  </script>
<div class="row">
                    <div class="col-lg-12">


                        <h2>INPUT SPJ KEGIATAN </h2>



                    </div>
                </div>

                <hr />
				
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            PROGRAM/KEGIATAN
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" id="mode" value="save">
							<input type="hidden" id="idprog" value="">
							<input type="hidden" id="idkeg" value="">
							<input type="hidden" id="idrek" value="">
							<input type="hidden" id="idpanjar" value="">
							</td>
							<td><label>NAMA PROGRAM </label></td><td><label>:</label></td><td><input name="nama" id="namaprog" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistprog"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qp" ><input type="button" value="CARI" onclick='getlprog();'></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>NAMA KEGIATAN</label></td><td><label>:</label></td><td><input name="nama" id="namakeg" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistkeg"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qk" ><input type="button" value="CARI" onclick='getlkeg();'></td>
							</tr>
							
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            DATA PANJAR
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<div id='tabelpanjar'></div>
							
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
				
				<div class="row" id='formspj'>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT SPJ
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>TRANSAKSI  </label></td><td><label>:</label></td><td>
							<select id='jspj'>
							<option value='0'>...PILIH...</option>
							<option value='1'>BELANJA</option>
							<option value='2'>PENGEMBALIAN PANJAR</option>
							
							</select>
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>REKENING BELANJA</label></td><td><label>:</label></td><td><input name="nama" id="rekbelanja" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistrekbelanja"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qr" ><input type="button" value="CARI" onclick='getlrek();'></td>
							</tr>
							
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>TANGGAL </label></td><td><label>:</label></td><td><input name="tgl" id="tgl" type="text" size="20">
							<label>NO. SPJ </label> <input name="tgl" id="nospj" type="text" size="35">
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>JENIS SPJ  </label></td><td><label>:</label></td><td>
							<select id='jspj'>
							<option value='0'>...PILIH...</option>
							<option value='1'>GU</option>
							<option value='2'>TU</option>
							<option value='3'>LS</option>
							</select>
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>KETERANGAN </label></td><td><label>:</label></td><td><input name="nama" id="ket" type="text" size="80">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>NILAI RUPIAH </label></td><td><label>:</label></td><td>Rp.<input name="nama" id="jml" type="text" size="30">
							Pembayaran:
							<select id='jbayar'>
							<option value='0'>...PILIH...</option>
							<option value='tunai'>TUNAI</option>
							<option value='bank'>BANK</option>
							
							</select>
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>PAJAK </label></td><td><label>:</label></td><td>
							<select id='jpajak'>
							<option value='0'>...PILIH...</option>
							<?$q=mysql_query("select * from jenispajak");while($r=mysql_fetch_array($q)){?>
							<option value='<?echo $r['id'];?>'><?echo $r['txtpajak'];?></option>
							<?}?>
							
							</select>
							Rp.<input name="nama" id="pajak" type="text" size="30">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td>
							</td><td></td><td><input type="button" value="SIMPAN" id="btninputpanjar" onclick="inputspj();setawal();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			
<input type='button' onclick='refreshtabel();' value='RELOAD TABEL'>
<div class="table-responsive" id="idtarget">
</div>
<div id='loader'></div>

    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
		var k=$("#idkeg").val();
        $.ajax({url: 'App/api.php?m=spj.tabel&idkeg='+k, success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>

<script>
function getlrek() {
		$("#targetlistrekbelanja").html('<h1>...LOADING...</h1>');
		var k=$("#qr").val();
		var idkeg=$("#idkeg").val();
        $.ajax({url: 'App/api.php?m=list.rekbelanja.spj&mode=getspd&idkeg='+idkeg+'&q='+k, success: function(result){
            $("#targetlistrekbelanja").html(result);
        }});
    }
</script>
<script>
function getlprog() {
		$("#targetlistprog").html('<h1>...LOADING...</h1>');
		var k=$("#qp").val();
        $.ajax({url: 'App/api.php?m=listprogall&q='+k, success: function(result){
            $("#targetlistprog").html(result);
        }});
    }
</script>
<script>
function getlkeg() {
		$("#targetlistkeg").html('<h1>...LOADING...</h1>');
		var k=$("#qk").val();
		var kp=$("#idprog").val();
        $.ajax({url: 'App/api.php?m=listkeg&idprog='+kp+'&q='+k, success: function(result){
            $("#targetlistkeg").html(result);
        }});
    }
</script>
<script>
function getnilaipanjar() {
		$("#npanjar").val('...LOADING...');
		var k=$("#idkeg").val();
        $.ajax({url: 'App/api.php?m=getnilaipanjar&k='+k, success: function(result){
            $("#npanjar").val(result);
        }});
    }
</script>
<script>
function getnilaispd() {
		$("#nspd").val('...LOADING...');
		var k=$("#idkeg").val();
		var rek=$("#idrek").val();
        $.ajax({url: 'App/api.php?m=getnilaispd&k='+k+'&rek='+rek, success: function(result){
            $("#nspd").val(result);
        }});
    }
</script>
<script>
function inputspj() {
		var mode=$("#mode").val();
		var idkeg=$("#idkeg").val();
		var idrek=$("#idrek").val();
		var tgl=$("#tgl").val();
		var nospj=$("#nospj").val();
		var jenis=$("#jspj").val();
		var ket=$("#ket").val();
		var jml=$("#jml").val();
		var jbayar=$("#jbayar").val();
		var idpanjar=$("#idpanjar").val();
		var pajak=$("#pajak").val();
		var jpajak=$("#jpajak").val();
        $.ajax({url: 'App/api.php?m=spj.input&mode='+mode+'&idkeg='+idkeg+'&idrek='+idrek+'&idpanjar='+idpanjar+'&tgl='+tgl+'&nospj='+nospj+'&jenis='+jenis+'&ket='+ket+'&jml='+jml+'&jbayar='+jbayar+'&pajak='+pajak+'&jpajak='+jpajak, success: function(result){
            alert('DATA TERSIMPAN...');
			refreshtabel();
			getdatapanjar();
        }});
    }
function setawal() {
$("#jspj").val(0);
$("#ket").val('');
$("#jml").val('');
$("#pajak").val('');
}
</script>
<script>
function getdatapanjar() {
		var k=$("#idkeg").val();
		$("#tabelpanjar").html('...LOADING...');
        $.ajax({url: 'App/api.php?m=panjar.tabel2&mode=list&id='+k, success: function(result){
            $("#tabelpanjar").html(result);
        }});
    }
</script>

<script>refreshtabel();$("#formspj").hide();</script>
<?
if(isset($_SESSION['setprog'])){
?>
<script>$("#idprog").val('<?echo $_SESSION['setprog'];?>');$("#namaprog").val('<?echo $_SESSION['txtprog'];?>');</script>
<?}
?>
<?
if(isset($_SESSION['setkeg'])){
?>
<script>$("#idkeg").val('<?echo $_SESSION['setkeg'];?>');$("#namakeg").val('<?echo $_SESSION['txtkeg'];?>');
getdatapanjar();
refreshtabel();
</script>
<?}
?>

