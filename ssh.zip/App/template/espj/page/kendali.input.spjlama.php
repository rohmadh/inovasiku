<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
  <link rel="stylesheet" href="<?echo $base;?>/assets/css/jquery-ui.css">
  <script src="<?echo $base;?>/assets/js/jquery-ui.min.js"></script>
  <script>
  $( function() {
    $( "#tgl" ).datepicker({dateFormat: "dd/mm/yy"});
  } );
  </script>
<div class="row">
                    <div class="col-lg-12">


                        <h2>INPUT REALISASI</h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" id="mode" value="save">
							<input type="hidden" id="idprog" value="">
							<input type="hidden" id="idkeg" value="">
							<input type="hidden" id="idrek" value="">
							</td>
							<td><label>NAMA PROGRAM </label></td><td><label>:</label></td><td><input name="nama" id="namaprog" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistprog"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qp" ><input type="button" value="CARI" onclick='getlprog();'></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>NAMA KEGIATAN</label></td><td><label>:</label></td><td><input name="nama" id="namakeg" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistkeg"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qk" ><input type="button" value="CARI" onclick='getlkeg();'></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>REKENING BELANJA</label></td><td><label>:</label></td><td><input name="nama" id="rekbelanja" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistrekbelanja"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qr" ><input type="button" value="CARI" onclick='getlrek();'></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>NILAI PANJAR </label></td><td><label>:</label></td><td><input name="nama" class="form-control" id="npanjar" type="text" size="20" disabled>
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>NILAI SPD </label></td><td><label>:</label></td><td><input name="nama" class="form-control" id="nspd" type="text" size="20" disabled>
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>TANGGAL </label></td><td><label>:</label></td><td><input name="tgl" id="tgl" type="text" size="20">
							<label>NO. SPJ </label> <input name="tgl" id="nospj" type="text" size="35">
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>JENIS SPJ  </label></td><td><label>:</label></td><td>
							<select id='jspj'>
							<option value='0'>...PILIH...</option>
							<option value='1'>GV</option>
							<option value='2'>TU</option>
							<option value='3'>LS</option>
							</select>
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>KETERANGAN </label></td><td><label>:</label></td><td><input name="nama" id="ket" type="text" size="80">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>NILAI RUPIAH </label></td><td><label>:</label></td><td><input name="nama" id="jml" type="text" size="30">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>NILAI PAJAK </label></td><td><label>:</label></td><td><input name="nama" id="pajak" type="text" size="30">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN" id="btninputpanjar" onclick="inputspj();setawal();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			

<div class="table-responsive" id="idtarget">
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api.php?m=spj.tabel', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function getlkeg() {
		$("#targetlistkeg").html('<h1>...LOADING...</h1>');
		var k=$("#qk").val();
        $.ajax({url: 'App/api.php?m=listkegall&mode=panjar&q='+k, success: function(result){
            $("#targetlistkeg").html(result);
        }});
    }
</script>
<script>
function getlrek() {
		$("#targetlistrekbelanja").html('<h1>...LOADING...</h1>');
		var k=$("#qk").val();
        $.ajax({url: 'App/api.php?m=list.rekbelanja&mode=getspd&q='+k, success: function(result){
            $("#targetlistrekbelanja").html(result);
        }});
    }
</script>
<script>
function getlprog() {
		$("#targetlistprog").html('<h1>...LOADING...</h1>');
		var k=$("#qk").val();
        $.ajax({url: 'App/api.php?m=listprogall&q='+k, success: function(result){
            $("#targetlistprog").html(result);
        }});
    }
</script>
<script>
function getnilaipanjar() {
		$("#npanjar").val('...LOADING...');
		var k=$("#idkeg").val();
        $.ajax({url: 'App/api.php?m=getnilaipanjar&k='+k, success: function(result){
            $("#npanjar").val(result);
        }});
    }
</script>
<script>
function getnilaispd() {
		$("#nspd").val('...LOADING...');
		var k=$("#idkeg").val();
		var rek=$("#idrek").val();
        $.ajax({url: 'App/api.php?m=getnilaispd&k='+k+'&rek='+rek, success: function(result){
            $("#nspd").val(result);
        }});
    }
</script>
<script>
function inputspj() {
		var mode=$("#mode").val();
		var idkeg=$("#idkeg").val();
		var idrek=$("#idrek").val();
		var tgl=$("#tgl").val();
		var nospj=$("#nospj").val();
		var jenis=$("#jspj").val();
		var ket=$("#ket").val();
		var jml=$("#jml").val();
		var pajak=$("#pajak").val();
        $.ajax({url: 'App/api.php?m=spj.input&mode='+mode+'&idkeg='+idkeg+'&idrek='+idrek+'&tgl='+tgl+'&nospj='+nospj+'&jenis='+jenis+'&ket='+ket+'&jml='+jml+'&pajak='+pajak, success: function(result){
            alert('DATA TERSIMPAN...');
			refreshtabel();
        }});
    }
function setawal() {
$("#jspj").val(0);
$("#ket").val('');
$("#jml").val('');
$("#pajak").val('');
}
</script>

<script>refreshtabel();</script>

