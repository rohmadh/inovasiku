<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>INPUT KELOMPOK ASB</h2>



                    </div>
                </div>

                <hr />
				<?if($_SESSION['leveluser']=='0'){?>
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<form id="formasb" name="formasb" action="App/api/asb.kelompok.php" method="post">
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" name="mode" value="SAVE">
							</td>
							<td><label>NAMA KELOMPOK ASB</label></td><td><label>:</label></td><td><input name="nama" id="nama" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            </form>
							<table>
							<tr>
							<td></td><td></td><td><input type="submit" value="SIMPAN" name="btnexec" id="btnexec"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			<div class="row" id="frmedit">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            EDIT KELOMPOK ASB
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<input name="nama" id="enama" class="form-control" type="text">
                             <input type="button" value="SIMPAN" onclick="editkelompokasb();"> 
							<input type="hidden" id="eid">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			<?}?>
	<div id="message"></div>			
<?
$q=mysql_query("select * from kelompok order by nama ASC");

?>
<div class="table-responsive" id="idtarget">
                                
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
		$("#idtarget").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api/asb.kelompok.tabel.php', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function deletekelompokasb(k) {
        $.ajax({url: 'App/api/asb.kelompok.php?mode=delete&k='+k, success: function(result){
            alert("DATA SUKSES DIHAPUS..");
			refreshtabel();
        }});
    }
</script>
<script>
function enablekelompokasb(k) {
	var x=$("#t"+k+"").text();
     $("#frmedit").show();
	 $("#enama").val(x);
	 $("#eid").val(k);
	 $("#frmedit").focus();
    }
</script>
<script>
function editkelompokasb() {
		var k=$("#eid").val();
		var nm=$("#enama").val();
        $.ajax({url: 'App/api/asb.kelompok.php?mode=edit&k='+k+'&nama='+nm, success: function(result){
            alert("DATA SUKSES DIUBAH..");
			refreshtabel();
			$("#eid").val("");
			$("#enama").val("");
			$("#frmedit").hide();
        }});
    }
</script>
<script>$("#frmedit").hide();refreshtabel();</script>

<script src="<?echo $base;?>/libs/asb.kelompok.js"></script>
