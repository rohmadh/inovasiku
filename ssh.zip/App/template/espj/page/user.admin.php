<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>USER SKPD</h2>



                    </div>
                </div>

                <hr />
				<div class="row" id=forminput>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT USER
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>NAMA LENGKAP</label></td><td><label>:</label></td><td><input name="nama" id="nama" class="form-control" type="text" size="100"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>SKPD</label></td><td><label>:</label></td><td>
							<select id="iskpd" class="form-control">
							<?
							$q=mysql_query("select * from skpd order by namaskpd ASC");
							while($r=mysql_fetch_array($q)){
							?>
							<option value="<?echo $r['id'];?>"><?echo $r['namaskpd'];?></option>
							<?}?>
							</select>
							</td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>USERNAME (<i>tanpa spasi, bisa memakai NIP</i>)</label></td><td><label>:</label></td><td><input name="nama" id="nip" class="form-control" type="text" size="50"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" id="mode" value="save">
							<input type="hidden" id="idd" value="">
							<input type="hidden" id="ide" value="">
							</td>
							<td><label>PASSWORD (<i>minimal 5 karakter, tanpa spasi</i>)</label></td><td><label>:</label></td><td><input name="harga" id="password" class="form-control" type="text" size="30"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN" name="btnexec" id="btnsave" onclick="saveuser();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			
			
			<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            PENCARIAN USER
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table>
							<tr>
							<td><label>KATA KUNCI</label></td><td>:<input type="text" id="txtcari"></td><td><input type="button" value="CARI" id="btncari" onclick="cariuser();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			
<?


?>
<div class="table-responsive" id="idtarget">
                                
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/user.tabel.php', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function cariuser() {
		var k=$("#txtcari").val();
        $.ajax({url: 'App/api/user.tabel.php?mode=cari&k='+k, success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function showedit(k) {
		var enip=$("#nip"+k+"").text();
		var enama=$("#nama"+k+"").text();
		var eskpd=$("#skpd"+k+"").text();
		var idd=k;
       
		$("#nip").val(enip);
		$("#idd").val(enip);
		$("#ide").val(k);
		$("#nama").val(enama);
		$("#iskpd").val(eskpd);
		$("#mode").val('update');
			
    }
</script>
<script>
function kosongform() {
		$("#nip").val('');
		$("#idd").val('');
		$("#ide").val('');
		$("#nama").val('');
		$("#iskpd").val('');
		$("#mode").val('save');
		$("#password").val('');
}
</script>
<script>
function saveuser() {
		var nip=$("#nip").val();
		var enip=$("#idd").val();
		var ide=$("#ide").val();
		var nama=$("#nama").val();
		var skpd=$("#iskpd").val();
		var psw=$("#password").val();
		var mode=$("#mode").val();
        $.ajax({url: 'App/api/user.input.php?mode='+mode+'&ide='+ide+'&nip='+nip+'&enip='+enip+'&nama='+nama+'&skpd='+skpd+'&psw='+psw, success: function(result){
            refreshtabel();
			
			alert('DATA SUKSES DISIMPAN');
			kosongform();
        }});
    }
</script>
<script>
$("#formedit").hide();
refreshtabel(); 
</script>
