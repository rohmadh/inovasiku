<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<script src="<?echo $base;?>/assets/js/jquery-ui.min.js"></script>
<link rel="stylesheet" href="<?echo $base;?>/assets/css/jquery-ui.css">
<script>
  $( function() {
    $( "#tgl" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
  } );
  </script>

<div class="row">
                    <div class="col-lg-12">


                        <h2>INPUT NILAI PANJAR</h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" id="mode" value="save">
							<input type="hidden" id="idprog" value="">
							<input type="hidden" id="idkeg" value="">
							<input type="hidden" id="idpanjar" value="">
							</td>
							<td><label>NAMA PROGRAM </label></td><td><label>:</label></td><td><input name="nama" id="namaprog" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistprog"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qp" onfocus='setawal();'><input type="button" value="CARI" onclick='getlprog();'></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>NAMA KEGIATAN</label></td><td><label>:</label></td><td><input name="nama" id="namakeg" class="form-control" type="text" size="100" disabled>
							<br />
							<div id="targetlistkeg"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qk" onfocus='setawal();'><input type="button" value="CARI" onclick='getlkeg();'></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>TANGGAL PANJAR </label></td><td><label>:</label></td><td><input name="nama" id="tgl" type="text" size="20">
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>JUMLAH PANJAR </label></td><td><label>:</label></td><td><input name="nama" id="jmlpanjar" type="text" size="20" onfocus='refreshtabel();'>
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>Keterangan </label></td><td><label>:</label></td><td><textarea id='ket' cols='80%'></textarea>
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN" id="btninputpanjar" onclick="inputpanjar();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>			
<?
$q=mysql_query("select * from kelompok order by nama");

?>
<input type="button" value="REFRESH" id="btninputpanjar" onclick="refreshtabel();">
<div class="table-responsive" id="idtarget">                              
</div>



    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
		var k=$("#idkeg").val();
		$("#idtarget").html('...LOADING...');
        $.ajax({url: 'App/api.php?m=panjar.tabel&mode=list&id='+k, success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function getlprog() {
		$("#targetlistprog").html('<h1>...LOADING...</h1>');
		var k=$("#qp").val();
        $.ajax({url: 'App/api.php?m=listprogall&q='+k, success: function(result){
            $("#targetlistprog").html(result);
        }});
    }
</script>
<script>
function getlkeg() {
		$("#targetlistkeg").html('<h1>...LOADING...</h1>');
		var k=$("#qk").val();
		var kp=$("#idprog").val();
        $.ajax({url: 'App/api.php?m=listkeg&idprog='+kp+'&q='+k, success: function(result){
            $("#targetlistkeg").html(result);
        }});
    }
</script>
<script>
function inputpanjar() {
		var mode=$("#mode").val();
		var idkeg=$("#idkeg").val();
		var idpanjar=$("#idpanjar").val();
		var npanjar=$("#jmlpanjar").val();
		var tgl=$("#tgl").val();
		var ket=$("#ket").val();
        $.ajax({url: 'App/api.php?m=panjar.input&mode='+mode+'&idkeg='+idkeg+'&idpanjar='+idpanjar+'&npanjar='+npanjar+'&tgl='+tgl+'&ket='+ket, success: function(result){
            alert('DATA TERSIMPAN...');
			refreshtabel();
        }});
    }
</script>
<script>
function setawal() {
$("#targetlistprog").html('');
$("#targetlistkeg").html('');
}
</script>
<script>refreshtabel();</script>
<div id="loader">                              
</div>