<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<?
$qu=mysql_query("select * from pengguna where nip='".$_SESSION['nipuser']."'");
$ru=mysql_fetch_array($qu);
?>

<div class="row">
                    <div class="col-lg-12">


                        <h2>USER SKPD</h2>



                    </div>
                </div>

                <hr />
				<div class="row" id=forminput>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form EDIT USER
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>NAMA PEMAKAI</label></td><td><label>:</label></td><td><input name="nama" id="nama" class="form-control" type="text" size="100" value="<? echo $ru['nama'];?>"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>SKPD</label></td><td><label>:</label></td><td>
							<select id="iskpd" class="form-control" disabled>
							<?
							$q=mysql_query("select * from skpd order by namaskpd ASC");
							while($r=mysql_fetch_array($q)){
							?>
							<option value="<?echo $r['id'];?>" <?if($r['id']==$_SESSION['idskpduser']){echo "selected";}?>><?echo $r['namaskpd'];?></option>
							<?}?>
							</select>
							</td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>USERNAME (<i>tanpa spasi, bisa memakai NIP</i>)</label></td><td><label>:</label></td><td><input name="nama" id="nip" class="form-control" type="text" size="50" value="<? echo $ru['nip'];?>"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" id="mode" value="update">
							<input type="hidden" id="ide" value="<?echo $_SESSION['iduser'];?>">
							<input type="hidden" id="idd" value="<?echo $_SESSION['nipuser'];?>">
							</td>
							<td><label>PASSWORD (<i>tanpa spasi,minimal 5 karakter</i>)</label></td><td><label>:</label></td><td><input name="harga" id="password" class="form-control" type="text" size="30"></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN" name="btnexec" id="btnsave" onclick="saveuser();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			
			
	<div id="message"></div>			
<?


?>
<div class="table-responsive" id="idtarget">
                                
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>


<script>
function saveuser() {
		var ide=$("#ide").val();
		var nip=$("#nip").val();
		var enip=$("#idd").val();
		var nama=$("#nama").val();
		var skpd=$("#iskpd").val();
		var psw=$("#password").val();
		var mode=$("#mode").val();
		$("#message").html('<h2>..PROSES DATA...</h2>');
        $.ajax({url: 'App/api/user.input.php?mode='+mode+'&ide='+ide+'&nip='+nip+'&enip='+enip+'&nama='+nama+'&skpd='+skpd+'&psw='+psw, success: function(result){
            $("#message").html('<h2>...MOHON LOGOUT TERLEBIH DAHULU...</h2>');
			alert('DATA SUKSES DISIMPAN');
			
        }});
    }
</script>

