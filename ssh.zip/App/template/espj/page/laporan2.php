<?
if($_SESSION['iduser']>0){
$lap='laporan2.tabel.bagian';$lapprint='lap.serapan.bagian';
}else{$lap='laporan2.tabel';$lapprint='lap.serapan';}
?>
<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
  border-spacing: 0px;
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
  font-size:9pt;
}
.table td, th { 
  spacing:0;
  padding: 0px; 
  border: 1px solid #ccc; 
  text-align: right; 
  font-size:9pt;
}

</style>
<div class="row">
                    <div class="col-lg-12">

						<center>
                        <h2 align='center'>KENDALI KEGIATAN</h2>

						<label>Sampai dengan Bulan<select id='bln'>
						<?
						for ($i = 1; $i <= 12; $i++) {?>
						<option value='<? echo $i;?>' <?if($i==intval(date('m'))){echo "selected";}?>><?echo $i;?></option>
						<?}
						?>
						
						</select></label>
						<label>Tahun<select id='thn'>
						
						<?
						$io=intval($_SESSION['thn']);
						for ($i = ($io-10); $i <= $io; $i++) {?>
						<option value='<? echo $i;?>' <?if($i==$_SESSION['thn']){echo "selected";}?>><?echo $i;?></option>
						<?}
						?>
						
						</select></label>
						<input type='button' value='REKAP' onclick='load1();'>
						<input type='button' value='PRINT' onclick='loadp();'>
						</center>
                    </div>
                </div>
<div id='tampil' align='center'>				
</div>
<script>
function hitung1() {
		$("#tampil").html('...MENGHITUNG...');
        $.ajax({url: 'App/api.php?m=rekapdata2', success: function(result){
            $("#tampil").html("<br><center><input type='button' value='TAMPILKAN HASIL' onclick='load1();'></center>");
        }});
    }
</script>
<script>
function load1() {
		var k=$("#tw").val();
		$("#tampil").html('<h1>...LOADING LAPORAN...</h1>');
        $.ajax({url: 'App/api.php?m=<?echo $lap;?>&tw='+k, success: function(result){
            $("#tampil").html(result);
        }});
    }
</script>
<script>
function loadp() {
		window.open("./?action=print&page=<?echo $lapprint;?>", "_blank");
    }
</script>
