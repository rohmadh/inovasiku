<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>UPLOAD FILE BANK V2</h2>



                    </div>
                </div>

                <hr />
				
							<?php
include("App/config/db.php.inc");
$conn = mysqli_connect($serv, $user, "", $db);
$prioritas=array("spp","pendukung","extra","kbm","infaq");
if (isset($_POST["import"])) {
	mysqli_query($conn,"truncate table master_import");
    
    $fileName = $_FILES["file"]["tmp_name"];
    $fileasal = $_FILES["file"]["name"];
    if ($_FILES["file"]["size"] > 0) {
        
        $file = fopen($fileName, "r");
        ##### proses sequencing pembayaran bertingkat
        while (($column = fgetcsv($file, 10000, ";")) !== FALSE) {
            $sqlInsert = "INSERT into keu_trxbank (pdate,efdate,branch,reffno,trxcode,desc1,desc2,debet,kredit,vanumber,vaname,file,tahun)
                   values ('" . $column[1] . "','" . $column[2] . "','" . $column[3] . "','" . $column[4] . "','" . $column[5] . "',
				   '" . $column[6] . "','" . $column[7] . "','" . $column[8] . "','" . $column[9] . "','" . $column[10] . "','" . $column[11] . "','".$fileasal."',
				   '" . $_SESSION['thn'] . "'
				   )";
            $result = mysqli_query($conn, $sqlInsert);
			########ambilsisatagihansesuaibulan transfer
			########### sisa tagihan
			$qs="SELECT id,nama,va1,va2,sum(spp)-sum(bspp) as ba,sum(pendukung)-sum(bpendukung) as bb, sum(extra)-sum(bextra) as bc,
			sum(kbm)-sum(bkbm) as bd,sum(infaq)-sum(binfaq) as be,sum(jamiyah)-sum(bjamiyah) as bf,
			sum(atk)-sum(batk) as bg,sum(bukupaket)-sum(bbukupaket) as bh, 
			sum(seragam)-sum(bseragam) as bi,sum(anjem)-sum(banjem) as bj, sum(catering)-sum(bcatering) as bk, sum(osis)-sum(bosis) as bl, 
			sum(lain)-sum(blain) as bm,
			sum(spp+pendukung+extra+kbm+infaq+jamiyah+atk+bukupaket+seragam+anjem+catering+osis+lain)-
			sum(bspp+bpendukung+bextra+bkbm+binfaq+bjamiyah+batk+bbukupaket+bseragam+banjem+bcatering+bosis+blain) as btagih,
			month(thn) as bulan,year(thn) as tahun 
			FROM keu_mastertagihan
			where thn<'".$column[1]."' and (va1='".$column[10]."' or va2='".$column[10]."')
			group by va1
			order by nama,bulan,tahun ASC
			";
			$rs = mysqli_query($conn, $qs);
			$rows=mysqli_fetch_array($rs);
			#######
			######### pembayaran sisa
			$qb="select va,sum(jml) as sisabayar 
			FROM keu_rincian_potong_trxbank
			where kode='byrsisa' and pdate<='".$column[1]."' and (va='".$column[10]."' or va='".$column[10]."')
			group by va
			";
			$rs1 = mysqli_query($conn, $qb);
			$rowsb=mysqli_fetch_array($rs1);
			###
			$utang=$rows['btagih']-$rowsb['sisabayar'];
			echo $utang;
            if (! empty($result)) {
				$inv=time();
				##### insert history
				$sqlhist="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','0020','".$column[1]."','TRF  a.n ".$column[11]."','".$column[9]."')";
				$resulthist = mysqli_query($conn, $sqlhist);
				##### proses sequencing pembayaran bertingkat
				$a=0;
				$jmlpemb=0;
				$sisauang=$column[9];
				$flag=0;
				####get prioritas
				$sqlp="select * from keu_prioritas_tagihan order by no ASC";
				$resultp = mysqli_query($conn, $sqlp);
				while($a<count($prioritas)){
				#while($rowp=mysqli_fetch_array($resultp)){
				####bulan
				$b=date('m',strtotime($column[1]));
				#$prioritas[$a]=$rowp['kode'];
				#### cek sudah dibayar?
				$sqlcek="select ".$prioritas[$a]." as dt, b".$prioritas[$a]." as dc from keu_mastertagihan where va1='".$column[10]."' and month(thn)='".$b."' and year(thn)='" . $_SESSION['thn'] . "'";
				echo $sqlcek;
				$resultc = mysqli_query($conn, $sqlcek);
				$dcek=mysqli_fetch_array($resultc);
				if(($dcek['dc']<$dcek['dt'])and($dcek['dt']>0)){
				##echo "sisa-".$sisauang;
				#### ambil nilai tagihan
				$sqltagih="select ".$prioritas[$a].",b".$prioritas[$a]." from keu_mastertagihan where va1='".$column[10]."' and month(thn)='".$b."' and year(thn)='" . $_SESSION['thn'] . "'";
				##echo $sqltagih;
				$resultt = mysqli_query($conn, $sqltagih);
				$tagih=mysqli_fetch_array($resultt);
				##echo $tagih[0];
				### update bayar
				if(($sisauang>=($tagih['0']-$tagih['1']))and($flag==0)){
				$sqlbayar="update keu_mastertagihan set b".$prioritas[$a]."='".$tagih['0']."' where va1='".$column[10]."' and month(thn)='".$b."' and year(thn)='" . $_SESSION['thn'] . "'";
				##echo $sqlbayar;
				$resultb = mysqli_query($conn, $sqlbayar);
				#####isi rincian potong
				$sqlrincian="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','".$prioritas[$a]."','".$column[1]."','bayar-".$prioritas[$a]."','".($tagih['0']-$tagih['1'])."')";
				$resultr = mysqli_query($conn, $sqlrincian);
				#$sisauang=$sisauang-$tagih['0'];
				}
				if(($sisauang<($tagih['0']-$tagih['1']) and $sisauang>0)and($flag==0)){
				$flag=1;
				####isikan bayar sisanya semua
				$sql1="update keu_mastertagihan set b".$prioritas[$a]."='".$sisauang."' where va1='".$column[10]."' and month(thn)='".$b."' and year(thn)='" . $_SESSION['thn'] . "'";
				$resultr = mysqli_query($conn, $sql1);
				$sql2="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','".$prioritas[$a]."','".$column[1]."','bayar-".$prioritas[$a]."[kurang]','".$sisauang."')";
				$resultr = mysqli_query($conn, $sql2);
				$sqlrincian="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','0030','".$column[1]."','SALDO SISA KURANG-STOP','0')";
				$resultr = mysqli_query($conn, $sqlrincian);
				}
				$sisauang=$sisauang-($tagih['0']-$tagih['1']);
				$utang=$utang-($tagih['0']-$tagih['1']);
				}
				$a=$a+1;
				
				
				}
				###### jika ada sisa uang bayar sisa tagihan
				echo $sisauang;
				if($sisauang>0){
				if($sisauang>$utang){
				$sqlbayarsisa="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','byrsisa','".$column[1]."','Bayar Sisa Tagihan sebelumnya','".$utang."')";
				$resultbayarsisa = mysqli_query($conn, $sqlbayarsisa);}
				if($sisauang<$utang){
				$sqlbayarsisa="insert into keu_rincian_potong_trxbank (va,noinv,kode,pdate,ket,jml) value ('".$column[10]."','".$inv."','byrsisa','".$column[1]."','Bayar Sisa Tagihan sebelumnya','".$sisauang."')";
				$resultbayarsisa = mysqli_query($conn, $sqlbayarsisa);}
				}
				###
                $type = "success";
                $message = "CSV Data Imported into the Database";
            } else {
                $type = "error";
                $message = "Problem in Importing CSV Data";
            }
####
        }
    }
}
?>

<script type="text/javascript">
$(document).ready(function() {
    $("#frmCSVImport").on("submit", function () {

	    $("#response").attr("class", "");
        $("#response").html("");
        var fileType = ".csv";
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + fileType + ")$");
        if (!regex.test($("#file").val().toLowerCase())) {
        	    $("#response").addClass("error");
        	    $("#response").addClass("display-block");
            $("#response").html("Invalid File. Upload : <b>" + fileType + "</b> Files.");
            return false;
        }
        return true;
    });
});
</script>

    <h3>Import CSV TRANSAKSI BANK DANAMON</h3>
    
    <div id="response" class="<?php if(!empty($type)) { echo $type . " display-block"; } ?>"><?php if(!empty($message)) { echo $message; } ?></div>
    <div class="outer-scontainer">
        <div class="row">

            <form class="form-horizontal" action="" method="post"
                name="frmCSVImport" id="frmCSVImport" enctype="multipart/form-data">
                <div class="input-row">
                    <label class="col-md-4 control-label">PIlih CSV
                        File(yang sudah disesuaikan)</label> <input type="file" name="file"
                        id="file" accept=".csv">
                    <button type="submit" id="submit" name="import"
                        class="btn-submit">Import</button> 
                    <br />
					
					<center>
					<i>Browse piih file,Klik Import, kemudian cek, setelah OK klik SIMPAN KE DATABASE. data lama akan diganti dg yg baru dg tahun yg sama</i><br />
					<input type="button" id="copydata" value="SIMPAN KE DATABASE" onclick="simpandata();">
					</center>
                </div>

            </form>

        </div>
		<div id="hasil">
		
		<hr>
		<b>Cek Data</b>
               <?php
            $sqlSelect = "SELECT * FROM keu_trxbank where tahun='".$_SESSION['thn']."'";
            $result = mysqli_query($conn, $sqlSelect);
            
            if (mysqli_num_rows($result) > 0) {
                ?>
            <table id='userTable' border='1' style="font-size:8pt;">
            <thead>
                <tr>
                    <th>postdate</th>
                    <th>effdate</th>
                    <th>branch</th>
                    <th>reffno</th>
					<th>trxcode</th>
					<th>desc1</th>
					<th>desc2</th>
					<th>debet</th>
					<th>kredit</th>
					<th>VAno</th>
					<th>VAname</th>
					<th>Tahun</th>
                </tr>
            </thead>
<?php
                
                while ($row = mysqli_fetch_array($result)) {
                    ?>
                    
                <tbody>
				
                <tr>
                    <td><?php  echo $row['pdate']; ?></td>
                    <td><?php  echo $row['efdate']; ?></td>
                    <td><?php  echo $row['branch']; ?></td>
                    <td><?php  echo $row['reffno']; ?></td>
					<td><?php  echo $row['trxcode']; ?></td>
					<td><?php  echo $row['desc1']; ?></td>
					<td><?php  echo $row['desc2']; ?></td>
					<td><?php  echo $row['debet']; ?></td>
					<td><?php  echo $row['kredit']; ?></td>
					<td><?php  echo $row['vanumber']; ?></td>
					<td><?php  echo $row['vaname']; ?></td>
					<td><?php  echo $row['tahun']; ?></td>
                </tr>
				
                    <?php
                }
                ?>
                </tbody>
        </table>
        <?php } ?>
		</div>
    </div>
	
	<script>
	alert("DATA DARI SIMDA TAHUN <?echo $_SESSION['thn'];?> , <?echo mysqli_num_rows($result)?> Kegiatan.");
	</script>
    <script>
	function simpandata() {
			$("#hasil").html('<h1>...MENGCOPY DATA KE DATABASE...</h1>');
			$.ajax({url: 'App/api.php?m=kendali.copy.simda&mode=copy', success: function(result){
				$("#hasil").html('<h1>...PROSES SELESAI...</h1>'); 
			}});
		}
	</script>            
<?
$sqltagih="select (sum(".$prioritas[0].")-sum(b".$prioritas[0].")) as sisat from keu_mastertagihan where va1='8844300000000410' and year(thn)='2019'";
#echo $sqltagih;
$result = mysqli_query($conn, $sqltagih);
$row=mysqli_fetch_array($result);
echo $row['sisat'];
$s="2019-12-11";
#echo date("m", strtotime($s));
$column[10]='100';
echo $column[10];
echo date('m',strtotime('2019-12-1'));
?>	
                         
