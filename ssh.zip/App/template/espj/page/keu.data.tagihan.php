<link rel="stylesheet" href="<?echo $base;?>/assets/css/jquery-ui.css">
  <script src="<?echo $base;?>/assets/js/jquery-ui.min.js"></script>
  <script>
  $( function() {
    $( "#ta" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
	$( "#tb" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
  } );
  </script>
<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 0px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<div class="row">
                    <div class="col-lg-12">

						<center>
                        <h2 align='center'>DATA TAGIHAN MURID Tahun <?echo date('Y');?></h2>

						<label>Masukkan KATA KUNCI NAMA:
						
						<input name="nis" id="nis" type="text" size="10">
						</label>
						<input type='button' value='CARI' onclick='load1();'>
						</center>
                    </div>
                </div>
<div id='tampil' align='center'>				
</div>

<script>
function load1() {
		var nis=$("#nis").val();
		$("#tampil").html('<h1>...LOADING DATA...</h1>');
        $.ajax({url: 'App/api.php?m=tagihan.murid.tabel&nis='+nis, success: function(result){
            $("#tampil").html(result);
        }});
    }
</script>
<script>
function loadp() {
		var ta=$("#ta").val();
		var tb=$("#tb").val();
		window.open("./?action=print&page=bku&ta="+ta+"&tb="+tb, "_blank");
    }
</script>
