<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />


<div class="row">
                    <div class="col-lg-12">


                        <h2>UPLOAD TAGIHAN MURID</h2>



                    </div>
                </div>

                <hr />
				
							<?php
include("App/config/db.php.inc");
$conn = mysqli_connect($serv, $user, "", $db);

if (isset($_POST["import"])) {
	mysqli_query($conn,"truncate table keu_mastertagihan_temp");
    $a=0;
	$iduplod=time();
    $fileName = $_FILES["file"]["tmp_name"];
    
    if ($_FILES["file"]["size"] > 0) {
        
        $file = fopen($fileName, "r");
        
        while (($column = fgetcsv($file, 10000, ";")) !== FALSE) {
			echo $a;
            $sqlInsert = "INSERT into keu_mastertagihan_temp (nama,kelas,va1,va2,spp,pendukung,extra,kbm,infaq,jamiyah,atk,bukupaket,seragam,anjem,catering,osis,lain,iduplod)
                   values ('" . $column[1] . "','" . $column[2] . "','" . $column[3] . "','" . $column[4] . "','" . $column[5] . "',
				   '" . $column[6] . "','" . $column[7] . "','" . $column[8] . "','" . $column[9] . "','" . $column[10] . "','" . $column[11] . "',
				   '" . $column[12] . "','" . $column[13] . "','" . $column[14] . "','" . $column[15] . "','" . $column[16] . "','" . $column[17] . "','" .$iduplod. "'
				   )";
            $result = mysqli_query($conn, $sqlInsert);
            
            if (! empty($result)) {
                $type = "success";
                $message = "CSV Data Imported into the Database";
            } else {
                $type = "error";
                $message = "Problem in Importing CSV Data";
            }
			$a=$a+1;
        }
    }
}
?>

<script type="text/javascript">
$(document).ready(function() {
    $("#frmCSVImport").on("submit", function () {

	    $("#response").attr("class", "");
        $("#response").html("");
        var fileType = ".csv";
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + fileType + ")$");
        if (!regex.test($("#file").val().toLowerCase())) {
        	    $("#response").addClass("error");
        	    $("#response").addClass("display-block");
            $("#response").html("Invalid File. Upload : <b>" + fileType + "</b> Files.");
            return false;
        }
        return true;
    });
});
</script>

    <h3>Import CSV master Tagihan Bulanan Murid</h3>
    
    <div id="response" class="<?php if(!empty($type)) { echo $type . " display-block"; } ?>"><?php if(!empty($message)) { echo $message; } ?></div>
    <div class="outer-scontainer">
        <div class="row">

            <form class="form-horizontal" action="" method="post"
                name="frmCSVImport" id="frmCSVImport" enctype="multipart/form-data">
                <div class="input-row">
                    <label class="col-md-4 control-label">PIlih CSV
                        File(yang sudah disesuaikan)</label> <input type="file" name="file"
                        id="file" accept=".csv">
                    <button type="submit" id="submit" name="import"
                        class="btn-submit">Import</button> 
                    <br />
					
					<center>
					<i>Browse piih file,Klik Import, kemudian cek, setelah OK klik SIMPAN KE DATABASE. data lama akan diganti dg yg baru dg tahun yg sama</i><br />
					
					</center>
                </div>

            </form>

        </div>
		<div id="hasil">
		
		<hr>
		<b>Cek Data JIKA SUDAH YAKIN, TEKAN TOMBOL SIMPAN KE DATABASE <input type="button" id="copydata" value="SIMPAN KE DATABASE" onclick="simpandata();"></b>
               <?php
            $sqlSelect = "SELECT * FROM keu_mastertagihan_temp where year(thn)='".$_SESSION['thn']."'";
            $result = mysqli_query($conn, $sqlSelect);
			
            
            if (mysqli_num_rows($result) > 0) {
                ?>
            <table id='userTable' border='1' style="font-size:8pt;">
            <thead>
                <tr>
                    <th>nama</th>
                    <th>kelas</th>
                    <th>va1</th>
                    <th>va2</th>
					<th>spp</th>
					<th>pendukung</th>
					<th>extra</th>
					<th>kbm</th>
					<th>infaq</th>
					<th>jamiyah</th>
					<th>atk</th>
					<th>b.paket</th>
					<th>seragam</th>
					<th>anjem</th>
					<th>catering</th>
					<th>osis</th>
					<th>lain</th>
					<th>wkt</th>
                </tr>
            </thead>
<?php
                
                while ($row = mysqli_fetch_array($result)) {
                    ?>
                    
                <tbody>
				
                <tr>
                    <td><?php  echo $row['nama']; ?></td>
                    <td><?php  echo $row['kelas']; ?></td>
                    <td><?php  echo $row['va1']; ?></td>
					<td><?php  echo $row['va2']; ?></td>
					<td><?php  echo $row['spp']; ?></td>
					<td><?php  echo $row['pendukung']; ?></td>
					<td><?php  echo $row['extra']; ?></td>
					<td><?php  echo $row['kbm']; ?></td>
					<td><?php  echo $row['infaq']; ?></td>
					<td><?php  echo $row['jamiyah']; ?></td>
					<td><?php  echo $row['atk']; ?></td>
					<td><?php  echo $row['bukupaket']; ?></td>
					<td><?php  echo $row['seragam']; ?></td>
					<td><?php  echo $row['anjem']; ?></td>
					<td><?php  echo $row['catering']; ?></td>
					<td><?php  echo $row['osis']; ?></td>
					<td><?php  echo $row['lain']; ?></td>
					<td><?php  echo $row['thn']; ?></td>
                </tr>
				
                    <?php
                }
                ?>
                </tbody>
        </table>
        <?php } ?>
		</div>
    </div>
	
	<script>
	alert("DATA MASTER TAGIHAN TAHUN <?echo $_SESSION['thn'];?> , <?echo mysqli_num_rows($result)?> Data.");
	</script>
    <script>
	function simpandata() {
			$("#hasil").html('<h1>...MENGCOPY DATA KE DATABASE...</h1>');
			var k=<?echo $iduplod;?>; 
			$.ajax({url: 'App/api.php?m=keu.copy.tagihan&mode=copy&iduplod='+k, success: function(result){
				$("#hasil").html('<h1>...PROSES SELESAI...</h1>'); 
			}});
		}
	</script>                           
                         
<?echo time();?>