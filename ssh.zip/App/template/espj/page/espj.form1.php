 
<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
  <link rel="stylesheet" href="<?echo $base;?>/assets/css/jquery-ui.css">
  <script src="<?echo $base;?>/assets/js/jquery-ui.min.js"></script>
  

<div class="row">
                    <div class="col-lg-12">


                        <h2>FORM SPJ <?echo txthtml($_SESSION['thn']);?></h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            PROGRAM DAN KEGIATAN OPD
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<div id="frmkeg">
							</div>
							
                            
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading" id=''>
						DOKUMEN SPJ
                            
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<div id="">
							<center>
							<button class="button" style="vertical-align:middle" onclick="getangkas();"><span>ANGGARAN KAS </span></button>
							<button class="button" style="vertical-align:middle" onclick="getfrmaktivitas();"><span>AKTIVITAS </span></button>
							<button class="button" style="vertical-align:middle" onclick="$('#blokform').show();;getfrmbkp();"><span>BUKTI KAS PENGELUARAN </span></button>
							<button class="button" style="vertical-align:middle" onclick="$('#blokform').hide();$('#juduldata').html('PILIH DATA..');"><span>SURAT TRANSFER </span></button>
							
							</center>
							</div>
							
                            
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<div class="row" id="blokform">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading" id='judulbox'>
                            ANGGARAN KAS
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<div id="frmkas">
							</div>
							
                            
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading" id='juduldata'>
                            DATA SPJ
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<div id="frmdata">
							</div>
							
                            
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			
	<div id="targetresp"></div>			

<div id="targettbl" class="table table-striped table-bordered table-hover">
                                
</div>


<script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>

<script>
function getkodeakun() {
		$("#kodeakun").html("<b>Loading data....</b>");
        $.ajax({url: 'App/api.php?m=keu.option.kode.akun', success: function(result){
            $("#kodeakun").html(result);
        }});
    }
</script>
<script>
function carimurid() {
		var q = $("#q").val();
		$("#klien").html("<b>Loading data....</b>");
        $.ajax({url: 'App/api.php?m=keu.list.murid.v2&q='+q, success: function(result){
            $("#klien").html(result);
        }});
    }
</script>

<script>
function frmtransaksireset() {
		$("#mode").val('save');
		$("#akun").val('0000');
		$("#ket").val('');
		$("#jml").val('');
		$("#idklien").val('');
		$("#dari").val('');
		$("#idd").val('');
		$("#klien").html('');
		$("#dtgl").val('');
		$("#bln").val('');
    }
</script>
<script>
function loadp() {
		var inv=$("#inv").val();
		window.open("./?action=print&page=invoice&inv="+inv, "_blank");
    }
</script>
<script>
function getprogkeg() {
		
		$("#frmkeg").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=frm.progkeg', success: function(result){
            $("#frmkeg").html(result);
        }});
    }
</script>
<script>
function getform(t,f,v) {
		$("#"+t+"").html("<b>Loading data....</b>");
        $.ajax({url: 'App/api.php?m='+f, success: function(result){
            $("#"+t+"").html(result);
        }});
    }
</script>
<script>
function getangkas() {
		var kkeg = $("#idkeg").val();
		var n = $("#nourut").val();
		$("#frmkas").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=frmlistangkas&q='+kkeg+'&n='+n, success: function(result){
            $("#frmkas").html(result);
        }});
    }
</script>
<script>
function refreshundangan(){
	var n = $("#idaktivitas").val();
	$("#frmdata").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=spj.data.undangan.tabel&n='+n, success: function(result){
            $("#frmdata").html(result);
        }});
}
function refreshaktivitas(){
	var n = $("#nourut").val();
	var kkeg = $("#idkeg").val();
	var kprog = $("#idprog").val();
	$("#frmdata").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=spj.aktivitas.tabel&kprog='+kprog+'&kkeg='+kkeg+'&n='+n, success: function(result){
            $("#frmdata").html(result);
        }});
}
function refreshdaftarundangan(){
		var ida = $("#ida").val();
	$("#frmdata").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=spj.daftar.undangan.tabel&ida='+ida, success: function(result){
            $("#frmdata").html(result);
        }});
}
function getfrmundangan(k,t) {
		var kkeg = $("#idkeg").val();
		var n = $("#nourut").val();
		$("#judulbox").html("FORM UNDANGAN");
		$("#frmkas").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=frmspj.input.undangan&q='+kkeg+'&n='+n, success: function(result){
            $("#frmkas").html(result);
			
			
        }});
		$("#idaktivitas").val(k);
		$("#txtaktivitas").val(t);
		refreshundangan();
    }
function getfrmdaftarundangan() {
		var kkeg = $("#idkeg").val();
		var n = $("#nourut").val();
		$("#judulbox").html("FORM DAFTAR UNDANGAN");
		$("#frmkas").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=frmspj.input.daftar.undangan&q='+kkeg+'&n='+n, success: function(result){
            $("#frmkas").html(result);
        }});
		
    }
function getfrmaktivitas(k) {
		var kkeg = $("#idkeg").val();
		var n = $("#nourut").val();
		$("#judulbox").html("FORM AKTIVITAS");
		$("#frmkas").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=frmspj.input.aktivitas&q='+kkeg+'&n='+n, success: function(result){
            $("#frmkas").html(result);
			$("#no").val(k);
        }});
		refreshaktivitas();
    }
function getfrmbkp(k) {
		var kkeg = $("#idkeg").val();
		var n = $("#nourut").val();
		$("#judulbox").html("FORM BUKTI KAS PENGELUARAN");
		$("#frmkas").html("<h2>Loading data....</h2>");
        $.ajax({url: 'App/api.php?m=frmspj.input.bkp&q='+kkeg+'&n='+n, success: function(result){
            $("#frmkas").html(result);
			$("#no").val(k);
        }});
    }
</script>
<script>
getkodeakun();getprogkeg();
</script>
