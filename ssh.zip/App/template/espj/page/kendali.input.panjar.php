<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<script src="<?echo $base;?>/assets/js/jquery-ui.min.js"></script>
<link rel="stylesheet" href="<?echo $base;?>/assets/css/jquery-ui.css">
<script>
  $( function() {
    $( "#tgl" ).datepicker({dateFormat: "dd/mm/yy",changeMonth:true,changeYear:true});
  } );
  </script>

<div class="row">
                    <div class="col-lg-12">


                        <h2>INPUT NILAI PANJAR DAN SPJ</h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            PILIH PROGRAM DAN KEGIATAN
                        </div>
                        <div class="panel-body">
                            <div class="row">
							<div id='frmtargetprogkeg'>
							</div>
				</div></div></div></div></div>
				<div id="frmtarget">
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default" id='frmpanjar'>
                        <div class="panel-heading">
                            Form INPUT PANJAR
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>JENIS TRANSAKSI</label></td><td><label>:</label></td>
							<td>
							<select id="tipepanjar">
							<option value="0">Diberikan Panjar</option>
							<option value="1">Pengembalian Panjar</option>
							</select>
							
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>TANGGAL PANJAR </label></td><td><label>:</label></td>
							<td>
							<input name="nama" id="tgl" type="text" size="20">
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>JUMLAH PANJAR </label></td><td><label>:</label></td><td><input name="nama" id="jmlpanjar" type="text" size="20" onfocus='refreshtabel();'>
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							</td>
							<td><label>Keterangan </label></td><td><label>:</label></td><td><textarea id='ket' cols='80%'></textarea>
							
							</td>
							<td></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN" id="btninputpanjar" onclick="inputpanjar();">
							<input type="button" value="TAMBAH PANJAR" id="btntambah" onclick="setawal();">
							</td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			</div>
	<div id="message"></div>			
<?
$q=mysql_query("select * from kelompok order by nama");

?>
<input type="button" value="REFRESH" id="btninputpanjar" onclick="refreshtabel();">
<div class="table-responsive" id="idtarget">                              
</div>

    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
		var k=$("#idkeg").val();
		$("#idtarget").html('...LOADING...');
        $.ajax({url: 'App/api.php?m=panjar.tabel&mode=list&id='+k, success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function loadfrmprogkeg() {
		$("#frmtargetprogkeg").html('...LOADING...');
        $.ajax({url: 'App/api.php?m=frm.progkeg', success: function(result){
            $("#frmtargetprogkeg").html(result);
        }});
    }
</script>
<script>
function getlprog() {
		$("#targetlistprog").html('<h1>...LOADING...</h1>');
		var k=$("#qp").val();
        $.ajax({url: 'App/api.php?m=listprogall&q='+k, success: function(result){
            $("#targetlistprog").html(result);
			$("#targetlistkeg").html('');
        }});
    }
</script>
<script>
function getlkeg() {
		$("#targetlistkeg").html('<h1>...LOADING...</h1>');
		var k=$("#qk").val();
		var kp=$("#idprog").val();
        $.ajax({url: 'App/api.php?m=listkeg&idprog='+kp+'&q='+k, success: function(result){
            $("#targetlistkeg").html(result);
        }});
    }
</script>
<script>
function inputpanjar() {
		var mode=$("#mode").val();
		var idkeg=$("#idkeg").val();
		var jp=$("#tipepanjar").val();
		var idpanjar=$("#idpanjar").val();
		var npanjar=$("#jmlpanjar").val();
		var tgl=$("#tgl").val();
		var ket=$("#ket").val();
        $.ajax({url: 'App/api.php?m=panjar.input&mode='+mode+'&idkeg='+idkeg+'&idpanjar='+idpanjar+'&jp='+jp+'&npanjar='+npanjar+'&tgl='+tgl+'&ket='+ket, success: function(result){
            alert(result);
			refreshtabel();
        }});
    }
</script>
<script>
function setawal() {
$("#targetlistprog").html('');
$("#targetlistkeg").html('');
$("#tipepanjar").val('0');
$("#tgl").val('');
$("#jmlpanjar").val('');
$("#ket").val('');
$("#idkeg").val('');$("#namakeg").val('');
$("#idprog").val('');$("#namaprog").val('');
}
</script>
<script>refreshtabel();loadfrmprogkeg();</script>
<div id="loader">                              
</div>