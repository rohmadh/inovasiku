<?
if(strlen($data['tahun'])>0){
$_SESSION['thn']=$data['tahun'];
}

?>

<center><h2>TAHUN ANGGARAN SUDAH DIUBAH KE TAHUN <? echo $_SESSION['thn'];?></h2></center>