<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<?
$q=mysql_query("select * from master where kprog !='' and kode='".$data['id']."'");
$r=mysql_fetch_array($q);
?>

<div class="row">
                    <div class="col-lg-12">


                        <h2>DAFTAR KEGIATAN</h2>



                    </div>
                </div>

                <hr />
				<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form INPUT
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<table border="0">
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							<input type="hidden" id="mode" value="save">
							<input type="hidden" id="idprog" value="<?echo $data['id'];?>">
							<input type="hidden" id="idkeg" value="">
							</td>
							<td><label>NAMA PROGRAM </label></td><td><label>:</label></td><td><input name="nama" id="namaprog" class="form-control" type="text" value="<?echo $r['kprog'];?>" size="100" disabled>
							<br />
							<div id="targetlistprog"></div>
							</td>
							<td><label>KATA KUNCI :</label><input type="text" id="qp" ><input type="button" value="CARI" onclick='getlprog();'></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;
							
							</td>
							<td><label>NAMA KEGIATAN</label></td><td><label>:</label></td><td><input name="nama" id="namakeg" class="form-control" type="text" size="100" onfocus='refreshtabel();'>
							<br />
							<div id="targetlistkeg"></div>
							</td>
							<td></td>
							</tr>
							
							<tr>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td></td><td></td><td></td>
							</tr>
							</table>
                            
							<table>
							<tr>
							<td></td><td></td><td><input type="button" value="SIMPAN" id="btninput" onclick="inputkeg();"></td>
							</tr>
							</table>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<div id="message"></div>
<input type='button' onclick='refreshtabel();' value='RELOAD TABEL'>	
<?
$q=mysql_query("select * from kelompok order by nama");

?>
<div class="table-responsive" id="idtarget">                              
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
<script>
function refreshtabel() {
		var k=$("#idprog").val();
		$("#idtarget").html('<h1>...LOADING...</h1>');
        $.ajax({url: 'App/api.php?m=keg.tabel&mode=list&id='+k, success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<script>
function getlprog() {
		$("#targetlistprog").html('<h1>...LOADING...</h1>');
		var k=$("#qp").val();
        $.ajax({url: 'App/api.php?m=listprogall&q='+k, success: function(result){
            $("#targetlistprog").html(result);
        }});
    }
</script>
<script>
function inputkeg() {
		var mode=$("#mode").val();
		var idprog=$("#idprog").val();
		var idkeg=$("#idkeg").val();
		var namakeg=$("#namakeg").val();
        $.ajax({url: 'App/api.php?m=keg.input&mode='+mode+'&idprog='+idprog+'&idkeg='+idkeg+'&namakeg='+namakeg, success: function(result){
            alert('DATA TERSIMPAN...');
			refreshtabel();
			setawal();
        }});
    }
function setawal(){
$("#mode").val('save');
$("#namakeg").val('');
}
</script>
<script>refreshtabel();</script>
