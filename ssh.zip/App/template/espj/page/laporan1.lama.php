<style>
/* 
Generic Styling, for Desktops/Laptops 
*/
.table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
.table tr:nth-of-type(odd) { 
  background: #eee; 
}
.table th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
.table td, th { 
  padding: 0px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
</style>
<div class="row">
                    <div class="col-lg-12">

						<center>
                        <h2 align='center'>KENDALI PENYEDIAAN DANA</h2>

						<label>Bulan<select id='bln'>
						<?
						for ($i = 1; $i <= 12; $i++) {?>
						<option value='<? echo $i;?>' <?if($i==intval(date('m'))){echo "selected";}?>><?echo $i;?></option>
						<?}
						?>
						
						</select></label>
						<label>Tahun<select id='thn'>
						
						<?
						$io=intval($_SESSION['thn']);
						for ($i = ($io-10); $i <= $io; $i++) {?>
						<option value='<? echo $i;?>' <?if($i==$_SESSION['thn']){echo "selected";}?>><?echo $i;?></option>
						<?}
						?>
						
						</select></label>
						<input type='button' value='REKAP' onclick='load1();'>
						</center>
                    </div>
                </div>
<div id='tampil' align='center'>				
</div>
<script>
function hitung1() {
		$("#tampil").html('...MENGHITUNG...');
        $.ajax({url: 'App/api.php?m=rekapdata1', success: function(result){
            $("#tampil").html("<br><center><input type='button' value='TAMPILKAN HASIL' onclick='load1();'></center>");
        }});
    }
</script>
<script>
function load1() {
		$("#tampil").html('<h1>...LOADING LAPORAN...</h1>');
        $.ajax({url: 'App/api.php?m=laporan1.tabel', success: function(result){
            $("#tampil").html(result);
        }});
    }
</script>
