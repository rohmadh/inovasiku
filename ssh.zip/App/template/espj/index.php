﻿<?
include("App/header.php");
$base="App/template/espj";
if(isset($_SESSION['login'])){}else{header("Location: App/login");}
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->

<!-- BEGIN HEAD-->
<head>
   
     <meta charset="UTF-8" />
    <title>SISTEM E-SPJ KABUPATEN KULON PROGO</title>
     <meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
     <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <!-- GLOBAL STYLES -->
    <!-- GLOBAL STYLES -->
    <link rel="stylesheet" href="<?echo $base;?>/assets/plugins/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="<?echo $base;?>/assets/css/main.css" />
    <link rel="stylesheet" href="<?echo $base;?>/assets/css/theme.css" />
    <link rel="stylesheet" href="<?echo $base;?>/assets/css/MoneAdmin.css" />
    <link rel="stylesheet" href="<?echo $base;?>/assets/plugins/Font-Awesome/css/font-awesome.css" />
	<script src="<?echo $base;?>/assets/plugins/jquery-2.0.3.min.js"></script>
    <!--END GLOBAL STYLES -->

    <!-- PAGE LEVEL STYLES -->
    <!-- END PAGE LEVEL  STYLES -->
       <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript">
   function pengumuman(){
   
   window.open("App/pengumuman.html", "_blank", "toolbar=no,scrollbars=no,resizable=yes,location=no,status=no,top=50,left=500,width=600,height=400");
   
   }
</script>
<style>
#myProgress {
  width: 100%;
  background-color: #ffff;
}

#myBar {
  width: 1%;
  height: 30px;
  background-color: #4CAF50;
}
</style>
<script>
function startbar() {
  var elem = document.getElementById("myBar");   
  var width = 1;
  var id = setInterval(frame, 10);
  $("#myBar").show();
  function frame() {
    if (width >= 100) {
      clearInterval(id);
    } else {
      width++; 
      elem.style.width = width + '%'; 
    }
  }
}
</script>
<style>
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 15px;
  padding: 5px;
  
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>

<style>
.buttoncmd {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin: 4px 2px;
  cursor: pointer;
}

.button1 {font-size: 10px;}
.button2 {font-size: 12px;}
.button3 {font-size: 16px;}
.button4 {font-size: 20px;}
.button5 {font-size: 24px;}
</style>
</head>
    <!-- END  HEAD-->
    <!-- BEGIN BODY-->
<body class="padTop53 " >

     <!-- MAIN WRAPPER -->
    <div id="wrap">


         <!-- HEADER SECTION -->
        <div id="top">

            <nav class="navbar navbar-inverse navbar-fixed-top " style="padding-top: 10px;">
                <a data-original-title="Show/Hide Menu" data-placement="bottom" data-tooltip="tooltip" class="accordion-toggle btn btn-primary btn-sm visible-xs" data-toggle="collapse" href="#menu" id="menu-toggle">
                    <i class="icon-align-justify"></i>
                </a>
                <!-- LOGO SECTION -->
                <header class="navbar-header">

                    <a href="index.html" class="navbar-brand">
                    <img src="App/template/espj/assets/img/logokp.png" width="45">SISTEM E-SPJ KABUPATEN KULON PROGO</a>
                </header>
                <!-- END LOGO SECTION -->
                <ul class="nav navbar-top-links navbar-right">

                    <!-- MESSAGES SECTION -->
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <span class="label label-success">UBAH TAHUN ANGGARAN</span>    <i class="icon-envelope-alt"></i>&nbsp; <i class="icon-chevron-down"></i>
                        </a>
						
						<ul class="dropdown-menu dropdown-messages">
						<?$t=date('Y')-1;$ta=$t+5;while($t<=$ta){?>
                            <li>
                                <a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=ubah.tahun&tahun=".$t."",$key2));?>">
                                    <div>
                                       <strong>Tahun <?echo $t;?></strong>
                                    
                                    </div>
                                    
                                </a>
                            </li>
                            <li class="divider"></li>
                        <?$t++;}?>    
                            
                        </ul>
						
                        

                    </li>
                    <!--END MESSAGES SECTION -->

                    

                    
                    <!--ADMIN SETTINGS SECTIONS -->

                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="icon-user "></i>&nbsp; <i class="icon-chevron-down "></i>
                        </a>

                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=user.setting&idu=".$_SESSION['nipuser']."",$key2));?>"><i class="icon-user"></i> User Profile </a>
                            </li>
                            <li><a href="#"><i class="icon-gear"></i> Settings </a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="App/login/?mode=logout"><i class="icon-signout"></i> Logout </a>
                            </li>
                        </ul>

                    </li>
                    <!--END ADMIN SETTINGS -->
                </ul>

            </nav>

        </div>
        <!-- END HEADER SECTION -->



        <!-- MENU SECTION -->
       <div id="left" style="position: fixed;">
            <div class="media user-media well-small">
                <a class="user-link" href="#">
                    <img class="media-object img-thumbnail user-img" alt="User Picture" src="App/template/espj/api/uploaded_file/user/ariel.jpg" width="100"/>
                </a>
                <br />
                <div class="media-body">
                    <h5 class="media-heading"> <?echo $_SESSION['namauser'];?>(<?echo $_SESSION['iduser'];?>)</h5>
                    <ul class="list-unstyled user-info">
                        
                        <li>
                             <a class="btn btn-success btn-xs btn-circle" style="width: 10px;height: 12px;"></a> @<?echo $_SESSION['thn'];?>
                           
                        </li>
                       
                    </ul>
                </div>
                <br />
            </div>

            <ul id="menu" class="collapse">

                
                <li class="panel">
					<?if($_SESSION['leveluser']=='0'){?>
					<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=kendali.input.progkeg&id=".$r['id']."",$key2));?>">
					<?}else{?>
                    <a href="?" >
					<?}?>
                        <i class="icon-table"></i> Dashboard
	   
                       
                    </a>                   
                </li>
				<li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle collapsed" data-target="#form-pa">
                        <i class="icon-pencil"></i> SETTING DOKUMEN
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                          &nbsp; &nbsp;
                    </a>
                    <ul class="collapse" id="form-pa">
                        <li class=""><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=espj.setting.pejabat",$key2));?>"><i class="icon-angle-right"></i> SETTING PEJABAT </a></li>
						<li class=""><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=keu.koderek",$key2));?>"><i class="icon-angle-right"></i> KODE REKENING </a></li>
						
                        
                    </ul>
                </li>
				<?if($_SESSION['leveluser']=='0'){?>
				<li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle collapsed" data-target="#form-navmon">
                        <i class="icon-pencil"></i> PROGRAM KEGIATAN
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                          
                    </a>
					<ul class="collapse" id="form-navmon">
					<?if($_SESSION['leveluser']=='0'){?>
						<li class=""><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=kendali.upload.progkeg",$key2));?>"><i class="icon-angle-right"></i> UPLOAD DATA</a></li>
						
                    <?}?>    
						
						
                    </ul>
                </li>
				<?}?>
				
				
				<li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle collapsed" data-target="#form-spj">
                        <i class="icon-pencil"></i> SPJ
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                          
                    </a>
					<ul class="collapse" id="form-spj">
                        
						<li class=""><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=espj.form1",$key2));?>" onclick="startbar();"><i class="icon-angle-right"></i> FORM SPJ </a></li>
						
						
                    </ul>
                </li>
				<li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle collapsed" data-target="#form-navkk">
                        <i class="icon-pencil"></i> LAPORAN
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                          
                    </a>
                    <ul class="collapse" id="form-navkk">
                        <li class=""><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=laporan.penerimaan.harian",$key2));?>"><i class="icon-angle-right"></i> LAPORAN REALISASI </a></li>
                        
						
                    </ul>
                </li>
				
				
                <li><a href="App/login/?mode=logout"><i class="icon-signin"></i> Keluar </a></li>

            </ul>

        </div>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content">

            <div class="inner" style="min-height:1200px;">
            <div id="sasa"></div>
			<div id="myProgress" style="position:fixed;">
			  <div id="myBar"></div>
			</div>
			<?php
if($data['page']) {
$page=$data['page'];
$modul=$data['modul'];
} else {
  if($_SESSION['leveluser']=='0'){$page='home';}else{
$page='home';}
$modul='page';
}
include("App/template/espj/".$modul."/".$page.".php");
?> 



            </div>




        </div>
       <!--END PAGE CONTENT -->


    </div>

     <!--END MAIN WRAPPER -->

   <!-- FOOTER -->
    <div id="footer">
        <p>&copy;  ALAZHAR BSB CITY &nbsp;2019 &nbsp;</p>
    </div>
    <!--END FOOTER -->
     <!-- GLOBAL SCRIPTS -->
    
     <script src="<?echo $base;?>/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?echo $base;?>/assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    <!-- END GLOBAL SCRIPTS -->
	<script>
	function loaderwait() {
			$("#sasa").html("<h2>Loading PAGE....</h2>");	
		}
	</script>
	<script>
	$("#myBar").hide();
	</script>
</body>
    <!-- END BODY-->
    
</html>
