<?
###### query data
#####
$q="
SELECT *,sum(case when ket like'CASH%' then jml else 0 end) as bayar
FROM keu_rincian_potong_trxbank
where noinv='".$_GET['inv']."'
group by noinv
order by noinv ASC
";
$stmt = $conn->prepare($q);
$stmt->execute();
$rowb = $stmt->fetch();
#$conn = null;
#####
$q2="
SELECT *,day(pdate) as tgl,month(pdate) as bln,year(pdate) as thn
FROM keu_rincian_potong_trxbank
where noinv='".$_GET['inv']."' and ket like'bayar%'
order by id ASC
";
?>

<div id='histtrx'>
<center>
<table class='table' width='100%'>
<tr>
<td><img src="App/<?echo $base;?>/assets/img/logobsb2.jpg" width='100'></td><td align='center'><font size='3'><b>KUITANSI PEMBAYARAN</b></font>
<br />
<b>KB-TK-SD-SMP IA 29 & SMA  IA 16</b><br />
	Jl. RM Hadi Soebeno Sosrowardoyo, Mijen Semarang Telp. 024-76676637

</td>
<td><img src="App/<?echo $base;?>/assets/img/logoslawiok.png" width='100'></td>
</tr>
</table>
<br />
No. Invoice: <?echo txthtml($_GET['inv']);?>
<br />
<table class="table" style="font-size:9pt;" width="100%" class="table table-striped table-bordered table-hover" id="dataTables">
<tr>
					<th>Tanggal</th>
					<th>URAIAN</th>
					<th>Jumlah</th>
                </tr>

<?
$stmt = $conn->prepare($q2);
$stmt->execute();
$n=1;
$a=0+$sisauangsbl;$b=0;$c=0;$d=0;$e=0;$f=0;$g=0;$h=0;$i=0;$j=0;$k=0;$l=0;$m=0;$tagih=0;
while ($row = $stmt->fetch()) {
?>
<tr>
                    <td><?php  echo $row['tgl']."-".$row['bln']."-".$row['thn']; ?></td>
					<td><?php  echo $row['ket']; ?></td>
					<td align="right"><?php  echo uang($row['jml']); ?></td>

</tr>
<?
$n=$n+1;
$a=$a+$row['jml'];$b=$b+$row['pemotongan'];$c=$c+$row['c'];$d=$d+$row['d'];$e=$e+$row['e'];$f=$f+$row['f'];$g=$g+$row['g'];
$h=$h+$row['h'];$i=$i+$row['i'];$j=$j+$row['j'];$k=$k+$row['k'];$l=$l+$row['l'];$m=$m+$row['m'];$tagih=$tagih+$row['tagih'];
$n=$i+($row['i']+$row['j']+$row['k']+$row['l']+$row['m']+$row['katering']+$row['atk']+$row['jamiyyah']);
}?>

<tr>
                    <td colspan='2'>Total</td>
					<td align="right"><?php  echo uang($a); ?></td>

</tr>
</table>
</center>
<br />

Pembayaran: Rp.<?echo txthtml(uang($rowb['bayar']));?> <br />
Kembali: Rp.<?echo txthtml(uang($rowb['bayar']-$a));?>  *) diambil/disimpan <br />
<hr style='border-top: 0px solid black;'>
Semarang, <br />
<?echo date('d')?> <?echo bulan(date('m'))?> <?echo date('Y')?>
<br /><br /><br /><br /><br /><br /><br />
...................................
</table>
<?$conn = null;?>

