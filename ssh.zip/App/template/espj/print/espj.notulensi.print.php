<?
#$q="select * from undangan where id='"$_GET['id']"'";
#echo $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM undangan where id='".$_GET['a']."'");
$exec = $stmt->execute();
$r2 = $stmt->fetch();
######
$stmt = $conn->prepare("SELECT * FROM notulensi where idaktivitas='".$_GET['a']."'");
$exec = $stmt->execute();
$r = $stmt->fetch();
$conn = null;
?>
<html>
<head>
</head>
<style>
body{
	font-family:verdana;
}

</style>
<body>
<table width="100%">
<tr>
<td width="10%"><img src="App/template/espj/assets/img/logokp.png" width="150px"></td>
<td align="center">
<txt class="pemkab">PEMERINTAH KABUPATEN KULON PROGO </txt><br/>
<txt class="opd">BADAN PERENCANAAN PEMBANGUNAN DAERAH</txt><br />
<txt class="alamatopd">Gedug BAPPEDA & BKD, Jl. Perwakilan No.01, Terbah, Wates, Kabupaten Kulon Progo, Daerah Istimewa Yogyakarta 55611</txt>
</td>
</tr>
</table>
<hr / style="border:1.5px solid black;">

<br>
<table width="100%">
<tr>
<td width="10%" valign="top"></td>
<td width="100" colspan="3" align="center">&nbsp;&nbsp;<b>NOTULENSI HASIL RAPAT</b></td><td width="10"></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">HARI/TANGGAL</td><td width="10">:</td><td><? echo $r2['hari'];?>,<? echo $r2['tgl'];?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">WAKTU</td><td width="10">:</td><td><? echo $r2['jam'];?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">TEMPAT</td><td width="10">:</td><td><? echo $r2['tempat'];?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">ACARA</td><td width="10">:</td><td><? echo $r2['acara'];?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">KESIMPULAN</td><td width="10">:</td><td></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100"></td><td width="10"></td><td><? echo $r['txtnotulensi'];?></td>
</tr>
</table>
<br />

<table width="100%" class="tabpolos">
<tr>
<td width="10%" valign="top"></td>
<td width="50%"></td><td align="center">Wates, <?echo date(d);?> <?echo bulan(date(m));?> <?echo date(Y);?><br />Mengetahui,<br />PPTK<br /><br /><br /><br /></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="50%"></td><td align="center"><u>Imron Rosyadi, SE. Msc</u><br />NIP. 1234 1234 1234</td>
</tr>
</table>

</body>
</html>