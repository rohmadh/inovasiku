<?
$stmt = $conn->prepare("SELECT * FROM srttransfer 
where idbend26='".$_GET['a']."' ");
$exec = $stmt->execute();
$r = $stmt->fetch();
#######
$stmt = $conn->prepare("SELECT * FROM bend26 
where id='".$_GET['a']."' ");
$exec = $stmt->execute();
$r2 = $stmt->fetch();
?>
<html>
<head>
</head>
<style>
body{
	font-family:verdana;
}



</style>
<body>
<table width="100%" >
<tr>
<td width="10%"><img src="App/template/espj/assets/img/logokp.png" width="150px"></td>
<td align="center">
<txt class="pemkab">PEMERINTAH KABUPATEN KULON PROGO </txt><br/>
<txt class="opd">BADAN PERENCANAAN PEMBANGUNAN DAERAH</txt><br />
<txt class="alamatopd">Gedug BAPPEDA & BKD, Jl. Perwakilan No.01, Terbah, Wates, Kabupaten Kulon Progo, Daerah Istimewa Yogyakarta 55611</txt>
</td>
</tr>

<tr>
<td></td><td></td>
</tr>

</table>
<hr / style="border:1.5px solid black;">
</table>
<table width="100%">
<tr>
<td width="50%" valign="top">

</td>

<td>

<br /><br />
</td>
</tr>
<tr>
<td width="50%" valign="top">
Nomor:<br />
Sifat:<br />
Lamp.:<br />
Hal  :
</td>

<td>
<txt class="tgl">Wates, <?echo date(d);?> <?echo bulan(date(m));?> <?echo date(Y);?></txt> <br /><br />
Kepada
Yth.<br />
PT Bank BPD DIY Cabang Wates
<br /><br />
di -
<br />&nbsp;&nbsp;&nbsp;Kulon Progo<br />
</td>
</tr>
</table>
<br>
<table width="100%">
<tr>
<td width="10%" valign="top"></td>
<td width="100" colspan="3">&nbsp;&nbsp;
Dengan ini kami mohon bantuan Saudara untuk memindahbukukan dana kami, pada nomor rekening 
003.111.000380 a.n  Bendahara Pengeluaran Bappeda Kabupaten Kulon Progo kepada :
</td><td width="10"></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Nama</td><td width="10">:</td><td><?echo htmlspecialchars($r['nama'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Alamat</td><td width="10">:</td><td><?echo htmlspecialchars($r['alamat'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">NPWP</td><td width="10">:</td><td><?echo htmlspecialchars($r['npwp'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Bank</td><td width="10">:</td><td><?echo htmlspecialchars($r['bank'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">No.Rekening</td><td width="10">:</td><td><?echo htmlspecialchars($r['rekbank'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Jumlah</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r2['rupiah']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Terbilang</td><td width="10">:</td><td>==<?echo htmlspecialchars($r2['txtrupiah'])?>==</td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Jumlah Bersih</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r2['rupiah']-($r2['ppn']+$r2['pph22']+$r2['pph23']+$r2['pajakdaerah'])))?></td>
</tr>
<tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Pajak-pajak</td><td width="10">:</td><td></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;PPN (10%)</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r2['ppn']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;PPh Pasal 22</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r2['pph22']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;PPh Pasal 23</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r2['pph23']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;Pajak daerah</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r2['pajakdaerah']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Ditransaksikan pada tanggal</td><td width="10">:</td><td></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100" valign="top">Keterangan</td><td width="10">:</td><td valign="top"><?echo htmlspecialchars($r2['untukpemb'])?><br /> Kode Rekening Kegiatan:<?echo htmlspecialchars($r2['krek'])?>
.<?echo htmlspecialchars($r2['krekbelanja'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Catatan</td><td width="10">:</td><td><?echo htmlspecialchars($r['catatan'])?></td>
</tr>
<td width="10%" valign="top"></td>
<td width="100" colspan="3">&nbsp;Demikian kami sampaikan atas bantuannya diucapkan terima kasih</td><td width="10"></td>
</tr>
</table>
<br />
<table width="100%" style="border:none;">
<tr>

<td width="50%" valign="top" align="center">Mengetahui, <br/>PPK/Kasubag Keuangan Sekretariat<br />Bappeda Kabupaten Kulon Progo</td>
<td align="center" valign="top">Wates, <br />Bendahara Pengeluaran <br /><br /><br /><br /><br /><br /></td>
</tr>
<tr>

<td width="50%" align="center"><u><?echo strtoupper("adi mindarta, SE.")?></u><br/>NIP. 19750510 199803 1 007</td>
<td align="center"><u><?echo strtoupper("slamet purwito")?></u><br />NIP.19740509 200701 1 023</td>
</tr>
</table>
<p style="page-break-before: always">
<center><b><u>SURAT KESANGGUPAN</u></b></center>
<table width="100%">
<tr>
<td width="10%" valign="top"></td>
<td width="" colspan="3">Yang bertanda tangan di bawah ini, kami:</td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Nama</td><td width="10">:</td><td><?echo htmlspecialchars($r['nama'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Alamat</td><td width="10">:</td><td><?echo htmlspecialchars($r['alamat'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">NPWP</td><td width="10">:</td><td><?echo htmlspecialchars($r['npwp'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Bank</td><td width="10">:</td><td><?echo htmlspecialchars($r['bank'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">No.Rekening</td><td width="10">:</td><td><?echo htmlspecialchars($r['rekbank'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100" colspan="3">&nbsp;&nbsp;
Sehubungan dengan pencairan Dana  atas kegiatan kami dari Pemerintah Kabupaten
Kulon Progo, maka kami sanggup untuk dipotongkan oleh Bank BPD Provinsi DIY Cabang Wates  untuk kewajiban pembayaran sejumlah yang tercantum dalam Surat Bappeda Kulon Progo 
Nomor :&nbsp;&nbsp;&nbsp;&nbsp;/ Bappeda /&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;tertanggal    .......... 2020, Perihal : Pemindahbukuan Uang, yang terdiri dari :                                       
</td><td width="10"></td>
</tr>


<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;PPN </td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r2['ppn']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;PPh Pasal 22</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r2['pph22']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;PPh Pasal 23</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r2['pph23']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;Pajak daerah</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r2['pajakdaerah']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;Denda</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r['denda']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;Penyusutan</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r['penyusutan']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">&nbsp;&nbsp;&nbsp;&nbsp;Biaya Transfer</td><td width="10">:</td><td>Rp. <?echo htmlspecialchars(uang($r['biayatransfer']))?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Ditransaksikan pada tanggal</td><td width="10">:</td><td></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100" valign="top">Keterangan</td><td width="10">:</td><td valign="top"><?echo htmlspecialchars($r2['untukpemb'])?><br /> Kode Rekening Kegiatan:<?echo htmlspecialchars($r2['krek'])?>
.<?echo htmlspecialchars($r2['krekbelanja'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Catatan</td><td width="10">:</td><td><?echo htmlspecialchars($r['catatan'])?></td>
</tr>
<td width="10%" valign="top"></td>
<td width="100" colspan="3">&nbsp;Demikian kami sampaikan atas bantuannya diucapkan terima kasih</td><td width="10"></td>
</tr>
</table>
<br />
<table width="100%" style="border:none;">
<tr>

<td width="50%" valign="top" align="center">Mengetahui, <br/>PPK/Kasubag Keuangan Sekretariat<br />Bappeda Kabupaten Kulon Progo</td>
<td align="center" valign="top">Wates, <br />Bendahara Pengeluaran <br /><br /><br /><br /><br /><br /></td>
</tr>
<tr>

<td width="50%" align="center"><u><?echo strtoupper("adi mindarta, SE.")?></u><br/>NIP. 19750510 199803 1 007</td>
<td align="center"><u><?echo strtoupper("slamet purwito")?></u><br />NIP.19740509 200701 1 023</td>
</tr>
</table>
</body>
</html>