<?
$stmt = $conn->prepare("SELECT * FROM undangan where id='".$_GET['a']."' ");
$exec = $stmt->execute();
$r = $stmt->fetch();
###
$stmt = $conn->prepare("SELECT * FROM pejabat where kodejab='01' ");
$exec = $stmt->execute();
$rjab = $stmt->fetch();
?>
<html>
<head>
</head>
<style>
body{
	font-family:verdana;
}



</style>
<body>
<table width="100%" >
<tr>
<td width="10%"><img src="App/template/espj/assets/img/logokp.png" width="150px"></td>
<td align="center">
<txt class="pemkab">PEMERINTAH KABUPATEN KULON PROGO </txt><br/>
<txt class="opd">BADAN PERENCANAAN PEMBANGUNAN DAERAH</txt><br />
<txt class="alamatopd">Gedug BAPPEDA & BKD, Jl. Perwakilan No.01, Terbah, Wates, Kabupaten Kulon Progo, Daerah Istimewa Yogyakarta 55611</txt>
</td>
</tr>

<tr>
<td></td><td></td>
</tr>

</table>
<hr / style="border:1.5px solid black;">
</table>
<table width="100%">
<tr>
<td width="50%" valign="top">

</td>

<td>
<txt class="tgl">Wates, <?echo date(d);?> <?echo bulan(date(m));?> <?echo date(Y);?></txt>
<br /><br />
</td>
</tr>
<tr>
<td width="50%" valign="top">
Nomor:<br />
Lamp.:<br />
Hal  :
</td>

<td>
Kepada:<br /><br /><br />
Yth.<br /><br /><br /><br /><br />
di &nbsp;&nbsp;Tempat

</td>
</tr>
</table>
<br>
<table width="100%">
<tr>
<td width="10%" valign="top"></td>
<td width="100" colspan="3">&nbsp;&nbsp;Mengharap Kehadiran bapak/ibu/Saudara pada</td><td width="10"></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Hari, Tanggal</td><td width="10">:</td><td><?echo htmlspecialchars($r['hari'])?>, <?echo htmlspecialchars($r['tgl'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Jam</td><td width="10">:</td><td><?echo htmlspecialchars($r['jam'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Tempat</td><td width="10">:</td><td><?echo htmlspecialchars($r['tempat'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Acara</td><td width="10">:</td><td><?echo htmlspecialchars($r['acara'])?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100" colspan="3">&nbsp;Demikian disampaikan, atas kehadirannya diucapkan terima kasih</td><td width="10"></td>
</tr>
</table>
<br />
<table width="100%" style="border:none;">
<tr>
<td width="10%" valign="top"></td>
<td width="50%"></td><td align="center">Kepala Bappeda <br /><br /><br /><br /><br /><br /></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="50%"></td><td align="center"><u><?echo htmlspecialchars($rjab['nama'])?></u><br /><?echo htmlspecialchars($rjab['jabatan'])?><br />NIP. <?echo htmlspecialchars($rjab['nip'])?></td>
</tr>
</table>
</body>
</html>