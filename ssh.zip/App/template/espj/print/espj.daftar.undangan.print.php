<?
#$q="select * from undangan where id='"$_GET['id']"'";
#echo $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM undangan
where id='".$_GET['a']."'");
$exec = $stmt->execute();
$rt = $stmt->fetch();
###
$stmt = $conn->prepare("SELECT * FROM daftar_undangan 
left join undangan on daftar_undangan.idaktivitas=undangan.id
where daftar_undangan.idaktivitas='".$_GET['a']."'");
$exec = $stmt->execute();
$r2 = $stmt->fetchAll();
######

$conn = null;
?>
<html>
<head>
</head>
<style>
body{
	font-family:verdana;
}

</style>
<body>

<br />
<center><b><text style="font-size:13pt;">DAFTAR UNDANGAN</text></b><br />
<text style="font-size:11pt;"><? echo $rt['acara'];?></text>
<br>
<? echo $rt['hari'];?>, <? echo $rt['tgl'];?>, <? echo $rt['jam'];?>
<br><br><br><br>
</center>
<table width="100%">

<?$no=1;foreach ($r2 as $r) {?>
<tr>

<td width="10%" align="left"></td><td width="30%"><? echo $no;?>. <? echo $r['nama'];?></td><td></td>
</tr>
<?$no++;}?>
<tr>

<td width="10%" align="left"></td><td width="30%"></td><td align='center'>(<? echo $no-1;?> Orang)</td>
</tr>
</table>
<br />

</body>
</html>