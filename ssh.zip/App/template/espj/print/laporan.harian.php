<center>
<h2>LAPORAN KINERJA BAGIAN<br />
Tahun <?echo $_SESSION['thn'];?>
</h2>
</center>
<table class="table" width="100%">
<tr>
<th>Nama</th><th>Kelas</th><th>SPP</th><th>EXTRA MANDIRI</th><th>INFAQ</th><th>KBM</th><th>ANJEM</th><th>KATERING</th><th>ATK-BUKU</th><th>JAMIYYAH</th><th>JUMLAH</th>
</tr>

<?if(1==2){?>
<tr>
<td style='text-align:left;'>--<?echo $ra['nama'];?></td>
<td><?echo uang($a);?></td><td><?echo uang($b);?></td><td><?echo uang($c);?></td><td><?echo uang($d);?></td>
<td><?echo uang($e);?></td><td><?echo uang($f);?></td><td><?echo uang($g);?></td>
<td><?echo uang($h);?></td><td><?echo uang($i);?></td>
<td><?echo number_format((($h)/$a)*100,3);?></td>
</tr>
<?}}?>
<tr>
<td style='text-align:left;'><?echo $r['nama'];?></td>
<td><?echo uang($a);?></td><td><?echo uang($b);?></td><td><?echo uang($c);?></td><td><?echo uang($d);?></td>
<td><?echo uang($e);?></td><td><?echo uang($f);?></td><td><?echo uang($g);?></td>
<td><?echo uang($h);?></td><td><?echo uang($i);?></td>
<td><?echo number_format((($h)/$a)*100,3);?></td>
</tr>

<?}?>
</table>