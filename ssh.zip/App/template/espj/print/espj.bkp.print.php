<?
#$q="select * from undangan where id='"$_GET['id']"'";
#echo $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM undangan where id='".$_GET['a']."'");
$exec = $stmt->execute();
$r2 = $stmt->fetch();
######
$stmt = $conn->prepare("
SELECT * ,kegiatan.uraian as txtkeg FROM bend26 
inner join kegiatan on bend26.kkeg=kegiatan.kodekeg
where id='".$_GET['a']."'");
$exec = $stmt->execute();
$r = $stmt->fetch();
$conn = null;
?>
<html>
<head>
</head>
<style>
body{
	font-family:verdana;
}

</style>
<body>


<br>
<table width="100%">
<tr>
<td width="10%" valign="top"></td>
<td width="100" colspan="3" align="center">&nbsp;&nbsp;<b>BUKTI KAS PENGELUARAN</b></td><td width="10"></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Terima dari</td><td width="10">:</td><td><? echo $r['trmdari'];?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Uang sebesar</td><td width="10">:</td><td><? echo ucwords($r['txtrupiah']);?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Untuk Pembayaran</td><td width="10">:</td><td><? echo $r['untukpemb'];?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Kegiatan</td><td width="10">:</td><td><? echo $r['txtkeg'];?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">Terbilang</td><td width="10">:</td><td>Rp. <? echo uang($r['rupiah']);?></td>
</tr>

</table>
<br />

<table width="100%" class="tabpolos">
<tr>
<td width="33%" valign="top" align="center">Mengatahui dan menyetujui:</td>
<td width="33%"></td>
<td align="center" width="33%">Wates, tanggal</td>
</tr>
<tr>
<td width="33%" valign="top" align="center">Pengguna Anggaran <br /> Kepala Bappeda<br /><br /><br /><br /><br /><br />
NAMA<br /><u>NIP</u></td>
<td width="33%" align="center">Bendahara Pengeluaran<br /><br /><br /><br /><br /><br />
NAMA<br /><u>NIP</u>
</td>
<td align="center" width="33%">Penerima <br /><br /><br /><br /><br /><br />
NAMA<br />ALAMAT:
</td>
</tr>
</table>
<br />
<table width="100%" style="border:1px solid black;border-collapse:collapse;" cellpadding="5" cellspacing="5">

<tr>
<td width="33%" valign="top" align="center" style="border:1px solid black;" >Barang Tersebut telah diterima <br /> dengan cukup dan baik<br /><br /><br /><br /><br /><br /><br />
NAMA<br /><u>NIP</u></td>
<td width="33%" align="left" style="border:1px solid black;">Telah dipungut<br />
PPN    =Rp.<? echo uang($r['ppn']);?><br />
PPh 23 =Rp.<? echo uang($r['pph23']);?><br />
Pajak Daerah = Rp.<? echo uang($r['pajakdaerah']);?><br />
<br /><br /><br /><br /><br />
<center>(.......................................)</center>
</td>
<td align="left" width="33%" valign="top" style="border:1px solid black;">
Telah dibukukan: <br />
BK Tgl. <? echo $r['tgl'];?><br />
BKP Rek: <? echo $r['krek'];?><br />
Tahun Anggaran : <?echo date(Y);?><br /><br />
</td>
</tr>
</table>
</body>
</html>