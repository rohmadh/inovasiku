<center>
<h2>Rekapitulasi Serapan Kegiatan<br />
<?echo $_SESSION['namauser'];?> <?echo $_SESSION['skpduser'];?> Tahun <?echo $_SESSION['thn'];?>
</h2>
</center>
<table class="table" width="100%">
<thead>
<tr>
<th>Program/Kegiatan</th><th>Jumlah Anggaran</th><th>GU</th><th>TU</th><th>LS</th><th>JML PANJAR</th><th>S/D BLN LALU</th><th>BLN INI</th><th>S/D BLN INI</th><th>SISA ANGGARAN</th><th>(%) serapan</th>
</tr>
</thead>
<tbody>
<?
$q=mysql_query("select * from master where kode !='' and kprog !='' and tahun='".$_SESSION['thn']."'");
while($r=mysql_fetch_array($q)){
?>

<?
$q2=mysql_query("select * from master 
left join tbl_keg_bagian on master.kode=tbl_keg_bagian.koderek
where kkeg !='' and kode like '".$r['kode']."%' and kodeuser='".$_SESSION['iduser']."' and master.tahun='".$_SESSION['thn']."' and tbl_keg_bagian.tahun='".$_SESSION['thn']."'");
while($r2=mysql_fetch_array($q2)){
$qr=mysql_query("select 
sum(case when tipespj='1' then jml end) as gu,
sum(case when tipespj='2' then jml end) as tu,
sum(case when tipespj='3' then jml end) as ls,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj2.tgl,'%d/%m/%Y'))<month(now())) then jml else 0 end) as lalu,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj2.tgl,'%d/%m/%Y'))=month(now())) then jml else 0 end) as ini,
sum(case when (tipespj='1' and month(STR_TO_DATE(tblspj2.tgl,'%d/%m/%Y'))<=month(now())) then jml else 0 end) as sdini 
from tblspj2 where idkeg='".$r2['kode']."' and tahun='".$_SESSION['thn']."'
");
$rr=mysql_fetch_array($qr);
$qjar=mysql_query("select sum(npanjar) as jar from tblpanjar where idkeg='".$r2['kode']."' and tahun='".$_SESSION['thn']."'");
$rjar=mysql_fetch_array($qjar);
?>
<tr>
<td style='text-align:left;'><?echo $r2['kkeg'];?></td>
<td><?echo uang($r2['angg']);?></td><td><?echo uang($rr['gu']);?></td><td><?echo uang($rr['tu']);?></td><td><?echo uang($rr['ls']);?></td>
<td><?echo uang($rjar['jar']);?></td><td><?echo uang($rr['lalu']);?></td><td><?echo uang($rr['ini']);?></td>
<td><?echo uang($rr['sdini']);?></td><td><?echo uang($r2['angg']-$rr['sdini']);?></td>
<td><?echo number_format((($rr['sdini'])/$r2['angg'])*100,3);?></td>
</tr>

<?}echo mysql_error();}?>
</tbody>
</table>