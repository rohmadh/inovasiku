<link href="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<div class="row">
                    <div class="col-lg-12">
<?
$q=mysql_query("select * from skpd_kegiatan where id='".$_GET['id']."'");
$r=mysql_fetch_array($q);
?>

<div style="display: inline-block;vertical-align:top;">
                        <h3>KERTAS RENCANA KERJA<br /> NAMA KEGIATAN : <?echo $r['kegiatan'];?> <br />
						SKPD: <?echo $_SESSION['skpduser'];?><br ?>
						Tahun: <?echo $_SESSION['thn'];?>
						</h3>
						<h3>Total Anggaran:Rp. <label id="t"> Rp. 0,00</label></h3>
</div>

                    </div>
                </div>
				
				<div class="table-responsive" id="tabelasb">
				</div>

<div class="table-responsive" id="idtarget">
  <h1>LOADING DATA.....</h1>                              
</div>


    <script src="<?echo $base;?>/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
     <script>
         $(document).ready(function () {
             $('#dataTables-example').dataTable();
         });
    </script>
<script>
function saveskpdaktivitas() {
		var namaaktv=$("#namaaktv").val();
		var idasb=$("#asbaktv").val();
		var nvar=$("#varasb").val();
        $.ajax({url: 'App/api/skpd.aktivitas.php?mode=save&idkeg='+<?echo $_GET['id'];?>+'&nama='+namaaktv+'&idasb='+idasb+'&nvar='+nvar, success: function(result){
            refreshtabel();
        }});
    }
</script>
<?if($_SESSION['leveluser']=='0'){?>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/skpd.aktivitas.tabel.php?id=<?echo $_GET['id'];?>', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<?}else{?>
<script>
function refreshtabel() {
        $.ajax({url: 'App/api/skpd.aktivitashide.tabel.print.php?id=<?echo $_GET['id'];?>', success: function(result){
            $("#idtarget").html(result);
        }});
    }
</script>
<?}?>
<script>
function cariasb() {
		var s=$("#s").val();
		$("#tabelasb").show();
        $.ajax({url: 'App/api/asb.tabel.php?s='+s, success: function(result){
            $("#tabelasb").html(result);
        }});
    }
</script>
<script>
function awal(val) {
        $("#asbaktv").val('');
		$("#nasb").val('');
		$("#txtvar").html('');
		$("#s").val('');
		$("#s").focus();
		$("#tabelasb").hide();
		}
</script>
<script>
refreshtabel();
$("#namaaktv").focus();
</script>