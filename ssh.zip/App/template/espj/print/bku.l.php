<?
$qn=mysql_query("select * from setting where user='".$_SESSION['iduser']."'");
$rn=mysql_fetch_array($qn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
<title>Buku Kas UMUM</title></head>
<body>
<table style="text-align: left; width: 988px; height: 224px;" border="0" cellpadding="2" cellspacing="0"><tbody><tr align="center"><td style="width: 666px;" colspan="3" rowspan="1"><big><span style="font-weight: bold;">PEMERINTAH KABUPATEN TEGAL</span></big><br style="font-weight: bold;"><big><big><span style="font-weight: bold;">BUKU KAS PENGELUARAN PEMBANTU</span></big></big><br><span style="font-weight: bold;">TAHUN ANGGARAN 2018</span></td></tr><tr><td style="width: 284px;" align="undefined" valign="undefined">SKPD</td><td style="width: 11px;" align="undefined" valign="undefined">:</td><td style="width: 666px;" align="undefined" valign="undefined"><?echo $_SESSION['skpduser'];?></td></tr><tr><td style="width: 284px;" align="undefined" valign="undefined">Unit Kerja</td><td style="width: 11px;" align="undefined" valign="undefined">:</td><td style="width: 666px;" align="undefined" valign="undefined">
<?echo $_SESSION['namauser'];?>
</td></tr><tr><td style="width: 284px;" align="undefined" valign="undefined">Pengguna Anggaran/Kuasa Pengguna Angg</td><td style="width: 11px;" align="undefined" valign="undefined">:</td><td style="width: 666px;" align="undefined" valign="undefined"><?echo $rn['npenggunaangg'];?></td></tr><tr><td style="width: 284px;" align="undefined" valign="undefined">Bendahara Pengeluaran Pembantu</td><td style="width: 11px;" align="undefined" valign="undefined">:</td><td style="width: 666px;" align="undefined" valign="undefined"><?echo $rn['nbendahara'];?></td></tr></tbody></table>
<br>
<table style="text-align: left; width: 993px; height: 52px;" border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr><td>No</td><td align="undefined" valign="undefined">TANGGAL</td><td align="undefined" valign="undefined">KODE REKENING</td><td style="width:350px" align="undefined" valign="undefined">URAIAN</td><td align="center" valign="undefined">PENERIMAAN</td><td align="center" valign="undefined">PENGELUARAN</td></tr>
<?
$tb=mysql_escape_string($_GET['tb']);
$ta=mysql_escape_string($_GET['ta']);
$a=0;$b=0;	
$q=mysql_query("select * from tblspj2 
left join jenispajak on tblspj2.jpajak=jenispajak.id
where user='".$_SESSION['iduser']."' and (str_to_date(tgl,'%d/%m/%Y')) between str_to_date('".$ta."','%d/%m/%Y') and str_to_date('".$tb."','%d/%m/%Y') 
order by tgl ASC");
echo mysql_error();
while($r=mysql_fetch_array($q)){?>

<tr><td align="undefined" valign="undefined"></td>
<td align="undefined" valign="undefined"><? echo htmlspecialchars($r['tgl']);?></td>
<td align="undefined" valign="undefined"><? echo htmlspecialchars($r['idrek']);?></td>
<td align="undefined" valign="undefined"><? echo htmlspecialchars($r['uraian']);?>,<? echo strtoupper(htmlspecialchars($r['jbayar']));?></td>
<td align="right" valign="undefined"><? echo uang(0);?></td>
<td align="right" valign="undefined"><? echo uang($r['jml']);?></td>
</tr>
<?if($r['pajak']>0){?>
<tr><td align="undefined" valign="undefined"></td>
<td align="undefined" valign="undefined"><? echo htmlspecialchars($r['tgl']);?></td>
<td align="undefined" valign="undefined"></td>
<td align="undefined" valign="undefined">- Diterima <? echo htmlspecialchars($r['txtpajak']);?></td>
<td align="right" valign="undefined"><? echo uang($r['pajak']);?></td>
<td align="right" valign="undefined"><? echo uang(0);?></td>
</tr>

<tr><td align="undefined" valign="undefined"></td>
<td align="undefined" valign="undefined"><? echo htmlspecialchars($r['tgl']);?></td>
<td align="undefined" valign="undefined"></td>
<td align="undefined" valign="undefined">- Dikeluarkan <? echo htmlspecialchars($r['txtpajak']);?></td>
<td align="right" valign="undefined"><? echo uang(0);?></td>
<td align="right" valign="undefined"><? echo uang($r['pajak']);?></td>
</tr>

<?}
$a=$a+$r['pajak'];
$b=$b+$r['jml']+$r['pajak'];
}?>
<tr><td align="undefined" valign="undefined"></td><td align="undefined" valign="undefined"></td><td align="undefined" valign="undefined"></td><td align="undefined" valign="undefined">Jumlah</td><td align="right" valign="undefined"><? echo uang($a);?></td><td align="right" valign="undefined"><? echo uang($b);?></td></tr>
</tbody>
</table>
<br>
<table style="text-align: left; width: 991px; height: 88px;" border="0" cellpadding="2" cellspacing="0"><tbody><tr><td></td><td align="undefined" valign="undefined"></td></tr><tr><td align="undefined" valign="undefined"></td><td align="undefined" valign="undefined"></td></tr><tr><td align="undefined" valign="undefined"></td><td align="undefined" valign="undefined"></td></tr></tbody></table>
<br>
<table style="text-align: left; width: 990px; height: 88px;" border="0" cellpadding="2" cellspacing="0"><tbody><tr><td align="center">Mengetahui</td><td align="center" valign="undefined">Slawi,<?echo date('d')."&nbsp;".date('M')."&nbsp;".date('Y');?></td></tr><tr><td align="center" valign="undefined">Kuasa Pengguna Anggaran</td><td align="center" valign="undefined">Bendahara Pengeluaran Pembantu</td></tr><tr><td align="undefined" valign="undefined"></td><td align="undefined" valign="undefined"></td></tr><tr><td style="text-align: center;"><span style="text-decoration: underline;"><br><br><br><br><br><?echo $rn['npenggunaangg'];?></span><br>NIP.<?echo $rn['nippa'];?></td><td style="text-align: center;"><span style="text-decoration: underline;"><br><br><br><br><br><?echo $rn['nbendahara'];?></span><br>NIP.<?echo $rn['nipbend'];?></td></tr></tbody></table>
<br></body></html>