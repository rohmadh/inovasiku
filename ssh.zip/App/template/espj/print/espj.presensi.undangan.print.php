<?
#$q="select * from undangan where id='"$_GET['id']"'";
#echo $_GET['id'];
######
$stmt = $conn->prepare("SELECT * FROM undangan where id='".$_GET['a']."'");
$exec = $stmt->execute();
$r = $stmt->fetch();
$conn = null;
?>
<html>
<head>
</head>
<style>
body{
	font-family:verdana;
}
txt.pemkab {
  font-weight: bold;
  font-size:12pt;
}

txt.opd {
  font-weight: bold;
  font-size:17pt;
}

txt.alamatopd {
  font-size:12pt;
}

txt.tgl {
  text-align:right;
}
</style>
<body>
<table width="100%">
<tr>
<td width="10%"><img src="App/template/espj/assets/img/logokp.png" width="150px"></td>
<td align="center">
<txt class="pemkab">PEMERINTAH KABUPATEN KULON PROGO </txt><br/>
<txt class="opd">BADAN PERENCANAAN PEMBANGUNAN DAERAH</txt><br />
<txt class="alamatopd">Gedug BAPPEDA & BKD, Jl. Perwakilan No.01, Terbah, Wates, Kabupaten Kulon Progo, Daerah Istimewa Yogyakarta 55611</txt>
</td>
</tr>
</table>


<br>
<table width="100%">
<tr>
<td width="10%" valign="top"></td>
<td width="100" colspan="3" align="center">&nbsp;&nbsp;DAFTAR HADIR</td><td width="10"></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">HARI/TANGGAL</td><td width="10">:</td><td><? echo $r['hari']?>,<? echo $r['tgl']?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">WAKTU</td><td width="10">:</td><td><? echo $r['jam']?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">TEMPAT</td><td width="10">:</td><td><? echo $r['tempat']?></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="100">ACARA</td><td width="10">:</td><td><? echo $r['acara']?></td>
</tr>

</table>
<br />
<table width="100%" align="center">
<tr>
<td align="center">No</td><td align="center">NAMA</td><td align="center">ALAMAT/JABATAN</td><td colspan="2" align="center">TTD</td>
</tr>
<?
$a=1;
while($a<30){
?>
<tr>
<td align="center"><?echo $a;?>.</td><td align="center">...</td><td align="center">...</td>
<?if (fmod($a,2)==1){?>
<td align="center"><?echo $a;?>.</td><td align="center"></td><?}else{?>
<td align="center"></td><td align="center"><?echo $a;?>.</td><?}?>
</tr>
<?$a++;}?>
</table>
<br />
<table width="100%">
<tr>
<td width="10%" valign="top"></td>
<td width="50%"></td><td align="center">Wates, <br />Mengetahui,<br />PPTK<br /><br /><br /><br /></td>
</tr>
<tr>
<td width="10%" valign="top"></td>
<td width="50%"></td><td align="center"><u>Imron Rosyadi, SE. Msc</u><br />NIP. 1234 1234 1234</td>
</tr>
</table>
</body>
</html>