<html>
<head>
</head>
<style>
body{
	font-family:verdana;
}
txt.pemkab {
  font-weight: bold;
  font-size:12pt;
}

txt.opd {
  font-weight: bold;
  font-size:17pt;
}

txt.alamatopd {
  font-size:12pt;
}

p.thicker {
  font-weight: 900;
}
</style>
<body>
<table width="100%">
<tr>
<td width="10%"><img src="App/template/espj/assets/img/logokp.png" width="150px"></td>
<td align="center">
<txt class="pemkab">PEMERINTAH KABUPATEN KULON PROGO </txt><br/>
<txt class="opd">BADAN PERENCANAAN PEMBANGUNAN DAERAH</txt><br />
<txt class="alamatopd">Gedug BAPPEDA & BKD, Jl. Perwakilan No.01, Terbah, Wates, Kabupaten Kulon Progo, Daerah Istimewa Yogyakarta 55611</txt>
</td>
</tr>
</table>
</body>
</html>