<?
$q=mysql_query("select * from master_barang order by nama ASC");


?>

	<br />
	 <img src="App/template/images/c_tp.gif" alt="" width="596" height="6" style="margin:10px 0 0 0;align:center;" /> 
	  <span class="modl"> <span class="titl2" style="color:#DB4801;">Etalase Produk</span> 
	  
	  <div id="items" align="center">
	  <?while($r=mysql_fetch_array($q)){ ?>
	  <div class="item">
	  <?
	  $doc = new DOMDocument();
				@$doc->loadHTML($r['gbr']);

				$tags = $doc->getElementsByTagName('img');

				foreach ($tags as $tag) {
					$sgbr=$tag->getAttribute('src');
					
				}
	  
	  
	  ?>
	  <img src="App/<? if(strlen($sgbr)>0){echo $sgbr;}else{echo"App/template/images/noimage.jpg";}?>" height="140" width="140">
	  <p><a href="?pid=<? echo rawurlencode(encrypt("?modul=addons&page=product.read&id=".$r['id']."",$key2));?>"><?echo $r['nama'];?></a></p><span class="price">Rp. <?
	  if($r['harga']>0){
	  echo uang($r['harga']);}else{echo "call us";}?></span>
	  </div>
	  <?}?>
	  
	  </div> 
	  
	  </span> <img src="App/template/images/c_btm.gif" alt="" width="596" height="6" />