<?

if($_POST['tblc']=='SELESAI BELANJA'){
include('App/PHPMailer/examples/gmail.php');
mysql_query("insert into data_online (notrx,nama,alamat,pembayaran,notelp) values ('".$_SESSION['notrx']."','".$_POST['nama']."','".$_POST['alamatkirim']."',
'".$_POST['carabayar']."','".$_POST['telp']."')");

mysql_query("
insert into transaksi_order (id_klien,notrx,totalbeli,source)
select '5','".$_SESSION['notrx']."',sum(total),'I' from temporer_data where notrx='".$_SESSION['notrx']."'
");

mysql_query("
insert into transaksi_detail (notrx,idbarang,jml,total)
select notrx,idbarang,jml,total from temporer_data
");
echo mysql_error();
mysql_query("delete from temporer_data where notrx='".$_SESSION['notrx']."'");
kirimemail($_SESSION['notrx']);
unset($_SESSION['notrx']);
}

?>

<div id="main">
	
            <br />
			<div id="inside">
			<br />
			
				<div class="info">
				<p>
										
				</div>
				
				
			</div>
</div>
<span class="titl">Detail Pembelian</span> 
	
	<span class="txt">  <br />
      
      </span> 
	  
	  <img src="App/template/images/c_tp.gif" alt="" width="596" height="6" style="margin:10px 0 0 0;" /> 
	  <span class="modl"> <span class="titl2" style="color:#DB4801;">&nbsp;</span> 
	  
	  <span class="txt" style="width:90%;"> 
	  
					<form method="POST">
					<table>
					<tr>
					<td>Nama:</td><td><input type="text" name="nama"></td>
					</tr>
					<tr>
					<td>Alamat Pengiriman:</td><td><textarea name="alamatkirim"></textarea>
					</tr>
					<tr>
					<td>Pembayaran:</td><td><input type="text" name="carabayar"></td>
					</tr>
					<tr>
					<td>No Telp:</td><td><input type="text" name="telp"></td>
					</tr>
					</table>
					
					
					<h2>Keranjang Belanja Anda</h2>
					<br />
					<h3>No. ID Transaksi: <?echo $_SESSION['notrx'];?></h3>
					<br  />
					<table width="80%" border=1 cellpadding=5 cellspacing=0>
					<tr>
					<th>Nama Barang</th><th>Harga</th><th>Qty</th><th>Jumlah</th>
					</tr>
					<?
					$total=0;
					$qs=mysql_query("select * from temporer_data 
					left join master_barang on temporer_data.idbarang=master_barang.id
					where notrx='".$_SESSION['notrx']."'
					");
					while($rs=mysql_fetch_array($qs)){
					$total=$total+$rs['total']
					?>
					<tr>
					<td align="center"><?echo $rs['nama'];?></td><td align="right"><?echo uang($rs['harga']);?></td><td><?echo $rs['jml'];?></td><td align="right"><?echo uang($rs['total']);?></td>
					</tr>
					<?};?>
					<tr>
					<td colspan="3" align="center"><b>Jumlah</b></td><td align="right"><b><?echo uang($total);?></b></td>
					</tr>
					</table>
					<br>
					*) Harga tersebut belum biaya pengiriman. biaya pengiriman akan diinformasikan setelah menyelesaikan Belanja oleh Admin dengan mempertimbangkan
					harga dan jangkauan pengiriman. JNE, TIKI, POS 
					<br />
					<input type="submit" value="SELESAI BELANJA" name="tblc">
					</form>
	  </span> 
	  
	  </span> <img src="App/template/images/c_btm.gif" alt="" width="596" height="6" />