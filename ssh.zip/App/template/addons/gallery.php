<br />
<br />
 <img src="App/template/images/c_tp.gif" alt="" width="596" height="6" style="margin:10px 0 0 0;" /> 
	  <span class="modl"> <span class="titl2" style="color:#DB4801;">Foto Kegiatan</span> 
	  <a href="#" class="vw">View Full Gallery</a> 
	  <span style="width:595px; float:left;"> 
	  <iframe src="App/gallery/" width="100%" height="600" scrolling="no" frameborder="0"></iframe> 

	  </span> 
	  
	  </span> <img src="App/template/images/c_btm.gif" alt="" width="596" height="6" />