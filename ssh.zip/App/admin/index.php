<?
include('header.php');
if($_SESSION['logged']=='1'){ }else{
header("Location: login/");
}
$q=mysql_query("select * from setting limit 1");
$r=mysql_fetch_array($q);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>MyStore</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<script type="text/javascript">
tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

function GetClock(){
var d=new Date();
var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear();
if(nyear<1000) nyear+=1900;
var d=new Date();
var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds();
if(nmin<=9) nmin="0"+nmin
if(nsec<=9) nsec="0"+nsec;

document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+"";
}

window.onload=function(){
GetClock();
setInterval(GetClock,1000);
}
</script>


</head>
<body>
<!-- Header -->
<div id="header">
	<div class="shell">
		<!-- Logo + Top Nav -->
		<div id="top">
			<h1><a href="#"><?echo $r['namausaha'];?></a></h1>
			
			<div id="top-navigation">
				Welcome <a href="#"><strong><?echo $_SESSION['namauser']?></strong></a>
				<span>|</span>
				
				<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.user",$key2));?>">Profile Settings</a>
				<span>|</span>
				<a href="login/?mode=logout">Log out</a>
				<br>
				<div id="clockbox"></div>
			</div>
		</div>
		<!-- End Logo + Top Nav -->
		
		<!-- Main Nav -->
		<div id="navigation">
			<ul>
			    
			    
			    
			    
				<?if($_SESSION['namauser']=='administrator'){?>
				<li><a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=kategori",$key2));?>"><span>Kategori</span></a></li>
			    <li><a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.news",$key2));?>"><span>Berita</span></a></li>
				<li><a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=setting.taklim",$key2));?>"><span>Jadwam Taklim</span></a></li>
				<li><a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.user",$key2));?>"><span>User</span></a></li>
				
			    <?}?>
			</ul>
		</div>
		<!-- End Main Nav -->
	</div>
</div>
<!-- End Header -->

<!-- Container -->
<div id="container">
	<div class="shell">
		
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content" style="overflow-y: auto; max-height: 800px ">
				
<?php
if($data['page']) {
$page=$data['page'];
$modul=$data['modul'];
} else {
$page='daftar.news';
$modul='admin';
}
include("modul/".$modul."/".$page.".php");
?>  				
				
				

			</div>
			<!-- End Content -->
			
			<!-- Sidebar -->
			<div id="sidebar">
				
				<!-- Box -->
				<div class="box">
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>Transaksi</h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
					
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=new_order&mode=new",$key2));?>" class="add-button"><span>New ORDER</span></a>
						<div class="cl">&nbsp;</div>
						
						
						
						<!-- Sort -->
						<div class="sort">
						<label>Cek ORDER</label>
						<form method="POST" action="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=new_order",$key2));?>">
						<input type="text" name="notrx" value="<?echo $notrx;?>" class="field"></form>
							
							
							</select>
							
						</div>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box -->
				<?if($_SESSION['namauser']=='administrator'){?>
				<!-- Box -->
				<div class="box">
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>System Adm</h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
					
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.user",$key2));?>" class="add-button"><span>User Management</span></a>
						
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=setting",$key2));?>" class="add-button"><span>Nama Mahad</span></a>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=setting.faq",$key2));?>" class="add-button"><span>---F.A.Q</span></a>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=setting.welcome",$key2));?>" class="add-button"><span>Welcome Text</span></a>
						
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=upload",$key2));?>" class="add-button"><span>Media</span></a>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=add.link",$key2));?>" class="add-button"><span>Media</span></a>
						<div class="cl">&nbsp;</div>
						
						<!-- Sort -->
						<div class="sort">
						
						</div>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box -->
				<?}?>
				
			</div>
			<!-- End Sidebar -->
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->


<!-- Footer -->
<div id="footer">
	<div class="shell">
		<span class="left"><?echo $r['namausaha'];?>, <?echo $r['alamat'];?>&copy; 2015 - MyAdvertising</span>
		<span class="right">
			
		</span>
	</div>
</div>
<!-- End Footer -->
	
</body>
</html>