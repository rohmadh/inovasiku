<?
session_start();
ob_start();
include("../header.php");
?>
<?
if($_GET['mode']=='logout'){session_destroy();}
if($_POST['tbl']=='Login'){
#echo $cek1;
$nip=cleanerpost($_POST['username'],'string');
$psw=mysql_escape_string($_POST['password']);
$cek1=md5($psw);
$a=0;$b=0;$d=0;$k=0;
$q1="select *,pengguna.nama as tnama,pengguna.id as idd,skpd.namaskpd as skpd,pengguna.skpd as idskpd from pengguna 
left join skpd on pengguna.skpd=skpd.id
where nip=:nip and passwd=:psw";
#$stmt = $conn->prepare("SELECT * FROM pengguna");
$stmt = $conn->prepare($q1);
$stmt->bindValue(':nip', $nip, PDO::PARAM_STR);
$stmt->bindValue(':psw', $cek1, PDO::PARAM_STR);
$stmt->execute();
$r1 = $stmt->fetch();
#echo $stmt->rowCount();
 if(($stmt->rowCount()==1) and (strlen($r1['nip'])>0)) {
 $_SESSION['login']='1';$_SESSION['namauser']=$rprofil['tnama'];$_SESSION['nipuser']=$r1['nip'];$_SESSION['iduser']=$r1['idd'];
 $_SESSION['skpduser']=$r1['skpd'];$_SESSION['leveluser']=$r1['level'];$_SESSION['idskpduser']=$r1['idskpd'];$_SESSION['thn']=date('Y');
 $_SESSION['txtpmbtingkat']=$r1['skpd'];$_SESSION['pmbtingkat']=$r1['idskpd'];
 #header("Location: ../");
 echo "ok";
 }else{ echo "<center>----LOGIN GAGAL</center>";}
}

?>