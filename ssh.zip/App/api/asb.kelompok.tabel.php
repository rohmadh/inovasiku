
<?
include("../header.php");
$q=mysql_query("select * from kelompok order by nama ASC");
?>
<div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Nama Kelompok</th>
											<th>Rincian Aktivitas</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<div id="idtarget">
									<?while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            <td><? echo $r['id'];?></td>
                                            <td><div id="t<?echo $r['id'];?>"><? echo $r['nama'];?></div></td>
                                            <td><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=asb.aktivitas&id=".$r['id']."",$key2));?>">[LIHAT]</a>
											<?if($_SESSION['leveluser']=='0'){?>
											<input type="button" value="edit" onclick="enablekelompokasb(<? echo $r['id'];?>);">
											<input type="button" value="X" onclick="deletekelompokasb(<? echo $r['id'];?>);">
											<?}?>
											</td>
                                        </tr>
									<?}?>
									</div>
									</tbody>
								</table>
</div>