<?
session_start();
include("../header.php");

?>
<?
$q=mysql_query("select *,asb".$_SESSION['thn'].".id as idd from asb".$_SESSION['thn']." 
left join satuanharga".$_SESSION['thn']." on asb".$_SESSION['thn'].".idssh=satuanharga".$_SESSION['thn'].".id

where asb".$_SESSION['thn'].".idaktivitas='".$_GET['k']."'
order by asb".$_SESSION['thn'].".id ASC
");
echo mysql_error();
?>

                                 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Nama Barang</th>
											<th>Satuan</th>
											<th>Harga</th>
											<th>Volume ASB</th>
											<th>Pengali</th>
											<th>Total(Rp)</th>
											<th>proses</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?$ta=0;while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            <td><? echo $r['idd'];?></td>
                                            <td><? echo $r['nama'];?></td>
											<td><? echo $r['satuan'];?></td>
											<td><? echo $r['harga'];?></td>
											<td><? echo $r['volume'];?></td>
											<td><? 
											$driver = array("Orang"=>"1", "Hari"=>"1");
											$v = explode(",", $r['idvar']);
											$t=1;
											foreach ($v as $value) {
											echo $value;
											$t=$t*$driver[$value];
											}
											if($t=='0'){$t=1;}
											echo "&nbsp;Total=".$t;
											?></td>
											<td align="right"><? echo uang($r['harga']*$r['volume']*$t);?></td>
                                            <td><?if($_SESSION['leveluser']=='0'){?><input type="button" value="X" onclick="delssh(<?echo $r['idd'];?>);"><?}?></td>
											
                                        </tr>
									<?$ta=$ta+($r['harga']*$r['volume']*$t);}?>
									<tr>
									<td colspan="5"><h3>Total Nilai Satuan Aktivitas</h3></td><td colspan="2"><h3>Rp.<?echo uang($ta);?></h3></td>
									</tr>
									</tbody>
								</table>
<?
mysql_query("update aktivitas set hspk='".$ta."' where id='".$_GET['k']."'");
?>