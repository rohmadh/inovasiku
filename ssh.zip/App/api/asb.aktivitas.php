<?
session_start();
include("../header.php");

############ simpan
if($_POST['mode']=='SAVE'){
$q=mysql_query("insert into aktivitas (idkelompok,aktivitas,vdriver) value ('".$_POST['idkelompok']."','".$_POST['nama']."','".$_POST['vardriver']."')");
$rdata=array("status"=>"sukses","data"=>"".$_POST['nama']."");
}
###################
if($_POST['mode']=='update'){
mysql_query("update book_mast set book_name='".$_POST['judul']."',isbn_no='".$_POST['isbn']."',no_page='".$_POST['hal']."' 
where book_id='".$_POST['kode']."'
");
$qt=mysql_query("select * from book_mast where book_id='".$_POST['kode']."'");
$result = mysql_fetch_array($qt);
if($_POST['kode']){$rdata=array("status"=>"DATA SUKSES DIUPDATE...","total"=>$result['book_id'],"idb"=>$result['book_id'],
"judul"=>$result['book_name'],"isbn"=>$result['isbn_no'],"hal"=>$result['no_page']
);
}}
##############

if($_GET['mode']=='del') {
$qt=mysql_query("delete from aktivitas where id='".$_GET['k']."'");
$rdata=array("status"=>"DATA BERHASIL [".$_POST['kode']."]DIHAPUS");
}

########### hasil
header('Content-type: application/json');
echo json_encode($rdata);
?>