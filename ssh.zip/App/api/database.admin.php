<?
session_start();
include("../header.php");
if($_GET['mode']=='create'){
$thna=$_GET['thn'];
$thnb=$thna+1;
mysql_query("create table satuanharga".$thnb." like satuanharga".$thna."");
mysql_query("insert satuanharga".$thnb." select * from satuanharga".$thna."");
mysql_query("create table asb".$thnb." like asb".$thna."");
mysql_query("insert asb".$thnb." select * from asb".$thna."");
}
echo mysql_error();
#echo $thna;echo $thnb;
?>
