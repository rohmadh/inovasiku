<?
session_start();
include("../header.php");
if($_GET['mode']=='cari'){
$q=mysql_query("select *,pengguna.id as id,skpd.namaskpd as nskpd,skpd.id as iskpd from pengguna 
left join skpd on pengguna.skpd=skpd.id
where pengguna.nama like '%".$_GET['k']."%' or skpd.namaskpd like '%".$_GET['k']."%'
and pengguna.level>0
order by skpd.namaskpd,pengguna.nama ASC ");
}else{
$q=mysql_query("select *,pengguna.id as id,skpd.namaskpd as nskpd,skpd.id as iskpd from pengguna 
left join skpd on pengguna.skpd=skpd.id
where pengguna.level>0
order by skpd.namaskpd,pengguna.nama ASC ");
}
echo mysql_error();
?>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
											<th>USERNAME</th>
                                            <th>SKPD</th>
                                            <th>NAMA</th>
											<th>LEVEL</th>
											<th>proses</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<div id="idtarget">
									<?
									while($r=mysql_fetch_array($q)){
									?>
                                        <tr>
                                            <td><div id="nip<?echo $r['id'];?>"><? echo $r['nip'];?></div></td>
                                            <td><? echo $r['nskpd'];?><div id="skpd<?echo $r['id'];?>" style="visibility: hidden;"><? echo $r['iskpd'];?></div></td>
											<td><div id="nama<?echo $r['id'];?>"><? echo $r['nama'];?></div></td>
											<td><div id="l<?echo $r['id'];?>"><? echo $r['level'];?></div></td>
                                            <td><input type="button" value="EDIT" onclick="showedit(<?echo $r['id'];?>);"></td>
                                        </tr>
									<?}?>
									</div>
									</tbody>
								</table>