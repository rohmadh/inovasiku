<?
include("../header.php");
$q=mysql_query("select *,aktivitas.id as idd from aktivitas
left join kelompok on aktivitas.idkelompok=kelompok.id
where aktivitas like'%".$_GET['s']."%'");
?>
<table class="table table-striped table-bordered table-hover" id="dataasb">
<thead>
	<tr>
		<th>Kode</th>
		<th>Nama Aktivitas</th>
		<th>Spesifikasi</th>
		<th>Pengali</th>
	</tr>
</thead>
<tbody>

<?while($r=mysql_fetch_array($q)){?>
	<tr>
		<td><? echo $r['idd'];?></td>
		<td><div id="asb<?echo $r['idd'];?>"><? echo $r['aktivitas'];?></div></td>
		<td><? echo $r['spesifikasi'];?></td>
		<td><div id="asbvar<?echo $r['idd'];?>"><? echo $r['vdriver'];?></div></td>
		<td><input type="button" value="save" onclick="pilihasb(<?echo $r['idd'];?>);">
		
		</td>
	</tr>
<?}?>

</tbody>
</table>
<script>
function pilihasb(val) {
        $("#asbaktv").val(val);
		var x=$("#asb"+val+"").text();
		var txtvar=$("#asbvar"+val+"").text();
		$("#nasb").val(x);
		$("#s").val('');
		$("#txtvar").html(txtvar);
		$("#varasb").focus();
		$("#tabelasb").hide();
		
		}
</script>

<script>
         $(document).ready(function () {
             $('#dataasb').dataTable();
         });
    </script>