<?
session_start();
include("../header.php");
$q=mysql_query("select * from satuanharga".$_SESSION['thn']." order by id DESC limit 0,10 ");
?>

                                 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Nama BARANG</th>
											<th>SATUAN</th>
											<th>HARGA</th>
											<th>proses</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<div id="idtarget">
									<?while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            <td><? echo $r['id'];?></td>
                                            <td><div id="n<?echo $r['id'];?>"><? echo $r['nama'];?></div></td>
											<td><div id="s<?echo $r['id'];?>"><? echo $r['satuan'];?></div></td>
											<td align="right"><div id="h<?echo $r['id'];?>"><? echo $r['harga'];?></div></td>
                                            <td><input type="button" value="EDIT" onclick="showedit(<?echo $r['id'];?>);"></td>
                                        </tr>
									<?}?>
									</div>
									</tbody>
								</table>