
<?
include("../header.php");
$q=mysql_query("select *,aktivitas.id as idd from aktivitas
left join kelompok on aktivitas.idkelompok=kelompok.id
where idkelompok='".$_GET['k']."'");

?>
<div class="table-responsive">
                                 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Nama Kelompok</th>
											<th>Rincian ASB</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            <td><? echo $r['idd'];?></td>
                                            <td><? echo $r['aktivitas'];?></td>
                                            <td><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=asb.aktivitas&id=".$r['id']."",$key2));?>">[view]</a></td>
                                        </tr>
									<?}?>
									
									</tbody>
								</table>
</div>