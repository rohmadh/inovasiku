<?
session_start();
include("../header.php");

############ simpan
if($_POST['mode']=='SAVE'){
$qc=mysql_query("select max(id) as idmax from asb".$_SESSION['thn']."");
$rc=mysql_fetch_array($qc);
$q=mysql_query("insert into asb".$_SESSION['thn']." (id,idaktivitas,idssh,volume,idvar) value ('".($rc['idmax']+1)."','".$_POST['idaktivitas']."','".$_POST['idssh']."','".$_POST['vol']."','".$_POST['ivarasb']."')");
$rdata=array("status"=>"sukses","data"=>"".$_POST['nama']."");
}

##############

if($_GET['mode']=='delete') {
$qt=mysql_query("delete from asb".$_SESSION['thn']." where id='".$_GET['id']."'");
$rdata=array("status"=>"sukses");
}

########### hasil
header('Content-type: application/json');
echo json_encode($rdata);
?>