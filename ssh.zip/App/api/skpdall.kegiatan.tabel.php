<?
session_start();
include("../header.php");
$q=mysql_query("select *,skpd_kegiatan.id as id from skpd_kegiatan 
left join skpd on skpd_kegiatan.skpd=skpd.id
where tahun='".$_SESSION['thn']."'");
?>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
											<th>SKPD</th>
                                            <th>Nama Kegiatan</th>
											<th>ASB Aktivitas</th>
											<th>Belanja Non ASB <br />(Honorarium, Perjalanan Dinas)</th>
											<th>Total Anggaran</th>
											<th>Rincian Aktivitas</th>
											
                                        </tr>
                                    </thead>
                                    <tbody>
									<?while($r=mysql_fetch_array($q)){?>
                                        <tr>
                                            <td><? echo $r['id'];?></td>
											<td><? echo $r['namaskpd'];?></td>
                                            <td><? echo $r['kegiatan'];?></td>
											<td align="right"><? echo uang($r['totalanggaran']);?></td>
											<td align="right"><? echo uang($r['totalnonasb']);?></td>
											<td align="right"><? echo uang($r['totalanggaran']+$r['totalnonasb']);?></td>
                                            <td><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=skpd.aktivitas&id=".$r['id']."",$key2));?>">[view]</a>
											<input type="button" value="X" onclick="delskpdkegiatan('<?echo $r['id'];?>');">
											</td>
                                        </tr>
									<?}?>
									</tbody>
								</table>
<script>
function delskpdkegiatan(val) {
		alert("hapus Kegiatan..??");
        $.ajax({url: 'App/api/skpd.kegiatan.php?mode=del&keg='+val, success: function(result){
            refreshtabel();
        }});
    }
</script>