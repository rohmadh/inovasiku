<?
include("../config/db.php.inc");
$q=mysql_query("select * from regions where province='".$_GET['k']."' ")
?>
<label>Kabupaten/Kota <span>(Required Field)</span></label>
<select name="region" id="tes">
<?while($r=mysql_fetch_array($q)){?>
<option value="<? echo $r['id'];?>"><? echo $r['name'];?></option>
<?}?>
</select><br>
