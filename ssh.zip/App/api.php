<?
session_start();
include('header.php');
#include(''.$base.'/dbcnf/db.php');
if($_GET['m']){
include(''.$base.'/api/'.$_GET['m'].'.php');
}
?>