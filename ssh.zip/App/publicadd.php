<?
include('header.php');
if($_SESSION['status']!='publicadd'){
header('Location:../');
}

$q=mysql_query("select * from setting limit 1");
$r=mysql_fetch_array($q);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Alumni Add [Public]</title>
	<link rel="stylesheet" href="css/admin/style.css" type="text/css" media="all" />
<script type="text/javascript">
tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

function GetClock(){
var d=new Date();
var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear();
if(nyear<1000) nyear+=1900;
var d=new Date();
var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds();
if(nmin<=9) nmin="0"+nmin
if(nsec<=9) nsec="0"+nsec;

document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+"";
}

window.onload=function(){
GetClock();
setInterval(GetClock,1000);
}
</script>


</head>
<body>
<!-- Header -->
<div id="header">
	<div class="shell">
		<!-- Logo + Top Nav -->
		<div id="top">
			<h1><a href="#">Database Alumni Teknik Sipil dan Lingkungan UGM</a></h1>
			
			<div id="top-navigation">
				
				<br>
				<div id="clockbox"></div>
			</div>
		</div>
		<!-- End Logo + Top Nav -->
		
		<!-- Main Nav -->
		<div id="navigation">
		
		</div>
		<!-- End Main Nav -->
	</div>
</div>
<!-- End Header -->

<!-- Container -->
<div id="container">
	<div class="shell">
		
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content" >
				
<?php
if($data['page']) {
$page=$data['page'];
$modul=$data['modul'];
} else {
$page='alumni.list';
$modul='admin';
}
include("modul/".$modul."/".$page.".php");
?>  				
				
				

			</div>
			<!-- End Content -->
			
			<!-- Sidebar -->
			<div id="sidebar">
			<!-- Box -->
				<div class="box">
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>Informasi</h2>
						
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
					<p>
					Pastikan data diisi dengan LENGKAP dan SESUAI <br />
					</p>
					<p>
					<b>FORM PENGISIAN DATA ALUMNI ada 2 HALAMAN.</b><br />
					Halaman pertama berisi Biodata <br />
					Halaman kedua berisi Data Akademik
					</p>
					<p>
					Data yang telah diisi dan disimpan hanya dapat diverifikasi oleh Admin. Untuk keperluan lebih lanjut dapat menghubungi
					email: <b>alumni.tsipil@gmail.com</b>
					
					</p>
					<p>
					<?if($data['page']=='alumni.add2'){?>
					<p>
					Jika Sudah Selesai, Silahkan Klik TOmbol berikut agar data tersimpan dengan baik. <br />
					<br />
					
					</p>
						<a href="../?complete=y" class="add-button"><span>Selesai Pengisian</span></a></p>
					<?}?>	
						<div class="cl">&nbsp;</div>
						
						<!-- Sort -->
						<div class="sort">
						
						</div>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box -->	
				
				
				
			</div>
			<!-- End Sidebar -->
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->


<!-- Footer -->
<div id="footer">
	<div class="shell">
		<span class="left"><?echo $r['namausaha'];?>, <?echo $r['alamat'];?>&copy; 2015 - MyAdvertising</span>
		<span class="right">
			
		</span>
	</div>
</div>
<!-- End Footer -->
	
</body>
</html>