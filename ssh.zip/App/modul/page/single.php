<div class="clearfix content">
						
						<h1>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis </h1>
						<div class="clearfix post-meta">
							<p><span><i class="fa fa-user"></i> Admin</span> <span><i class="fa fa-clock-o"></i> 20 Jan 2014</span> <span><i class="fa fa-comment"></i> 4 comments</span> <span><i class="fa fa-folder"></i> Category</span></p>
						</div>
						
						<p>Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a 
						ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit. Class 
						aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos Sed non  mauris vitae erat consequat auctor eu in elit. Class 
						aptent taciti sociosqu</p>
						
						<div class="rectangle_large aligncenter"></div>
						
						
						<p>Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a 
						ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit. Class 
						aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos Sed non  mauris vitae erat consequat auctor eu in elit. Class 
						aptent taciti sociosqu</p>
						<div class="rectangle_medium aligncenter"></div>
						
						<blockquote>
							Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry
							<span>Antorjal alin</span>
						</blockquote>
						
						<p>Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a 
						ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit. Class 
						aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos Sed non  mauris vitae erat consequat auctor eu in elit. Class 
						aptent taciti sociosqu</p>
						
						<h3>Feature Options</h3>
						<ul>
							<li>dummy text of the printing and typesetting</li>
							<li>dummy text of the printing and typesetting</li>
							<li>dummy text of the printing and typesetting</li>
							<li>dummy text of the printing and typesetting</li>
							<li>dummy text of the printing and typesetting</li>
							<li>dummy text of the printing and typesetting</li>

						</ul>
						
						<h4>List items with anchor text</h4>
						<ul>
							<li><a href="">dummy text of the printing and typesetting</a></li>
							<li><a href="">dummy text of the printing and typesetting</a></li>
							<li><a href="">dummy text of the printing and typesetting</a></li>
							<li><a href="">dummy text of the printing and typesetting</a></li>
							<li><a href="">dummy text of the printing and typesetting</a></li>
							<li><a href="">dummy text of the printing and typesetting</a></li>
						</ul>
						
						<div class="more_post_container">
							<h2>You may Also like:</h2>
							<div class="more_post">
								<a href="">Lorem Ipsum is simply dummy text of the printing</a>
								<a href="">Lorem Ipsum is simply dummy text of the printing</a>
								<a href="">Lorem Ipsum is simply dummy text of the printing</a>
							</div>
						</div>	

						<div class="advertisement_container">
							<div class="advertisement">
								
							</div>
						</div>	
						
						<a class="btn" href="">Preview</a>
						<a class="btn" href="">Download</a>
					
					</div>