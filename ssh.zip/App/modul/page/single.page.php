<?
$q=mysql_query("update news set klik=(klik+1) where news.id='".$data['id']."'");


$q=mysql_query("
select *,kategori.kat as kate,news.id as idd from news 
left join kategori on news.kat=kategori.id
where news.id='".$data['id']."'
");
$r=mysql_fetch_array($q);

?>
<div class="clearfix content">
						
						<h1><? echo $r['judul'];?> </h1>
						<div class="clearfix post-meta">
							<p><span><i class="fa fa-user"></i> Admin</span> <span><i class="fa fa-clock-o"></i> <?echo $r['date'];?></span>  <span><i class="fa fa-folder"></i> <?echo $r['kate'];?></span></p>
						</div>
						<?echo $r[depan];?>
						<?echo $r[isi];?>
						
						<div class="advertisement_container">
							<div class="advertisement">
								
							</div>
						</div>	
						
						<a class="btn" href="#" onclick="window.print()">Print</a>
						
					
</div>