<?
$q=mysql_query("select *,kategori.kat as kate,news.id as idd from news 
left join kategori on news.kat=kategori.id
where judul like  '%".$_POST['q']."%' or
depan like '%".$_POST['q']."%' or
isi like '%".$_POST['q']."%'
order by news.date DESC limit 0,10");
echo mysql_error();
?>

<div class="clearfix content">
						<div class="content_title"><h2>Hasil Pencarian "<?echo $_POST['q'];?>"</h2></div>
						<?
						while($r=mysql_fetch_array($q)){
						?>
						<div class="clearfix single_content">
							<div class="clearfix post_date floatleft">
								<div class="date">
									<h3>27</h3>
									<p>January</p>
								</div>
							</div>
							<div class="clearfix post_detail">
								<h2><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=single.page&id=".$r['idd']."",$key2));?>">
								<?echo $r['judul'];?> </a></h2>
								<div class="clearfix post-meta">
									<p><span><i class="fa fa-user"></i> Admin</span> <span><i class="fa fa-clock-o"></i> <?echo $r['date'];?></span>  <span><i class="fa fa-folder"></i> <?echo $r['kate'];?></span></p>
								</div>
								
							</div>
						</div>
						<?}?>
											
					</div>
					
					