<!-- slider -->

							<div class="slider-holder">
								<div class="flexslider">
									<ul class="slides">
<?
if ($handle = opendir('slider/')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
			?>
										<li><img src="slider/<?echo "$entry";?>" width="720" height="334" border="0" usemap="#Map" /></li>
										
									<?
        }
    }

    closedir($handle);
}
?>
										
									</ul>
								</div>
							</div>
							
							<!-- end of slider -->	
<div class="home">
					
					<div>
						<div>
							<div>
							<h4>Selamat Datang</h4>
							<?
							$q=mysql_query("select welcome from setting limit 1");
							while($r=mysql_fetch_array($q)){
							
							?>
								
								<h3>Website RSIA Gunung Sawo Semarang</h3>
								<p>
								<?echo $r['welcome'];?>
								</p>
								<span><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=about",$key2));?>">Baca</a></span>
							<?}?>
							</div>
							<?
							$qc=mysql_query("select count(id) as idc from news where kat='10'");
							$qrc=mysql_fetch_array($qc);
							if($rqc['idc']>0) {
							?>
							<div>
							<h4>Berita Terbaru</h4>
							<?
							$q=mysql_query("select * from news where kat='10' order by date DESC");
							while($r=mysql_fetch_array($q)){
							
							?>
							
								
								<h2><?echo $r['judul']?></h2>
								<ul>
									<p><?echo $r['depan']?></p>
								</ul>
								<span><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=news.read&id=".$r['id']."",$key2));?>">Baca Berita</a></span><br /><br />
							<?}?>
							</div>
							<?}?>
						</div>
						<div>
							<h4>Pelayanan RSIA</h4>
							<a href="services.html"><img src="images/services.jpg" alt=""></a>
							<ul>
							<?
							$q=mysql_query("select * from services where tipe='1' order by urut ASC");
							while($r=mysql_fetch_array($q)){
							
							?>
							<li>
									<label onclick="toggle_visibility('sm<?echo $r['id']?>');" style="cursor:pointer"><?echo $r['judul']?></label>
									
								</li>
								<div id="sm<?echo $r['id']?>" style="display:none;">
								<?
								$qsm=mysql_query("select * from services where mm='".$r['id']."' order by urut ASC");
								while($rsm=mysql_fetch_array($qsm)){
								?>
								
								<label><a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=services.read&id=".$rsm['id']."",$key2));?>"><?echo $rsm['judul'];?></a></label><br>
								
								
								<?}?>
								</div>
								
							<?}?>
								<li>
									<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=services.read&id=".$r['id']."",$key2));?>"><?echo $r['judul']?></a>
								</li>
								
							</ul>
							
						</div>
						<div>
							<h4>Artikel & Berita</h4>
							<a href="?pid=<? echo rawurlencode(encrypt("?modul=page&page=list.artikel",$key2));?>"><img src="gambar/imagesourdoc.jpg" alt=""></a>
							
							
						</div>
					</div>
				</div>