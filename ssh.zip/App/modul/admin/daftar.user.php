<?
if($_POST['btldel']=="X"){
mysql_query("delete from pengguna where id='".$_POST['idu']."'");

}
if($_POST['passwd']){
mysql_query("update pengguna set password='".md5($_POST['passwd'])."' where id='".$_POST['idu']."'");
}
$q1=mysql_query("select * from pengguna");

?>
	<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=user.add",$key2));?>">Tambah User</a>
			
		</div>
		<!-- End Small Nav -->	
		
		
				
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Daftar User</h2>
						<div class="right">
							
							
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								<th>Nama</th>
								<th>username</th>
								<th>Ganti password</th>
								
								<th width="110" class="ac">Content Control</th>
							</tr>
							<?
							while($rq1=mysql_fetch_array($q1)) {
							?>
							<tr>
								<form method="POST">
								<td><h3><a href="#"><?echo $rq1['nama'];?></a></h3></td>
								<td><?echo $rq1['username'];?></td>
								<td><input type="text" name="passwd" class="field">
								<input type="hidden" name="idu" value="<?echo $rq1['id'];?>" class="field">
								</td>
								<td>
								<input type="submit" class="button" name="btldel" value="X" >
								<input type="button" class="button" value="SAVE" onclick="submit()">	
								</td>
								</form>
							</tr>
							<?}?>
							
							
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
				
			
			