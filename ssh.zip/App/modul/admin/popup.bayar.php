<?
if($data['mode']=='new'){
mysql_query("insert into transaksi_order (id_klien,notrx) values ('".$data['idklien']."','".$data['notrx']."')");
echo "ok";
}
if($_POST['action']=='submit'){
mysql_query("update transaksi_order set bayar='".$_POST['bayar']."', totalbeli='".$_POST['totalbeli']."', kembali=bayar-totalbeli, tutup='1' 
where notrx='".$data['notrx']."'");
echo mysql_error();
}
echo mysql_error();
if($_POST['tblpr']=='print'){
header("Location: invoice/invoice.php?notrx=".$data['notrx']."");

}
$r=mysql_query("select * from transaksi_order where notrx='".$data['notrx']."'");
$rr=mysql_fetch_array($r);
?>

<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>PEMBAYARAN</h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									
									<label>TOTAL PEMBELIAN</label>
									<input name="totalbeli" type="text" class="field size1" value="<?echo $data['totalbeli'];?>"/>
								</p>
								
								<p>
									
									<label>PEMBAYARAN </label>
									<input name="bayar" type="text" class="field size1" value="<? echo $rr['bayar'];?>"/>
								</p>
								
								<p>
									
									<label>Kembali </label>
									<input name="kembali" type="text" class="field size1" value="<?echo $rr['kembali'];?>"/>
								</p>
								
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							<input name="tblpr" type="submit" class="button" value="print" />
							<input name="action" type="submit" class="button" value="submit" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->