<?
if($_POST['q']){
$q1=mysql_query("select nama,alamat,telp,wkt,notrx,tutup from transaksi_order left join master_klien on transaksi_order.id_klien=master_klien.id
where nama like '%".$_POST['q']."%' or alamat like '%".$_POST['q']."%' or notrx like '%".$_POST['q']."%'
order by wkt desc
");
} else {
$q1=mysql_query("select nama,alamat,telp,wkt,notrx,tutup from transaksi_order left join master_klien on transaksi_order.id_klien=master_klien.id
order by wkt desc limit 0,25
");
}
echo mysql_error();
?>
		
		
		
				
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Latest Order</h2>
						<div class="right">
							
							<form method="post">
							<input type="text" class="field small-field" name="q"/>
							<input type="submit" class="button" value="search" />
							</form>
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<th>No.TRX</th>
								<th>Nama</th>
								<th>Alamat</th>
								<th>Telp</th>
								<th>Tgl</th>
								<th>Status</th>
								
								
							</tr>
							<?
							while($rq1=mysql_fetch_array($q1)) {
							?>
							
							<tr>
								<td>
								<form method="post" action="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=new_order",$key2));?>">
								<input type=hidden name="notrx" value="<?echo $rq1['notrx'];?>">
								<input type=submit class="button" value="<?echo $rq1['notrx'];?>">
								</form>
								</td>
								<td><h3><a href="#"><?echo $rq1['nama'];?></a></h3></td>
								<td><?echo $rq1['alamat'];?></td>
								<td><?echo $rq1['telp'];?></td>
								<td><?echo $rq1['wkt'];?></td>
								<td><?if($rq1['tutup']=='0'){echo "open";}else{echo "selesai";}?></td>
								
							</tr>
							<?}?>
							
							
							
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
				
			
			