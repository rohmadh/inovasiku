<?

?>
<script type="text/javascript" src="js/nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Upload Media, Picture </h2>
					</div>
					<!-- End Box Head -->
<?php
if($_SESSION['logged']=='0'){
header("Location: ?pid=".rawurlencode(encrypt("?modul=admin&page=login",$key2))."");
}
if($data['mode']=='del'){
unlink("gallery/gallery-images/".$data['dfile']."");
}
/*
* 	   Simple file Upload system with PHP.
* 	   Created By Tech Stream
* 	   Original Source at http://techstream.org/Web-Development/PHP/Single-File-Upload-With-PHP
*      This program is free software; you can redistribute it and/or modify
*      it under the terms of the GNU General Public License as published by
*      the Free Software Foundation; either version 2 of the License, or
*      (at your option) any later version.
*      
*      This program is distributed in the hope that it will be useful,
*      but WITHOUT ANY WARRANTY; without even the implied warranty of
*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*      GNU General Public License for more details.
*     
*/
	if(isset($_FILES['image'])){
		$errors= array();
		$file_name = $_FILES['image']['name'];
		$file_size =$_FILES['image']['size'];
		$file_tmp =$_FILES['image']['tmp_name'];
		$file_type=$_FILES['image']['type'];   
		$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
		
		$expensions= array("jpeg","jpg","png"); 		
		if(in_array($file_ext,$expensions)=== false){
			$errors[]="extension not allowed, please choose a JPEG or PNG file.";
		}
		if($file_size > 2097152){
		$errors[]='File size must be excately 2 MB';
		}				
		if(empty($errors)==true){
			move_uploaded_file($file_tmp,"gallery/gallery-images/".$file_name);
			echo "Success";
		}else{
			print_r($errors);
		}
	}
?>

<form action="" method="POST" enctype="multipart/form-data">
<input type="file" name="image" />
<input type="submit" value="PROSES"/>
</form>

<br><br>
<table width="90%" border=1 cellpadding=0>
<tr>
<th>Gambar</th><th>URL</th><th>DELETE</th>
</tr>


<?
if ($handle = opendir('gallery/gallery-images')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
			?>
			<tr>
             
			<td width="50%"><img src="gallery/gallery-images/<?echo "$entry";?>" width="150"></td><td><?echo "$entry";?></td>
			<td><a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=gallery.upload&mode=del&dfile=".$entry."",$key2));?>">HAPUS</a></td>
			</tr>
			
			<?
        }
    }

    closedir($handle);
}
?>

</table>					
				</div>
				<!-- End Box -->