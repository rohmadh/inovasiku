<?
if($_POST['action']=='submit'){
mysql_query("insert into news (id,judul,kat,depan,isi) values ('".rand()."','".mysql_real_escape_string($_POST['judul'])."',
'".mysql_real_escape_string($_POST['kat'])."',
'".mysql_real_escape_string($_POST['depan'])."','".mysql_real_escape_string($_POST['isi'])."')");
}

if($_POST['action']=='update'){
mysql_query("update news set judul='".mysql_real_escape_string($_POST['judul'])."',
depan='".mysql_real_escape_string($_POST['depan'])."',
isi='".mysql_real_escape_string($_POST['isi'])."',
kat='".$_POST['kat']."'

where id='".$_POST['ide']."'");
}
if($data['mode']=='edit'){
$qc=mysql_query("select * from news where id='".$data['id']."'");
$rqc=mysql_fetch_array($qc);
}

echo mysql_error();
?>
<script type="text/javascript" src="js/nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>
<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.news",$key2));?>">Daftar Berita/Artikel</a>
			
		</div>
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Tulis Berita</h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									
									<label>Judul <span>(Required Field)</span></label>
									<textarea name="judul" class="field size" rows="5" cols="100%"><?echo stripslashes($rqc['judul']);?></textarea>
								</p>
								
								<p>
									
									<label>Kategori </label>
									<select name="kat">
									<?
									$qk=mysql_query("select * from kategori");
									while($rqk=mysql_fetch_array($qk)){
									?>
									<option value="<?echo $rqk['id'];?>" <?if($rqk['id']==$rqc['kat']){echo "selected";}?>><?echo $rqk['kat'];?></option>
									<?}?>
									</select>
								</p>
								
								
								<p>
									
									<label>Isi Depan</label>
									<textarea name="depan" class="field size1" rows="10" cols="30"><?echo stripslashes($rqc['depan']);?></textarea>
								</p>
								<p>
									
									<label>Lanjutan Artikel</label>
									<textarea name="isi" class="field size1" rows="10" cols="30"><?echo stripslashes($rqc['isi']);?></textarea>
								</p>
								
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							<input type="hidden" name="ide" value="<?echo $data['id']?>">
							<input name="action" type="submit" class="button" value="<?if($data['mode']=='edit'){echo "update";}else{echo "submit";}?>" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->