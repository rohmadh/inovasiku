<script language="JavaScript" src="js/gen_validatorv4.js"
    type="text/javascript" xml:space="preserve"></script>
<script src="js/jquery-1.7.0.min.js" type="text/javascript"></script>
<?
if($_POST['action']=='submit'){
$_SESSION['kode']=rand();
mysql_query("insert into data_alumni 
(nama,region_id,occupation_id,alamat,notelp,nowa,nobb,email,fb,alamatskrg,instansi,jabatan,alamatktr,narasumber,jobfair,cpkeg,saran,idr) 
values ('".$_POST['nama']."','".$_POST['region']."','".$_POST['occupation']."','".$_POST['alamat']."','".$_POST['notelp']."','".$_POST['nowa']."','".$_POST['nobb']."','".$_POST['email']."',
'".$_POST['fb']."','".$_POST['alamatskrg']."','".$_POST['instansi']."','".$_POST['jabatan']."','".$_POST['alamatktr']."','".$_POST['narasumber']."',
'".$_POST['jobfair']."','".$_POST['cpkeg']."','".$_POST['saran']."','".$_SESSION['kode']."'
)");
if($_SESSION['status']=='publicadd'){
header("Location: publicadd.php?pid=".rawurlencode(encrypt("?modul=admin&page=alumni.add2&mode=start",$key2))."");
   }else {
   header("Location: ?pid=".rawurlencode(encrypt("?modul=admin&page=alumni.add2&mode=start",$key2))."");
   }
}

if($_POST['action']=='update'){

mysql_query("update data_alumni set 
nama='".$_POST['nama']."',region_id='".$_POST['region']."',occupation_id='".$_POST['occupation']."',alamat='".$_POST['alamat']."',notelp='".$_POST['notelp']."',nowa='".$_POST['nowa']."',nobb='".$_POST['nobb']."',
email='".$_POST['email']."',
fb='".$_POST['fb']."',alamatskrg='".$_POST['alamatskrg']."',instansi='".$_POST['instansi']."',jabatan='".$_POST['jabatan']."',
alamatktr='".$_POST['alamatktr']."',narasumber='".$_POST['narasumber']."',
jobfair='".$_POST['jobfair']."',cpkeg='".$_POST['cpkeg']."',saran='".$_POST['saran']."'
where id='".$_POST['ide']."'");
echo mysql_error();
}
if($data['mode']=='edit'){
$qc=mysql_query("select * from data_alumni where id='".$data['id']."'");
$rqc=mysql_fetch_array($qc);
}

echo mysql_error();
?>
<script type="text/javascript" src="js/nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>
<!-- Small Nav -->
		
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Add Alumni -- Halaman 1
						<?if($data['mode']=='edit'){?>
						<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=alumni.add2&ida=".$data['id']."",$key2));?>"><input type="button" value="RIWAYAT AKADEMIK"></a>
						<?}?>
						</h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post" name="myform" id="myform">
						
						<!-- Form -->
						<div class="form">
								<p>
									
									<label>Nama Lengkap dan Gelar<span>(Required Field)</span></label>
									<input name="nama" type="text" class="field size1" value="<?echo $rqc['nama'];?>"/>
								</p>
								<p>
									
									<label>Alamat <span>(Required Field)</span></label>
									<input name="alamat" type="text" class="field size1" value="<?echo $rqc['alamat'];?>"/>
								</p>
								<p>
								<script>
function ubah(val) {
        $.ajax({url: 'api/get.kabkot.php?k='+val, success: function(result){
            $("#tes2").html(result);
        }});
    }
</script>
									
									<label>Propinsi<span></span></label>
									<select name="prop" id="tes" onchange="ubah(this.value);">
									<? 
									if($data['mode']=='edit'){
									$q=mysql_query("select * from regions where id='".$rqc['region_id']."'");
									$rkab=mysql_fetch_array($q);
									
									}
									$q=mysql_query("select * from regions where city is null");
									
									while($r=mysql_fetch_array($q)){
									?>
									<option value="<?echo $r['province'];?>" <?if($rkab['province']==$r['province']){echo "selected";}?>><?echo $r['name'];?></option>
									<?}?>
									</select>
								</p>
								<p id="tes2">
								<?if($data['mode']=='edit'){?>
								<?
								$q=mysql_query("select * from regions where province='".$rkab['province']."' ")
								?>
								<label>Kabupaten/Kota <span>(Required Field)</span></label>
								<select name="region" id="tes">
								<?while($r=mysql_fetch_array($q)){?>
								<option value="<? echo $r['id'];?>" <?if($rqc['region_id']==$r['id']){echo "selected";}?>><? echo $r['name'];?></option>
								<?}?>
								</select>
								<?}?>
								</p>
								<p>
									
									<label>HP <span>(Required Field)</span></label>
									<input name="notelp" type="text" class="field size2" value="<?echo $rqc['notelp'];?>"/>
									<label>WA <span></span></label>
									<input name="nowa" type="text" class="field size2" value="<?echo $rqc['nowa'];?>"/>
									<label>Pin BB <span></span></label>
									<input name="nobb" type="text" class="field size2" value="<?echo $rqc['nobb'];?>"/>
									<label>E-mail <span>(Required Field)</span></label>
									<input name="email" type="text" class="field size2" value="<?echo $rqc['email'];?>"/>
								</p>
								<p>
									
									<label>Akun FB/Twitter<span></span></label>
									<input name="fb" type="text" class="field size1" value="<?echo $rqc['fb'];?>"/>
								</p>
								<p>
									
									<label>Alamat Saat ini<span>(Required Field)</span></label>
									<input name="alamatskrg" type="text" class="field size1" value="<?echo $rqc['alamatskrg'];?>"/>
								</p>
								<p>
									
									<label>Instansi<span></span></label>
									<input name="instansi" type="text" class="field size1" value="<?echo $rqc['instansi'];?>"/>
								</p>
								<p>
									
									<label>Bidang Kerja (<i>Occupation</i>)<span></span></label>
									<select name="occupation">
									<? 
									$qo=mysql_query("select * from occupations");
									while($ro=mysql_fetch_array($qo)){
									?>
									<option value="<?echo $ro['id'];?>" <?if($rqc['occupation_id']==$ro['id']){echo "selected";}?>><?echo $ro['name'];?></option>
									<?}?>
									</select>
								</p>
								<p>
									
									<label>Jabatan<span></span></label>
									<input name="jabatan" type="text" class="field size1" value="<?echo $rqc['jabatan'];?>"/>
								</p>
								<p>
									
									<label>Alamat Kantor<span></span></label>
									<input name="alamatktr" type="text" class="field size1" value="<?echo $rqc['alamatktr'];?>"/>
								</p>
								<p>
									
									<label>Kesediaan Menjadi Narasumber untuk kuliah tamu? </label>
									<select name="narasumber">
									
									<option value="1" <?if ($rqc['narasumber']=='1'){echo "selected";}?>>Ya</option>
									<option value="0" <?if ($rqc['narasumber']=='0'){echo "selected";}?>>Tidak</option>
									</select>
									
								</p>
								<p>
									
									<label>Kesediaan Instansi untuk berpartisipasi dalam acara Career Day (Job Fair) dalamrangka melakukan open recruitment?</label>
									<select name="jobfair">
									
									<option value="1" <?if ($rqc['jobfair']=='1'){echo "selected";}?>>Ya</option>
									<option value="0" <?if ($rqc['jobfair']=='0'){echo "selected";}?>>Tidak</option>
									</select>
									
								</p>
								<p>
									
									<label>
									
									Kesediaan menjadi Contact Person untuk kegiatan kuliah lapangan (field trip)?
									</label>
									<select name="cpkeg">
									
									<option value="1" <?if ($rqc['cpkeg']=='1'){echo "selected";}?>>Ya</option>
									<option value="0" <?if ($rqc['cpkeg']=='0'){echo "selected";}?>>Tidak</option>
									</select>
									
								</p>
								<p></p>
								<p>
									
									<label>Saran dan Masukan Alumni untuk DTSL</label>
									
									<textarea name="saran" class="field size1" rows="10" cols="30"><?echo stripslashes($rqc['saran']);?></textarea>
								</p>
								
								
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							<input type="hidden" name="ide" value="<?echo $data['id']?>">
							<input name="action" type="submit" class="button" value="<?if($data['mode']=='edit'){echo "update";}else{echo "submit";}?>" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->
<script language="JavaScript" type="text/javascript"
    xml:space="preserve">//<![CDATA[
//You should create the validator only after the definition of the HTML form
  var frmvalidator  = new Validator("myform");
  frmvalidator.addValidation("nama","req","SIlahkan Isi Nama lengkap dan Gelar");
  frmvalidator.addValidation("alamat","req","SIlahkan Isi Alamat");
  frmvalidator.addValidation("notelp","req","SIlahkan Isi NO. TELP");
  
  
  frmvalidator.addValidation("email","req");
  frmvalidator.addValidation("email","email");
  
  frmvalidator.addValidation("alamatskrg","req","SIlahkan Isi ALAMAT SEKARANG");
  frmvalidator.addValidation("instansi","req","SIlahkan Isi LENGKAP");
  frmvalidator.addValidation("alamatktr","req","SIlahkan Isi LENGKAP");

//]]></script>