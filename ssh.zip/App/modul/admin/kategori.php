<?
if($_POST['action']=='submit'){
mysql_query("insert into kategori (kat,ket) values ('".$_POST['kat']."','".$_POST['ket']."')");
}
if($_POST['action']=='update'){
mysql_query("update kategori set kat='".$_POST['kat']."',ket='".$_POST['ket']."' where id='".$_POST['idd']."'");
}
$q=mysql_query("select * from kategori where id='".$data['id']."'");
$r=mysql_fetch_array($q);
echo mysql_error();
?>
<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.kat",$key2));?>">Daftar Kategori</a>
			
		</div>
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Tambah Kategori Produk</h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									<span class="req">max 100 symbols</span>
									<label>Kategori <span>(Required Field)</span></label>
									<input name="kat" type="text" class="field size1" value="<? echo $r['kat'];?>"/>
								</p>
								<p>
									<span class="req">max 100 symbols</span>
									<label>Keterangan <span>(Required Field)</span></label>
									<input name="ket" type="text" class="field size1" value="<?echo $r['ket'];?>"/>
								</p>
								
								
								
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							<input type="hidden" name="idd" value="<?echo $r['id']?>">
							<input name="action" type="submit" class="button" value="<?if($data['mode']=='edit'){echo"update";}else{echo "submit";}?>" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->