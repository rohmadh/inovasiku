<?
if($_POST['masterorder']=='SIMPAN'){
mysql_query("insert into transaksi_order (id_klien,notrx) values ('".$_POST['idkliensave']."','".$_POST['notrx']."')");
}
if($data['mode']=='cek'){$_SESSION['notrx']=$data['ceknotrx'];}
if($data['mode']=='new'){$_SESSION['notrx']= rand();}
if($_SESSION['notrx']=='0'){
$notrx= rand();
} else {$notrx=$_SESSION['notrx'];}



if($data['idklien']>0){
$qk=mysql_query("select * from master_klien where id='".$data['idklien']."'");
$rqk=mysql_fetch_array($qk);
}



if($_POST['kprd']){
$qp=mysql_query("select * from master_barang where id='".$_POST['kprd']."'");
$rqp=mysql_fetch_array($qp);
}
if($_POST['rincian']=='submit'){
mysql_query("insert into transaksi_detail (notrx,idbarang,jml,total) values ('".$notrx."','".$_POST['kprd']."','".$_POST['qty']."','".$_POST['harga']*$_POST['qty']."')");
echo mysql_error();
}
if($_POST['eqty']){
mysql_query("update transaksi_detail set jml='".$_POST['eqty']."',total='".$_POST['eharga']*$_POST['eqty']."' where id='".$_POST['idrincian']."'");

}
if($_POST['notrx']){$_SESSION['notrx']=$_POST['notrx'];$notrx=$_SESSION['notrx'];
$qk=mysql_query("select * from transaksi_order left join master_klien on transaksi_order.id_klien=master_klien.id 
where notrx='".$_POST['notrx']."'");
$rqk=mysql_fetch_array($qk);
}

echo mysql_error();
?>
<script language="javascript" type="text/javascript">
<!--
function popitup(url) {
	self.name = 'mainWin';
	newwindow=window.open(url,'name','height=400,width=800,toolbar=0,status=0,left=150,top=100');
	if (window.focus) {newwindow.focus()}
	return false;
}

// -->
</script>
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Form ORDER </h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
						<table>
						<tr>
						<td><label>No.TRX</label></td><td><label>: <?echo $notrx;?></label></td>
						</tr>
						<tr>
						<td><label>Tanggal</label></td><td><label>: <? if($rqk['wkt']){echo $rqk['wkt'];}else{echo  date('Y-m-d h:i:s a', time());}?></label></td>
						</tr>
						
						<tr>
						<td><label>Nama Klien</label></td><td><label>: <?echo $rqk['nama'];?>&nbsp;&nbsp;<input type="button" value="CEK"
						onclick="return popitup('flat.php?pid=<? echo rawurlencode(encrypt("?modul=admin&page=popup.klien&idklien=".$rqk['id']."",$key2));?>')"
						></label>
						
						</td>
						</tr>
						<tr>
						<td><label>Alamat</label></td><td><label>: <?echo $rqk['alamat'];?></label></td>
						</tr>
						<tr>
						<td><label>Telp</label></td><td><label>: <?echo $rqk['telp'];?></label></td>
						</tr>
						</table>
								
								
								
								
								
							
						</div>
						<!-- End Form -->
						<?
						$qt=mysql_query("select sum(total) as tot from transaksi_detail where notrx='".$notrx."'");
						$rqt=mysql_fetch_array($qt);
						?>
						<!-- Form Buttons -->
						<div class="buttons">
						
						<b><font size="2">Total Order: Rp. <?echo uang($rqt['tot']);?></font></b><br>
						<?if($rqk['tutup']=='1'){?>
						<b><font size="2">Pembayaran: Rp. <?echo uang($rqk['bayar']);?></font></b><br>
						<b><font size="2">Kembali: Rp. <?echo uang($rqk['kembali']);?></font></b><br>
						<?}?>
						</div>
						<div class="buttons">
						
						<form method="POST" action="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=new_order",$key2));?>">
						<input type="hidden" name="idkliensave" value="<?echo $rqk['id'];?>">
						<input type="hidden" name="notrx" value="<?echo $notrx;?>">
						<?
						$qc=mysql_query("select count(notrx) as f from transaksi_order where notrx='".$notrx."' ");
						$rqc=mysql_fetch_array($qc);
						if($rqc['f']=='0'){$mode='new';
						?>
						<input type="submit" class="button" name="masterorder" value="SIMPAN" />
						<?};?>
						<?if($rqt['tot']>0){?>
							<input name="action" type="submit" class="button" value="BAYAR" 
							onclick="return popitup('flat.php?pid=<? echo rawurlencode(encrypt("?modul=admin&page=popup.bayar&notrx=".$notrx."&totalbeli=".$rqt['tot']."&mode=".$mode."&idklien=".$rqk['id']."",$key2));?>')"
							/>
						<?}?>
						</form>
						</div>
						<!-- End Form Buttons -->
					</form>
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
						<table>
						<tr>
						<td><label>Kode Produk</label></td>
						<td></td>
						<td><label>Nama Produk</label></td><td><label>Satuan</label></td><td><label>Harga</label></td><td><label>Qty</label></td>
						</tr>
						<tr>
						<td><input type="text" name="kprd" class="field" size="5" value="<?echo $rqp['id']?>"></td>
						<td align="left"><a href="#" 
						onclick="return popitup('flat.php?pid=<? echo rawurlencode(encrypt("?modul=admin&page=popup.daftar.produk&idklien=".$rqk['id']."",$key2));?>')">LIST</a>
						</td>
						<td><input type="text" name="nama" class="field" value="<?echo $rqp['nama']?>"></td>
						<td><input type="text" name="satuan" class="field" value="<?echo $rqp['satuan']?>"></td>
						<td><input type="text" name="harga" class="field" value="<?echo $rqp['harga']?>"></td>
						<td><input type="text" name="qty" class="field" size="5"></td>
						</tr>
						</table>
								
								
								
								
								
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							
							<input name="rincian" type="submit" class="button" value="submit" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->
<!------detail>
<?
$q1=mysql_query("select transaksi_detail.id as id,nama,satuan,harga,jml,total from transaksi_detail left join master_barang on transaksi_detail.idbarang=master_barang.id

where transaksi_detail.notrx='".$notrx."'
 ");

?>
		
		
		
				
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Rincian ORDER</h2>
						
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								<th>Nama Produk</th>
								<th>Satuan</th>
								<th>harga</th>
								<th>Qty</th>
								<th>Total</th>
								<th width="110" class="ac">Content Control</th>
							</tr>
							<?
							while($rq1=mysql_fetch_array($q1)) {
							?>
							<tr>
								
								<td><h3><a href="#"><?echo $rq1['nama'];?></a></h3></td>
								<td><?echo $rq1['satuan'];?></td>
								<td align="right"><?echo uang($rq1['harga']);?></td>
								<td>
								<form method="POST" action="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=new_order&idklien=".$rqk['id']."",$key2));?>">
								<input type=text name="eqty" value="<?echo $rq1['jml'];?>" class="field" size="5">
								<input type=hidden name="idrincian" value="<?echo $rq1['id'];?>" >
								<input type=hidden name="eharga" value="<?echo $rq1['harga'];?>" >
								</form>
								</td>
								<td align="right"><?echo uang($rq1['harga']*$rq1['jml']);?></td>
								<td><a href="#" class="ico del">Delete</a><a href="#" class="ico edit">Edit</a>
								
								</td>
							</tr>
							<?}?>
							
							
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
<!-->