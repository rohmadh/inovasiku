<?

$q1=mysql_query("select nama,saran from data_alumni order by nama ASC");
echo mysql_error();
?>
	<!-- Small Nav -->
		
		<!-- End Small Nav -->	
		
		
				
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Saran Alumni DTSL</h2>
						<div class="right">
							
							
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								<th>Nama</th>
								<th>Saran</th>
								
							</tr>
							<?
							
							while($rq1=mysql_fetch_array($q1)) {
							if(strlen($rq1['saran'])>7){
							?>
							<tr>
							<td><?echo $rq1['nama'];?></td>
							<td><?echo $rq1['saran'];?></td>	
							</tr>
							<?}}?>
							
							
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
				
			
			