<?
if($data['mode']=='del'){
mysql_query("delete from master_barang where id='".$data['id']."'");
}
if($_POST['q']){
$q1=mysql_query("select * from master_barang where nama like '%".$_POST['q']."%' ");}else{
$q1=mysql_query("select *,kategori.kat as kate,master_barang.id as idd from master_barang left join kategori on master_barang.kat=kategori.id");}

?>
		<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=produk",$key2));?>">Tambah Produk</a>
			
		</div>
		<!-- End Small Nav -->
		
		
				
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Daftar Produk</h2>
						<div class="right">
							<label></label>
							<form method="post">
							<input type="text" class="field small-field" name="q"/>
							<input type="submit" class="button" value="search" />
							</form>
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								<th>Nama</th>
								<th>kategori</th>
								<th>satuan</th>
								<th>Harga</th>
								
								<th width="110" class="ac">Content Control</th>
							</tr>
							<?
							while($rq1=mysql_fetch_array($q1)) {
							?>
							<tr>
								
								<td><h3><a href="#"><?echo $rq1['nama'];?></a></h3></td>
								<td><?echo $rq1['kate'];?></td>
								<td><?echo $rq1['satuan'];?></td>
								<td><?echo uang($rq1['harga']);?></td>
								<td>
								<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.produk&mode=del&id=".$rq1['idd']."",$key2));?>" class="ico del">Delete</a>
								<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=produk&mode=edit&id=".$rq1['idd']."",$key2));?>" class="ico edit">Edit</a>
								
								
								</td>
							</tr>
							<?}?>
							
							
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
				
			
			