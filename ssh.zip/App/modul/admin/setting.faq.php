<?
if($_POST['action']=='submit'){
mysql_query("update setting set faq='".$_POST['txt']."' ");
}
$q=mysql_query("select faq from setting limit 1");
$r=mysql_fetch_array($q);
?>
<script type="text/javascript" src="js/nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Setting </h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								
								<p>
									
									<label>F.A.Q</label>
									<textarea name="txt" class="field size1" rows="10" cols="30"><?echo $r['faq'];?></textarea>
								</p>
								
								
								
									
							
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							<input type="button" class="button" value="preview" />
							<input name="action" type="submit" class="button" value="submit" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->