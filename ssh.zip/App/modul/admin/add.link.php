<?
if($_POST['action']=='submit'){
mysql_query("insert into links (url,text) values ('".$_POST['url']."','".$_POST['text']."')");
}

?>
<!-- Small Nav -->
		<div class="small-nav">
			<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=daftar.link",$key2));?>">Daftar Link</a>
			
		</div>
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Form Link</h2>
					</div>
					<!-- End Box Head -->
					
					<form action="" method="post">
						
						<!-- Form -->
						<div class="form">
								<p>
									<span class="req">max 100 symbols</span>
									<label>URL <span>(Required Field)</span></label>
									<input name="url" type="text" class="field size1" />
								</p>
								<p>
									<span class="req">max 100 symbols</span>
									<label>text tampil <span>(Required Field)</span></label>
									<input name="text" type="text" class="field size1" />
								</p>
								
								
								
						</div>
						<!-- End Form -->
						
						<!-- Form Buttons -->
						<div class="buttons">
							
							<input name="action" type="submit" class="button" value="submit" />
						</div>
						<!-- End Form Buttons -->
					</form>
				</div>
				<!-- End Box -->