
<?
if($_POST['thn']){$thn=$_POST['thn'];}else{$thn=date('Y');}
$qtri=mysql_query("
SELECT 
sum(case  when month(wkt) between '1' and '3' then totalbeli else '0' end) as I,
sum(case  when month(wkt) between '4' and '6' then totalbeli else '0' end) as II,  
sum(case  when month(wkt) between '7' and '9' then totalbeli else '0' end) as III, 
sum(case  when month(wkt) between '10' and '12' then totalbeli else '0' end) as IV 
FROM `transaksi_order` 
where year(wkt)='".$thn."'
");

$q1=mysql_query("select wkt,month(wkt) as bulan,sum(totalbeli) as rp from transaksi_order where year(wkt)='".$thn."' 
group by bulan order by bulan ASC");

?>
<script language="javascript" type="text/javascript">
<!--
function popitup(url) {
	self.name = 'mainWin';
	newwindow=window.open(url,'name','height=400,width=800,toolbar=0,status=0,left=150,top=100');
	if (window.focus) {newwindow.focus()}
	return false;
}

// -->
</script>		
		
				<center>
				<form method="post">
				<b>Tahun Laporan </b> <input name="thn" value="<?if($_POST['thn']){echo $_POST['thn'];}else{echo date("Y");}?>" class="field" size="6">
				</form>
				</center>
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Laporan Triwulan</h2>
						<div class="right">
							<label></label>
							
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								
								<th>Triwulan I</th>
								<th>Triwulan II</th>
								<th>Triwulan III</th>
								<th>Triwulan IV</th>
								<th>Total</th>
								
							</tr>
							<?
							
							while($rtri=mysql_fetch_array($qtri)) {
							
							?>
							<tr>
								
								
								<td><?echo uang($rtri['I']);?></td>
								<td><?echo uang($rtri['II']);?></td>
								<td><?echo uang($rtri['III']);?></td>
								<td><?echo uang($rtri['IV']);?></td>
								<td><?echo uang($rtri['I']+$rtri['II']+$rtri['III']+$rtri['IV']);?></td>
								
							</tr>
							<?}?>
							
							
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Laporan Keuangan Bulanan</h2>
						<div class="right">
							<label></label>
							
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								<th>Bulan</th>
								<th>Penerimaan</th>
								
								
							</tr>
							<?
							$tot=0;
							while($rq1=mysql_fetch_array($q1)) {
							$tot=$tot+$rq1['rp'];
							?>
							<tr>
								
								<td><h3><a href="#" onclick="return popitup('invoice/lap.rinci.bulanan.php?bln=<? echo $rq1['bulan']?>&thn=<?echo $thn;?>&sbln=<?echo date("F",strtotime($rq1['wkt']));?>')" ><?echo date("F",strtotime($rq1['wkt']));?></a></h3></td>
								<td><?echo uang($rq1['rp']);?></td>
								
								
							</tr>
							<?}?>
							
							<tr>
							<td><label>Total Penerimaan</label></td><td><?echo uang($tot);?></td>
							</tr>
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Grafik Penerimaan</h2>
						<div class="right">
							<label></label>
							
						</div>
					</div>
					<!-- End Box Head -->	

					<img src="phplot/tes.php?thn=".$thn."" width="100%">
					
				</div>
				<!-- End Box -->
			
			