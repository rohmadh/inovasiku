<script language="JavaScript" src="js/gen_validatorv4.js"
    type="text/javascript" xml:space="preserve"></script>
<?
if($data['ida']>0) {
$dt=$data['ida'];
$q=mysql_query("select * from data_alumni where id ='".$dt."'");
} else {
$q=mysql_query("select * from data_alumni where idr ='".$_SESSION['kode']."'");
}

$rp=mysql_fetch_array($q);

if($_POST['action']=='submit'){

mysql_query("insert into akademik (idorg,jenjang,universitas,departemen,tmasuk,tlulus,prodi) 
values ('".$rp['id']."','".$_POST['jenjang']."','".$_POST['universitas']."','".$_POST['departemen']."','".$_POST['tmasuk']."'
,'".$_POST['tlulus']."','".$_POST['prodi']."'
)");

}

if($data['mode']=='del'){

mysql_query("delete from akademik where id='".$data['id']."'");
}

echo mysql_error();
?>
<script type="text/javascript" src="js/nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>
<!-- Small Nav -->
		
		<!-- End Small Nav -->
<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Form Alumni [<?echo $rp['nama'];?> ]-- Halaman 2 <br />
						
						</h2>
					</div>
					<!-- End Box Head -->
					
					
						
						<!-- Form -->
						
						<div class="table">
						
						<form method="POST" action="" name="myform" id="myform">		
						<table>
						<tr>
						<th>Jenjang</th><td>
						<select name="jenjang">
								<option value="S1">S1</option>
								<option value="S2">S2</option>
								<option value="S3">S3</option>
								
								</select>
								<p>Sesuai Jenjang Akademik saja. Jika masih studi (S2/S3) tahun lulus dikosongkan saja.</p>
						</td>
						
						</tr>
						<tr>
						<th>Universitas</th><td><input type="text" name="universitas"><span>(<i>Required Field</i>)</span></td>
						</tr>
						<tr>
						<th>Departemen</th><td><input type="text" name="departemen"><span>(<i>Required Field</i>)</span></td>
						</tr>
						<tr>
						<th>Tahun Masuk</th><td><input type="text" name="tmasuk"><span>(<i>Required Field</i>)</span></td>
						</tr>
						<tr>
						<th>Tahun Lulus</th><td><input type="text" name="tlulus"><span>(<i>Wajib diisi untuk S1</i>)</span></td>
						</tr>
						<tr>
						<th>Prodi</th><td><input type="text" name="prodi"><span>(<i>Required Field</i>)</span></td>
						</tr>
						<tr>
						<td colspan="2" align="right">Klik Untuk Menyimpan > <input type="submit" name="action" value="submit"></td>
						</tr>
						</table>
						</form>	
						
								
							
						</div>
						<!-- End Form -->
						
						
					
				</div>
				<!-- End Box -->
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Riwayat Akademik alumni</h2>
						<div class="right">
							
							<form method="post">
							<input type="text" class="field small-field" name="q"/>
							<input type="submit" class="button" value="search" />
							</form>
						</div>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								<th>Jenjang</th>
								<th>Universitas</th>
								<th>Departemen</th>
								<th>Masuk</th>
								<th>Lulus</th>
								<th>Prodi</th>
								<th width="110" class="ac">Content Control</th>
							</tr>
							
							<?
							$q1=mysql_query("select * from akademik where idorg='".$rp['id']."'");
							while($rq1=mysql_fetch_array($q1)) {
							?>
							<tr>
								
								<td><?echo $rq1['jenjang'];?></td>
								<td><?echo $rq1['universitas'];?></td>
								<td><?echo $rq1['departemen'];?></td>
								<td><?echo $rq1['tmasuk'];?></td>
								<td><?if($rq1['tlulus']==0){echo"-";}else{echo $rq1['tlulus'];}?></td>
								<td><?echo $rq1['prodi'];?></td>
								<td>
								<? if(($_SESSION['status'])=='publicadd'){?>
								<a href="publicadd.php?pid=<? echo rawurlencode(encrypt("?modul=admin&page=alumni.add2&mode=del&id=".$rq1['id']."",$key2));?>" class="ico del">Delete</a>
								<?}else{?>
								<a href="?pid=<? echo rawurlencode(encrypt("?modul=admin&page=alumni.add2&mode=del&id=".$rq1['id']."",$key2));?>" class="ico del">Delete</a>
								
								<?}?>
								
								</td>
							</tr>
							<?}?>
							
							
						</table>
						
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left"></div>
							<div class="right">
								
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
<script language="JavaScript" type="text/javascript"
    xml:space="preserve">//<![CDATA[
//You should create the validator only after the definition of the HTML form
  var frmvalidator  = new Validator("myform");
  frmvalidator.addValidation("universitas","req","Silahkan isi LEngkap");
  frmvalidator.addValidation("departemen","req","Silahkan isi LEngkap");
  frmvalidator.addValidation("tmasuk","req","Silahkan isi LEngkap");
  
  frmvalidator.addValidation("prodi","req","Silahkan isi LEngkap");
  

//]]></script>