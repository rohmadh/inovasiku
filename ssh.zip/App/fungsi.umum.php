<?
function txthtml($text) {
return htmlspecialchars($text,ENT_QUOTES,'UTF-8');
}
function cleanerpost($t,$tipe) {
$a=mysql_escape_string($t);
if($tipe=='string'){
$a=filter_var($a, FILTER_SANITIZE_STRING);
}
return $a;
}
####bulan
function bulan($k) {
if(strval($k)=='1'){$a="Januari";}
if(strval($k)=='2'){$a="Februari";}
if(strval($k)=='3'){$a="Maret";}
if(strval($k)=='4'){$a="April";}
if(strval($k)=='5'){$a="Mei";}
if(strval($k)=='6'){$a="Juni";}
if(strval($k)=='7'){$a="Juli";}
if(strval($k)=='8'){$a="Agustus";}
if(strval($k)=='9'){$a="September";}
if(strval($k)=='10'){$a="Oktober";}
if(strval($k)=='11'){$a="November";}
if(strval($k)=='12'){$a="Desember";}
return txthtml($a);
}
function splitva($k){
$a=str_split($k,8);
return intval($a[1]);
}
?>