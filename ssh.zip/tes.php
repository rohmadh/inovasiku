<?
$cars = array();
array_push($cars,array("Volvo",22,18));
array_push($cars,array("BMW",15,13));
array_push($cars,array("Saab",5,2));
array_push($cars,array("Land Rover",17,15));
#echo count($cars);
$x=0;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body,table,th,td {
font-size:10pt;
font-family:"Courier New", Courier, monospace;
}
* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
  font-size:10pt;
  float: left;
  width: 50%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>
</head>
<body>

<h2>Print TAGIHAN</h2>

<div class="row">
<?while($x<count($cars)){ ?>
  <div class="column" style="background-color:#;">
  <table width="95%" border="0" cellpadding="1" cellspacing="0">
	<tr>
	<td><img src="App\template\keualazhar\assets\img\logoslawiok.png" width="40"></td>
	<td align="center">AL AZHAR BSB CITY</td>
	<td><img src="App\template\keualazhar\assets\img\logoslawiok.png" width="40"></td>
	</tr>
	</table><br />
	Nama: <? echo $cars[$x][0];?><br/>
	Kelas: <? echo $cars[$x][1];?><br />
    <table width="95%" align="left" border="1" cellpadding="1" cellspacing="0">
	<tr>
	<th>Uraian</th><th>Jumlah</th>
	</tr>
	</table>
  </div>
<?$x=$x+1;}?>
</div>


</body>
</html>
